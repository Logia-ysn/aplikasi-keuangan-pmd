--
-- PostgreSQL database dump
--

\restrict RFKlpnNwjYgqpyzfjcJw0H4N4aC8OBx28gxo0zPgeLqgbIQvWkIjthYsW9F0NzA

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_offset_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_journal_entry_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoices DROP CONSTRAINT IF EXISTS sales_invoices_party_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoices DROP CONSTRAINT IF EXISTS sales_invoices_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoices DROP CONSTRAINT IF EXISTS sales_invoices_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoice_items DROP CONSTRAINT IF EXISTS sales_invoice_items_sales_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoice_items DROP CONSTRAINT IF EXISTS sales_invoice_items_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_party_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoice_items DROP CONSTRAINT IF EXISTS purchase_invoice_items_purchase_invoice_id_fkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoice_items DROP CONSTRAINT IF EXISTS purchase_invoice_items_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_runs DROP CONSTRAINT IF EXISTS production_runs_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_runs DROP CONSTRAINT IF EXISTS production_runs_created_by_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_run_items DROP CONSTRAINT IF EXISTS production_run_items_production_run_id_fkey;
ALTER TABLE IF EXISTS ONLY public.production_run_items DROP CONSTRAINT IF EXISTS production_run_items_item_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_party_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_entry_accounts DROP CONSTRAINT IF EXISTS journal_entry_accounts_journal_entry_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_entry_accounts DROP CONSTRAINT IF EXISTS journal_entry_accounts_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_entries DROP CONSTRAINT IF EXISTS journal_entries_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.journal_entries DROP CONSTRAINT IF EXISTS journal_entries_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_account_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fiscal_years DROP CONSTRAINT IF EXISTS fiscal_years_closed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_trail DROP CONSTRAINT IF EXISTS audit_trail_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS "accounts_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.accounting_ledger_entries DROP CONSTRAINT IF EXISTS accounting_ledger_entries_party_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accounting_ledger_entries DROP CONSTRAINT IF EXISTS accounting_ledger_entries_fiscal_year_id_fkey;
ALTER TABLE IF EXISTS ONLY public.accounting_ledger_entries DROP CONSTRAINT IF EXISTS accounting_ledger_entries_account_id_fkey;
DROP INDEX IF EXISTS public.users_username_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public.stock_movements_movement_type_idx;
DROP INDEX IF EXISTS public.stock_movements_movement_number_key;
DROP INDEX IF EXISTS public.stock_movements_journal_entry_id_key;
DROP INDEX IF EXISTS public.stock_movements_item_id_idx;
DROP INDEX IF EXISTS public.stock_movements_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.stock_movements_date_idx;
DROP INDEX IF EXISTS public.sales_invoices_status_idx;
DROP INDEX IF EXISTS public.sales_invoices_party_id_idx;
DROP INDEX IF EXISTS public.sales_invoices_invoice_number_key;
DROP INDEX IF EXISTS public.sales_invoices_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.sales_invoices_date_idx;
DROP INDEX IF EXISTS public.purchase_invoices_status_idx;
DROP INDEX IF EXISTS public.purchase_invoices_party_id_idx;
DROP INDEX IF EXISTS public.purchase_invoices_invoice_number_key;
DROP INDEX IF EXISTS public.purchase_invoices_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.purchase_invoices_date_idx;
DROP INDEX IF EXISTS public.production_runs_run_number_key;
DROP INDEX IF EXISTS public.production_runs_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.production_runs_date_idx;
DROP INDEX IF EXISTS public.production_run_items_production_run_id_idx;
DROP INDEX IF EXISTS public.payments_payment_number_key;
DROP INDEX IF EXISTS public.payments_party_id_idx;
DROP INDEX IF EXISTS public.payments_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.payments_date_idx;
DROP INDEX IF EXISTS public.payment_allocations_payment_id_idx;
DROP INDEX IF EXISTS public.payment_allocations_invoice_type_invoice_id_idx;
DROP INDEX IF EXISTS public."parties_partyType_idx";
DROP INDEX IF EXISTS public.journal_entries_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.journal_entries_entry_number_key;
DROP INDEX IF EXISTS public.journal_entries_date_idx;
DROP INDEX IF EXISTS public.inventory_items_code_key;
DROP INDEX IF EXISTS public.fiscal_years_name_key;
DROP INDEX IF EXISTS public.company_settings_slug_key;
DROP INDEX IF EXISTS public."accounts_rootType_idx";
DROP INDEX IF EXISTS public."accounts_parentId_idx";
DROP INDEX IF EXISTS public."accounts_accountNumber_key";
DROP INDEX IF EXISTS public."accounts_accountNumber_idx";
DROP INDEX IF EXISTS public.accounting_ledger_entries_reference_id_idx;
DROP INDEX IF EXISTS public.accounting_ledger_entries_party_id_idx;
DROP INDEX IF EXISTS public.accounting_ledger_entries_fiscal_year_id_idx;
DROP INDEX IF EXISTS public.accounting_ledger_entries_date_idx;
DROP INDEX IF EXISTS public.accounting_ledger_entries_account_id_idx;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.stock_movements DROP CONSTRAINT IF EXISTS stock_movements_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoices DROP CONSTRAINT IF EXISTS sales_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.sales_invoice_items DROP CONSTRAINT IF EXISTS sales_invoice_items_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoices DROP CONSTRAINT IF EXISTS purchase_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.purchase_invoice_items DROP CONSTRAINT IF EXISTS purchase_invoice_items_pkey;
ALTER TABLE IF EXISTS ONLY public.production_runs DROP CONSTRAINT IF EXISTS production_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.production_run_items DROP CONSTRAINT IF EXISTS production_run_items_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_allocations DROP CONSTRAINT IF EXISTS payment_allocations_pkey;
ALTER TABLE IF EXISTS ONLY public.parties DROP CONSTRAINT IF EXISTS parties_pkey;
ALTER TABLE IF EXISTS ONLY public.journal_entry_accounts DROP CONSTRAINT IF EXISTS journal_entry_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.journal_entries DROP CONSTRAINT IF EXISTS journal_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.inventory_items DROP CONSTRAINT IF EXISTS inventory_items_pkey;
ALTER TABLE IF EXISTS ONLY public.fiscal_years DROP CONSTRAINT IF EXISTS fiscal_years_pkey;
ALTER TABLE IF EXISTS ONLY public.company_settings DROP CONSTRAINT IF EXISTS company_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_trail DROP CONSTRAINT IF EXISTS audit_trail_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.accounting_ledger_entries DROP CONSTRAINT IF EXISTS accounting_ledger_entries_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.stock_movements;
DROP TABLE IF EXISTS public.sales_invoices;
DROP TABLE IF EXISTS public.sales_invoice_items;
DROP TABLE IF EXISTS public.purchase_invoices;
DROP TABLE IF EXISTS public.purchase_invoice_items;
DROP TABLE IF EXISTS public.production_runs;
DROP TABLE IF EXISTS public.production_run_items;
DROP TABLE IF EXISTS public.payments;
DROP TABLE IF EXISTS public.payment_allocations;
DROP TABLE IF EXISTS public.parties;
DROP TABLE IF EXISTS public.journal_entry_accounts;
DROP TABLE IF EXISTS public.journal_entries;
DROP TABLE IF EXISTS public.inventory_items;
DROP TABLE IF EXISTS public.fiscal_years;
DROP TABLE IF EXISTS public.company_settings;
DROP TABLE IF EXISTS public.audit_trail;
DROP TABLE IF EXISTS public.accounts;
DROP TABLE IF EXISTS public.accounting_ledger_entries;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."StockMovementType";
DROP TYPE IF EXISTS public."RootType";
DROP TYPE IF EXISTS public."PaymentType";
DROP TYPE IF EXISTS public."PartyType";
DROP TYPE IF EXISTS public."InvoiceStatus";
DROP TYPE IF EXISTS public."DocumentStatus";
DROP TYPE IF EXISTS public."AccountType";
--
-- Name: AccountType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AccountType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'Draft',
    'Submitted',
    'Cancelled'
);


--
-- Name: InvoiceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."InvoiceStatus" AS ENUM (
    'Draft',
    'Submitted',
    'Paid',
    'PartiallyPaid',
    'Overdue',
    'Cancelled'
);


--
-- Name: PartyType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PartyType" AS ENUM (
    'Customer',
    'Supplier',
    'Both'
);


--
-- Name: PaymentType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentType" AS ENUM (
    'Receive',
    'Pay'
);


--
-- Name: RootType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RootType" AS ENUM (
    'ASSET',
    'LIABILITY',
    'EQUITY',
    'REVENUE',
    'EXPENSE'
);


--
-- Name: StockMovementType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StockMovementType" AS ENUM (
    'In',
    'Out',
    'AdjustmentIn',
    'AdjustmentOut'
);


--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'Admin',
    'Accountant',
    'Viewer'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: accounting_ledger_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounting_ledger_entries (
    id text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    account_id text NOT NULL,
    party_id text,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    reference_type text NOT NULL,
    reference_id text NOT NULL,
    description text,
    fiscal_year_id text NOT NULL,
    is_cancelled boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    name text NOT NULL,
    "accountNumber" text NOT NULL,
    "accountType" public."AccountType" NOT NULL,
    "rootType" public."RootType" NOT NULL,
    "isGroup" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    currency text DEFAULT 'IDR'::text NOT NULL,
    description text,
    "parentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_trail (
    id text NOT NULL,
    user_id text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text NOT NULL,
    old_values jsonb,
    new_values jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_settings (
    id text NOT NULL,
    company_name text NOT NULL,
    address text,
    phone text,
    email text,
    tax_id text,
    logo_url text,
    default_currency text DEFAULT 'IDR'::text NOT NULL,
    fiscal_year_start_month integer DEFAULT 1 NOT NULL,
    slug text DEFAULT 'default'::text NOT NULL
);


--
-- Name: fiscal_years; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fiscal_years (
    id text NOT NULL,
    name text NOT NULL,
    start_date timestamp(3) without time zone NOT NULL,
    end_date timestamp(3) without time zone NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    closed_at timestamp(3) without time zone,
    closed_by text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_items (
    id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    unit text NOT NULL,
    category text,
    description text,
    current_stock numeric(15,3) DEFAULT 0 NOT NULL,
    minimum_stock numeric(15,3) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    account_id text,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entries (
    id text NOT NULL,
    entry_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    status public."DocumentStatus" DEFAULT 'Draft'::public."DocumentStatus" NOT NULL,
    narration text,
    fiscal_year_id text NOT NULL,
    created_by text NOT NULL,
    submitted_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: journal_entry_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journal_entry_accounts (
    id text NOT NULL,
    journal_entry_id text NOT NULL,
    account_id text NOT NULL,
    party_id text,
    debit numeric(15,2) DEFAULT 0 NOT NULL,
    credit numeric(15,2) DEFAULT 0 NOT NULL,
    description text
);


--
-- Name: parties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parties (
    id text NOT NULL,
    name text NOT NULL,
    "partyType" public."PartyType" NOT NULL,
    phone text,
    email text,
    address text,
    tax_id text,
    outstanding_amount numeric(15,2) DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_allocations (
    id text NOT NULL,
    payment_id text NOT NULL,
    invoice_type text NOT NULL,
    invoice_id text NOT NULL,
    allocated_amount numeric(15,2) NOT NULL
);


--
-- Name: payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payments (
    id text NOT NULL,
    payment_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    payment_type public."PaymentType" NOT NULL,
    party_id text NOT NULL,
    account_id text NOT NULL,
    amount numeric(15,2) NOT NULL,
    status public."DocumentStatus" DEFAULT 'Draft'::public."DocumentStatus" NOT NULL,
    reference_number text,
    notes text,
    created_by text NOT NULL,
    submitted_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    fiscal_year_id text NOT NULL
);


--
-- Name: production_run_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_run_items (
    id text NOT NULL,
    production_run_id text NOT NULL,
    item_id text NOT NULL,
    line_type text NOT NULL,
    quantity numeric(15,3) NOT NULL,
    rendemen_pct numeric(5,2),
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: production_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.production_runs (
    id text NOT NULL,
    run_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    notes text,
    reference_type text,
    reference_id text,
    reference_number text,
    rendemen_pct numeric(5,2),
    is_cancelled boolean DEFAULT false NOT NULL,
    fiscal_year_id text NOT NULL,
    created_by_id text NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: purchase_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_invoice_items (
    id text NOT NULL,
    purchase_invoice_id text NOT NULL,
    item_name text NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit text NOT NULL,
    rate numeric(15,2) NOT NULL,
    amount numeric(15,2) NOT NULL,
    account_id text NOT NULL,
    description text,
    discount numeric(5,2) DEFAULT 0 NOT NULL
);


--
-- Name: purchase_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_invoices (
    id text NOT NULL,
    invoice_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    party_id text NOT NULL,
    status public."InvoiceStatus" DEFAULT 'Draft'::public."InvoiceStatus" NOT NULL,
    grand_total numeric(15,2) NOT NULL,
    outstanding numeric(15,2) NOT NULL,
    due_date timestamp(3) without time zone,
    notes text,
    fiscal_year_id text NOT NULL,
    created_by text NOT NULL,
    submitted_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    biaya_lain numeric(15,2) DEFAULT 0 NOT NULL,
    potongan numeric(15,2) DEFAULT 0 NOT NULL,
    tax_pct numeric(5,2) DEFAULT 0 NOT NULL
);


--
-- Name: sales_invoice_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_invoice_items (
    id text NOT NULL,
    sales_invoice_id text NOT NULL,
    item_name text NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit text NOT NULL,
    rate numeric(15,2) NOT NULL,
    amount numeric(15,2) NOT NULL,
    account_id text NOT NULL,
    description text,
    discount numeric(5,2) DEFAULT 0 NOT NULL
);


--
-- Name: sales_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales_invoices (
    id text NOT NULL,
    invoice_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    party_id text NOT NULL,
    status public."InvoiceStatus" DEFAULT 'Draft'::public."InvoiceStatus" NOT NULL,
    grand_total numeric(15,2) NOT NULL,
    outstanding numeric(15,2) NOT NULL,
    due_date timestamp(3) without time zone,
    notes text,
    fiscal_year_id text NOT NULL,
    created_by text NOT NULL,
    submitted_at timestamp(3) without time zone,
    cancelled_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL,
    biaya_lain numeric(15,2) DEFAULT 0 NOT NULL,
    label_biaya text,
    label_potongan text,
    potongan numeric(15,2) DEFAULT 0 NOT NULL,
    tax_pct numeric(5,2) DEFAULT 0 NOT NULL,
    terms text
);


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    movement_number text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    item_id text NOT NULL,
    movement_type public."StockMovementType" NOT NULL,
    quantity numeric(15,3) NOT NULL,
    unit_cost numeric(15,2) DEFAULT 0 NOT NULL,
    total_value numeric(15,2) DEFAULT 0 NOT NULL,
    notes text,
    reference_type text,
    reference_id text,
    reference_number text,
    offset_account_id text,
    journal_entry_id text,
    fiscal_year_id text NOT NULL,
    created_by_id text NOT NULL,
    is_cancelled boolean DEFAULT false NOT NULL,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    username text NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role public."UserRole" DEFAULT 'Accountant'::public."UserRole" NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    last_login_at timestamp(3) without time zone,
    created_at timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
da5c8e67-a5bc-4cc0-980f-8d49c6bf69af	a811a922c33589fa6a1c52862b2d57d1acb91e1c1cd6c9bb628a866a5e219705	2026-03-14 14:25:43.109748+00	20260314142543_init_final_schema	\N	\N	2026-03-14 14:25:43.028151+00	1
77d7b6e1-896e-4dc3-8ed2-4a236b740c20	80e08f2ffb56240319367db3d5737e6c3198306349689fd8f1923497c627ce21	2026-03-14 20:01:28.456974+00	20260315000000_add-indexes-settings-slug	\N	\N	2026-03-14 20:01:28.445596+00	1
5f582332-a06d-4310-add9-bac7860786e7	dde29b4197b451cf9914676316c356cdb5b0a1c501051f28541c40c0a8a9faa2	2026-03-15 15:10:08.212227+00	20260315100000_add-inventory	\N	\N	2026-03-15 15:10:08.127298+00	1
47762479-d7e2-4d99-9485-2d056aa37758	f714da7bd9beab2569ec66108173362603193707a160ac412e9d581bde57f9b4	2026-03-15 22:23:20.412222+00	20260315110000_add-production-runs	\N	\N	2026-03-15 22:23:20.382755+00	1
\.


--
-- Data for Name: accounting_ledger_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounting_ledger_entries (id, date, account_id, party_id, debit, credit, reference_type, reference_id, description, fiscal_year_id, is_cancelled, created_at) FROM stdin;
423e8915-c66c-4b43-a6da-ef1b3d0ca761	2026-03-16 00:00:00	4626a83c-2270-4c20-911c-0cad3711f0db	\N	5000000.00	0.00	JournalEntry	c13f234a-92f1-46eb-a82a-afc64a13d0af	Persediaan: PI-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:18:41.418
95a14697-fc09-4f91-8ffa-ea22f1c48593	2026-03-16 00:00:00	83738eff-c0d8-4ef5-a524-240d529ffeaa	bc79a01d-761b-4b09-a3c7-ec329ddab228	0.00	5000000.00	JournalEntry	c13f234a-92f1-46eb-a82a-afc64a13d0af	Hutang: PI-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:18:41.418
736754ae-9f4a-40da-beab-0148bb700008	2026-03-16 00:00:00	c9c02bb2-f765-4552-885f-f173330ae1a7	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	8175100.00	0.00	JournalEntry	6692e7ad-c218-4987-90b7-df30a6e04d65	Piutang: SI-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:23:59.317
db725c53-9ba5-45d4-8bb5-1211e0ce0079	2026-03-16 00:00:00	7d1f94b7-a1bd-44f7-92cc-24619ec938c9	\N	0.00	8175100.00	JournalEntry	6692e7ad-c218-4987-90b7-df30a6e04d65	Penjualan: SI-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:23:59.317
3deea94d-2cdc-44c1-aa0c-f14087edf3ef	2026-03-16 00:00:00	49e18d26-dd22-4fc6-ae37-07db6f036bed	\N	8175100.00	0.00	JournalEntry	fa09f5f7-56dc-4eee-91e4-fd93b36ec629	Pembayaran: PAY-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:24:15.528
e783ebb9-e401-4e18-98a4-4bd2fd67ba0a	2026-03-16 00:00:00	c9c02bb2-f765-4552-885f-f173330ae1a7	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	0.00	8175100.00	JournalEntry	fa09f5f7-56dc-4eee-91e4-fd93b36ec629	Pembayaran: PAY-202603-0001	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:24:15.528
ac816215-108d-4ede-8c77-68a39cfdf7d3	2026-03-16 00:00:00	83738eff-c0d8-4ef5-a524-240d529ffeaa	bc79a01d-761b-4b09-a3c7-ec329ddab228	5000000.00	0.00	JournalEntry	092bf47c-1c50-48cb-910f-926d3dcdc7b8	Pembayaran: PAY-202603-0002	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:24:15.635
a195002d-bca7-4222-8c1d-eecc5c41bcdd	2026-03-16 00:00:00	49e18d26-dd22-4fc6-ae37-07db6f036bed	\N	0.00	5000000.00	JournalEntry	092bf47c-1c50-48cb-910f-926d3dcdc7b8	Pembayaran: PAY-202603-0002	86cdd2ca-9f54-42dd-8352-8e447263a368	f	2026-03-16 12:24:15.635
\.


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, name, "accountNumber", "accountType", "rootType", "isGroup", "isActive", balance, currency, description, "parentId", "createdAt", "updatedAt") FROM stdin;
fcd23412-50f5-4adb-bb93-50e734186ddb	Bank BCA	1.1.2	ASSET	ASSET	f	t	0.00	IDR	\N	9d9057db-31be-439e-8a7e-dc733602d997	2026-03-14 14:28:42.391	2026-03-16 15:27:57.722
c9c02bb2-f765-4552-885f-f173330ae1a7	Piutang Usaha	1.1.3	ASSET	ASSET	f	t	0.00	IDR	\N	9d9057db-31be-439e-8a7e-dc733602d997	2026-03-14 14:28:42.394	2026-03-16 15:27:57.724
4626a83c-2270-4c20-911c-0cad3711f0db	Persediaan Gabah	1.1.4	ASSET	ASSET	f	t	5000000.00	IDR	\N	9d9057db-31be-439e-8a7e-dc733602d997	2026-03-14 14:28:42.396	2026-03-16 15:27:57.725
b57180c1-207b-4740-9133-2dbd6662f886	Penjualan Sekam	4.2	REVENUE	REVENUE	f	t	0.00	IDR	\N	cee13fad-90ca-4447-a30e-91071054f0ae	2026-03-14 14:28:42.513	2026-03-16 15:27:57.747
387d2425-2eaa-4f12-8b9d-4857bc2b42d8	Persediaan Beras	1.1.5	ASSET	ASSET	f	t	0.00	IDR	\N	9d9057db-31be-439e-8a7e-dc733602d997	2026-03-14 14:28:42.398	2026-03-16 15:27:57.726
a01ddb88-7559-4452-8d45-b8877caf8b45	Penjualan Bekatul	4.3	REVENUE	REVENUE	f	t	0.00	IDR	\N	cee13fad-90ca-4447-a30e-91071054f0ae	2026-03-14 14:28:42.517	2026-03-16 15:27:57.748
45e55d4f-3a03-4926-9ee4-f954573e9856	Beban	5	EXPENSE	EXPENSE	t	t	0.00	IDR	\N	\N	2026-03-14 14:28:42.522	2026-03-16 15:27:57.749
fcca786a-f7c1-4b09-8248-c4c17d6a7a9c	Harga Pokok Penjualan	5.1	EXPENSE	EXPENSE	t	t	0.00	IDR	\N	45e55d4f-3a03-4926-9ee4-f954573e9856	2026-03-14 14:28:42.529	2026-03-16 15:27:57.751
25859e51-bcda-4944-9b15-1f9ad624d61f	Pembelian Gabah	5.1.1	EXPENSE	EXPENSE	f	t	0.00	IDR	\N	fcca786a-f7c1-4b09-8248-c4c17d6a7a9c	2026-03-14 14:28:42.533	2026-03-16 15:27:57.751
e7822c8a-7162-4481-af89-1cec5e8ef9d2	Liabilitas	2	LIABILITY	LIABILITY	t	t	0.00	IDR	\N	\N	2026-03-14 14:28:42.402	2026-03-16 15:27:57.728
9f27f97d-a159-4d7f-8417-fa4d9fe9c9b9	Beban Operasional	5.2	EXPENSE	EXPENSE	t	t	0.00	IDR	\N	45e55d4f-3a03-4926-9ee4-f954573e9856	2026-03-14 14:28:42.535	2026-03-16 15:27:57.752
62d7e968-8c06-4ddb-a069-6a38d8360702	Listrik & Air Pabrik	5.2.1	EXPENSE	EXPENSE	f	t	0.00	IDR	\N	9f27f97d-a159-4d7f-8417-fa4d9fe9c9b9	2026-03-14 14:28:42.538	2026-03-16 15:27:57.753
e0bf71cf-61b6-4c82-ba40-2a7ef529c8b9	Gaji Karyawan	5.2.2	EXPENSE	EXPENSE	f	t	0.00	IDR	\N	9f27f97d-a159-4d7f-8417-fa4d9fe9c9b9	2026-03-14 14:28:42.54	2026-03-16 15:27:57.753
1076a054-aa62-4188-9a17-4e8178574ac1	Liabilitas Jangka Pendek	2.1	LIABILITY	LIABILITY	t	t	0.00	IDR	\N	e7822c8a-7162-4481-af89-1cec5e8ef9d2	2026-03-14 14:28:42.406	2026-03-16 15:27:57.73
83738eff-c0d8-4ef5-a524-240d529ffeaa	Hutang Usaha	2.1.1	LIABILITY	LIABILITY	f	t	0.00	IDR	\N	1076a054-aa62-4188-9a17-4e8178574ac1	2026-03-14 14:28:42.411	2026-03-16 15:27:57.732
b70b3bb7-3592-4c9e-aeb1-66d55f1e0a7c	Hutang Gaji	2.1.2	LIABILITY	LIABILITY	f	t	0.00	IDR	\N	1076a054-aa62-4188-9a17-4e8178574ac1	2026-03-14 14:28:42.414	2026-03-16 15:27:57.734
ad3cb4cc-ab7e-462c-86c3-73d9e7140212	Aset	1	ASSET	ASSET	t	t	0.00	IDR	\N	\N	2026-03-14 14:28:42.365	2026-03-16 15:27:57.694
9d9057db-31be-439e-8a7e-dc733602d997	Aset Lancar	1.1	ASSET	ASSET	t	t	0.00	IDR	\N	ad3cb4cc-ab7e-462c-86c3-73d9e7140212	2026-03-14 14:28:42.381	2026-03-16 15:27:57.7
49e18d26-dd22-4fc6-ae37-07db6f036bed	Kas Utama	1.1.1	ASSET	ASSET	f	t	3175100.00	IDR	\N	9d9057db-31be-439e-8a7e-dc733602d997	2026-03-14 14:28:42.388	2026-03-16 15:27:57.72
7675bc53-c6bb-459f-b47e-b34e478fa58b	Ekuitas	3	EQUITY	EQUITY	t	t	0.00	IDR	\N	\N	2026-03-14 14:28:42.421	2026-03-16 15:27:57.736
9f99fa81-f0de-42bf-9056-66e470d8714d	Modal Disetor	3.1	EQUITY	EQUITY	f	t	0.00	IDR	\N	7675bc53-c6bb-459f-b47e-b34e478fa58b	2026-03-14 14:28:42.491	2026-03-16 15:27:57.739
7447d7d6-db37-4a8a-85a4-5c4d3118af35	Laba Ditahan	3.2	EQUITY	EQUITY	t	t	0.00	IDR	\N	7675bc53-c6bb-459f-b47e-b34e478fa58b	2026-03-14 14:28:42.495	2026-03-16 15:27:57.741
3d1cb032-3fee-450a-a3a3-4895685c05a5	Laba Ditahan Akumulasi	3.2.1	EQUITY	EQUITY	f	t	0.00	IDR	\N	7447d7d6-db37-4a8a-85a4-5c4d3118af35	2026-03-16 12:20:53.892	2026-03-16 15:27:57.742
b015b24e-2e6f-43a2-a212-33b1750da1ac	Laba Periode Berjalan	3.3	EQUITY	EQUITY	t	t	0.00	IDR	\N	7675bc53-c6bb-459f-b47e-b34e478fa58b	2026-03-16 12:20:53.898	2026-03-16 15:27:57.742
86407d47-1fc2-4ab0-97f7-16ab9c36157f	Laba Tahun Berjalan	3.3.1	EQUITY	EQUITY	f	t	0.00	IDR	\N	b015b24e-2e6f-43a2-a212-33b1750da1ac	2026-03-16 12:20:53.899	2026-03-16 15:27:57.743
cee13fad-90ca-4447-a30e-91071054f0ae	Pendapatan	4	REVENUE	REVENUE	t	t	0.00	IDR	\N	\N	2026-03-14 14:28:42.499	2026-03-16 15:27:57.745
aebd4560-85f9-4a91-8ce5-d9746295a442	Penjualan Beras	4.1	REVENUE	REVENUE	t	t	0.00	IDR	\N	cee13fad-90ca-4447-a30e-91071054f0ae	2026-03-14 14:28:42.507	2026-03-16 15:27:57.746
7d1f94b7-a1bd-44f7-92cc-24619ec938c9	Penjualan Beras Premium	4.1.1	REVENUE	REVENUE	f	t	8175100.00	IDR	\N	aebd4560-85f9-4a91-8ce5-d9746295a442	2026-03-16 12:20:53.904	2026-03-16 15:27:57.747
\.


--
-- Data for Name: audit_trail; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_trail (id, user_id, action, entity_type, entity_id, old_values, new_values, ip_address, user_agent, created_at) FROM stdin;
48a4f3ad-7c2e-4c89-89b0-6359a5caeaa9	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-14 18:46:49.208
8248d81d-96d5-4549-a6dc-f92ada5b81a0	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-14 19:05:56.318
9ab4389b-5fea-4d10-b7bc-88e38d744caa	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.1.6041 Chrome/144.0.7559.173 Electron/40.4.1 Safari/537.36	2026-03-14 19:22:06.371
5b158605-106a-4550-b4f2-92494ed36312	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-14 19:23:09.506
7e4deabf-ecc4-4b03-aec3-805f8ef4f7b3	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-14 19:44:06.62
fd45242c-87d0-416d-b06b-652a112392d7	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-15 05:55:09.717
22d5e91f-7496-47f5-8b4a-fc86d7aff177	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-15 15:23:49.195
156e6366-c91c-4431-ad1c-2b1212323b2f	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-15 15:25:23.511
ae4b5cf0-17bf-43c7-89d5-dadd1c8020e8	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	518fc3d4-6924-4649-b378-3937da9eaf89	\N	{"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg", "account": null, "category": "Bahan Baku", "isActive": true, "accountId": null, "createdAt": "2026-03-15T15:25:23.552Z", "updatedAt": "2026-03-15T15:25:23.552Z", "description": null, "currentStock": "0", "minimumStock": "500"}	::1	Python-urllib/3.9	2026-03-15 15:25:23.56
57d0c0ac-10b8-4c11-8b63-df585d22cd8e	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	\N	{"id": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "code": "BERAS-001", "name": "Beras Premium", "unit": "kg", "account": null, "category": null, "isActive": true, "accountId": null, "createdAt": "2026-03-15T15:25:23.563Z", "updatedAt": "2026-03-15T15:25:23.563Z", "description": null, "currentStock": "0", "minimumStock": "200"}	::1	Python-urllib/3.9	2026-03-15 15:25:23.566
8c8e9cd2-9691-4b4f-86ab-a618a0dc3068	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	8133cfe6-c20b-402c-9b7e-6daca66f1bd3	\N	{"id": "8133cfe6-c20b-402c-9b7e-6daca66f1bd3", "date": "2026-03-15T00:00:00.000Z", "item": {"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg"}, "notes": "Pembelian gabah dari petani", "itemId": "518fc3d4-6924-4649-b378-3937da9eaf89", "quantity": "1000", "unitCost": "5000", "createdAt": "2026-03-15T15:25:23.577Z", "updatedAt": "2026-03-15T15:25:23.577Z", "totalValue": "5000000", "createdById": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "isCancelled": false, "referenceId": null, "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "movementType": "In", "referenceType": null, "journalEntryId": null, "movementNumber": "SM-202603-0001", "offsetAccountId": null, "referenceNumber": null}	::1	Python-urllib/3.9	2026-03-15 15:25:23.586
df1e98cb-f02a-4bd9-9a23-3b35382dcc62	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	e9cd1d6c-5835-4a8c-a010-d4582250bc83	\N	{"id": "e9cd1d6c-5835-4a8c-a010-d4582250bc83", "date": "2026-03-15T00:00:00.000Z", "item": {"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg"}, "notes": null, "itemId": "518fc3d4-6924-4649-b378-3937da9eaf89", "quantity": "200", "unitCost": "0", "createdAt": "2026-03-15T15:25:23.608Z", "updatedAt": "2026-03-15T15:25:23.608Z", "totalValue": "0", "createdById": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "isCancelled": false, "referenceId": null, "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "movementType": "Out", "referenceType": null, "journalEntryId": null, "movementNumber": "SM-202603-0002", "offsetAccountId": null, "referenceNumber": null}	::1	Python-urllib/3.9	2026-03-15 15:25:23.611
98183e19-dc93-4e8c-a1e9-2b9880438cf4	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	e9cd1d6c-5835-4a8c-a010-d4582250bc83	N/A	\N	{"message": "Gerakan stok berhasil dibatalkan."}	::1	Python-urllib/3.9	2026-03-15 15:25:23.635
4e6f5443-dc58-4b16-9826-7fca298fc486	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-15 15:25:34.641
581f2302-346d-4522-932d-841a873e97ef	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	\N	{"id": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "code": "BERAS-001", "name": "Beras Premium", "unit": "kg", "account": null, "category": null, "isActive": false, "accountId": null, "createdAt": "2026-03-15T15:25:23.563Z", "updatedAt": "2026-03-15T15:25:34.665Z", "description": null, "currentStock": "0", "minimumStock": "200"}	::1	Python-urllib/3.9	2026-03-15 15:25:34.671
17ca1072-78bb-4541-b70a-7c8533054f9e	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	518fc3d4-6924-4649-b378-3937da9eaf89	518fc3d4-6924-4649-b378-3937da9eaf89	\N	{"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg", "account": null, "category": "Bahan Baku", "isActive": false, "accountId": null, "createdAt": "2026-03-15T15:25:23.552Z", "updatedAt": "2026-03-15T15:25:34.672Z", "description": null, "currentStock": "1000", "minimumStock": "500"}	::1	Python-urllib/3.9	2026-03-15 15:25:34.678
ef70105b-ee47-443d-9e80-dda4aefde0d2	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:12:58.051
0c175663-5515-42ee-8bca-763a241d11c3	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:13:11.059
f31ce0f2-aa16-4de1-bb87-4ec959e1d9fa	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:13:44.557
03a0d016-4799-4e7b-bd8e-b579fd9a7737	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	N/A	\N	{"error": "Item 'Gabah Padi' tidak aktif."}	::1	Python-urllib/3.9	2026-03-16 00:13:44.585
a44a8cbd-cdbe-40c3-b3e9-e486a93cefdd	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:14:08.931
68c75227-6649-4036-a539-31467a79f918	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	N/A	\N	{"error": "Item 'Gabah Padi' tidak aktif."}	::1	Python-urllib/3.9	2026-03-16 00:14:08.941
2b77bcd1-4f74-432d-ae3d-a311492cc3d9	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:14:43.243
44dd0773-a59d-421e-9240-00768cc89c24	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:15:08.731
22eae356-4192-420b-a9c6-6b41de074b67	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	518fc3d4-6924-4649-b378-3937da9eaf89	518fc3d4-6924-4649-b378-3937da9eaf89	\N	{"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg", "account": null, "category": "Bahan Baku", "isActive": true, "accountId": null, "createdAt": "2026-03-15T15:25:23.552Z", "updatedAt": "2026-03-16T00:15:08.740Z", "description": null, "currentStock": "1000", "minimumStock": "500"}	::1	Python-urllib/3.9	2026-03-16 00:15:08.746
18b3b132-c707-4946-881a-e5dfd158e210	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	\N	{"id": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "code": "BERAS-001", "name": "Beras Premium", "unit": "kg", "account": null, "category": null, "isActive": true, "accountId": null, "createdAt": "2026-03-15T15:25:23.563Z", "updatedAt": "2026-03-16T00:15:08.746Z", "description": null, "currentStock": "0", "minimumStock": "200"}	::1	Python-urllib/3.9	2026-03-16 00:15:08.761
c389e35e-52f4-480b-967b-fc2498c8f0eb	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Python-urllib/3.9	2026-03-16 00:15:24.068
a00beb34-2a15-442f-a6a8-debae3970530	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	\N	{"id": "fa304c5b-b52b-4fb2-b1a7-bea5c22354b0", "date": "2026-03-15T00:00:00.000Z", "items": [{"id": "edf8369d-aa89-4d43-9375-eb49fbf2e4eb", "item": {"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg"}, "itemId": "518fc3d4-6924-4649-b378-3937da9eaf89", "lineType": "Input", "quantity": "500", "createdAt": "2026-03-16T00:15:24.117Z", "rendemenPct": null, "productionRunId": "fa304c5b-b52b-4fb2-b1a7-bea5c22354b0"}, {"id": "2c53d75e-2129-43e0-9d09-f880563a6db6", "item": {"id": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "code": "BERAS-001", "name": "Beras Premium", "unit": "kg"}, "itemId": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "lineType": "Output", "quantity": "350", "createdAt": "2026-03-16T00:15:24.117Z", "rendemenPct": "70", "productionRunId": "fa304c5b-b52b-4fb2-b1a7-bea5c22354b0"}], "notes": "Giling batch pertama", "createdAt": "2026-03-16T00:15:24.090Z", "runNumber": "PR-202603-0001", "updatedAt": "2026-03-16T00:15:24.090Z", "createdById": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "isCancelled": false, "referenceId": null, "rendemenPct": "70", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "referenceType": null, "referenceNumber": "PI-202603-0001"}	::1	Python-urllib/3.9	2026-03-16 00:15:24.125
e25bb464-4373-4c22-9f28-bd70ec3cd74b	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	N/A	\N	{"message": "Proses produksi berhasil dibatalkan."}	::1	Python-urllib/3.9	2026-03-16 00:15:24.152
cfdc9e5b-2963-45be-b338-4f6cd6ec18e7	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.1.6041 Chrome/144.0.7559.173 Electron/40.4.1 Safari/537.36	2026-03-16 00:15:41.738
d7dd4e20-cb19-4568-89df-fa01d54973d2	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 00:24:59.895
9af4d676-aa95-4cab-81eb-46df6c6f88a4	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	DELETE	unknown	N/A	\N	{"error": "Tidak dapat menghapus akun yang masih memiliki sub-akun. Hapus sub-akun terlebih dahulu."}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.1.6041 Chrome/144.0.7559.173 Electron/40.4.1 Safari/537.36	2026-03-16 00:32:16.267
17a44a22-251c-4a64-8fc5-7392c98d11a2	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:14:46.294
2beee0a0-1c08-47c8-bf4f-9f866677142d	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:15:24.563
a823e8dc-eba4-4632-973b-76b33c102fa5	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:16:17.968
609d014c-947a-43d7-a5b2-11fd346b555b	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:16:31.345
e9f3dd3d-aff5-4172-88ef-4a7563be751b	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:31:19.533
c2a6bb02-a994-455b-96a9-dcb29a94e1b3	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 11:35:46.301
96195f17-e220-4794-a7aa-1acb72d5c8f5	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:36:19.814
da69aee6-ace7-404b-aab7-aa47fb845785	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 11:36:20.728
f0a388cd-722c-4428-88e2-ac5ef2d6c9e7	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:18:21.834
f1fef3bc-d789-4596-9a7a-7877bf79ba79	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:18:32.426
69c9bb3f-46bf-4ba0-ad92-98dee94e883b	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	bc79a01d-761b-4b09-a3c7-ec329ddab228	\N	{"id": "bc79a01d-761b-4b09-a3c7-ec329ddab228", "name": "PT Gabah Makmur", "email": null, "phone": "08123456789", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.442Z", "partyType": "Supplier", "updatedAt": "2026-03-16T12:18:32.442Z", "outstandingAmount": "0"}	::1	curl/8.7.1	2026-03-16 12:18:32.451
ce0ac4cd-d228-4e88-a11f-0ddfdbf92316	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	\N	{"id": "fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e", "name": "Toko Beras Sejahtera", "email": null, "phone": "08198765432", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.513Z", "partyType": "Customer", "updatedAt": "2026-03-16T12:18:32.513Z", "outstandingAmount": "0"}	::1	curl/8.7.1	2026-03-16 12:18:32.515
0dcf40f3-8c44-417d-a244-0a5f401a6698	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:18:41.348
1adb6a44-c781-489c-9023-931609b05bc0	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:35:23.881
c6a48451-c4ac-4096-a63d-bf89210e9892	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:35:29.413
83a18552-5b5d-4a61-a7dd-69b35a6c5c4e	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:37:59.472
2a4d06f9-6a7c-4e54-ba80-257243f57cac	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 13:19:57.961
4083c5dd-5ba2-414c-ae91-0ddc899b6e2d	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 13:46:40.008
07df6813-effa-4bdd-97bb-e94fb7d4e065	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	d86ebfcd-f1ea-401f-8bb8-1897097da1fd	\N	{"id": "d86ebfcd-f1ea-401f-8bb8-1897097da1fd", "date": "2026-03-16T00:00:00.000Z", "notes": null, "status": "Submitted", "dueDate": null, "partyId": "bc79a01d-761b-4b09-a3c7-ec329ddab228", "supplier": {"id": "bc79a01d-761b-4b09-a3c7-ec329ddab228", "name": "PT Gabah Makmur", "email": null, "phone": "08123456789", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.442Z", "partyType": "Supplier", "updatedAt": "2026-03-16T12:18:32.442Z", "outstandingAmount": "0"}, "createdAt": "2026-03-16T12:18:41.391Z", "createdBy": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "updatedAt": "2026-03-16T12:18:41.391Z", "grandTotal": "5000000", "cancelledAt": null, "outstanding": "5000000", "submittedAt": "2026-03-16T12:18:41.378Z", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "invoiceNumber": "PI-202603-0001"}	::1	curl/8.7.1	2026-03-16 12:18:41.43
70579fb6-dd57-4ce4-a7d2-5f77d5441a1a	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:18:49.52
24beba79-20ff-4c24-800f-2239ff51d82c	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	N/A	\N	{"error": "Konfigurasi akun AR/Penjualan tidak ditemukan."}	::1	curl/8.7.1	2026-03-16 12:18:49.539
6fbc2a84-84ab-4ddb-b75b-e561bd3a6611	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:18:55.678
ea2152cb-c5ed-4f4c-a06b-61c5d4b88cda	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	N/A	\N	{"error": "Konfigurasi akun AR/Penjualan tidak ditemukan."}	::1	curl/8.7.1	2026-03-16 12:18:55.7
df6d2f1a-7562-46c4-986b-580c0a3ba45c	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:19:03.358
aea0c409-31f7-4dac-a8e6-e59700fba414	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:20:31.562
4e3f7fac-ed12-4756-b417-8c3e65758901	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:23:59.269
ddc45877-820a-4543-a2dd-670467206646	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	d014640c-b114-4181-84e8-e705a34b9f29	\N	{"id": "d014640c-b114-4181-84e8-e705a34b9f29", "date": "2026-03-16T00:00:00.000Z", "notes": null, "status": "Submitted", "dueDate": "2026-04-15T00:00:00.000Z", "partyId": "fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e", "customer": {"id": "fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e", "name": "Toko Beras Sejahtera", "email": null, "phone": "08198765432", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.513Z", "partyType": "Customer", "updatedAt": "2026-03-16T12:18:32.513Z", "outstandingAmount": "0"}, "createdAt": "2026-03-16T12:23:59.296Z", "createdBy": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "updatedAt": "2026-03-16T12:23:59.296Z", "grandTotal": "8175100", "cancelledAt": null, "outstanding": "8175100", "submittedAt": "2026-03-16T12:23:59.295Z", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "invoiceNumber": "SI-202603-0001"}	::1	curl/8.7.1	2026-03-16 12:23:59.324
38e5f483-1ccc-407f-8bf9-0016f5b3153a	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:24:15.445
df993766-12f4-402d-b462-f5b231dc8971	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	f29ba1eb-7259-45af-b9f7-55fcb627b955	\N	{"id": "f29ba1eb-7259-45af-b9f7-55fcb627b955", "date": "2026-03-16T00:00:00.000Z", "notes": null, "party": {"id": "fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e", "name": "Toko Beras Sejahtera", "email": null, "phone": "08198765432", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.513Z", "partyType": "Customer", "updatedAt": "2026-03-16T12:23:59.322Z", "outstandingAmount": "8175100"}, "amount": "8175100", "status": "Submitted", "partyId": "fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e", "accountId": "49e18d26-dd22-4fc6-ae37-07db6f036bed", "createdAt": "2026-03-16T12:24:15.512Z", "createdBy": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "updatedAt": "2026-03-16T12:24:15.512Z", "cancelledAt": null, "paymentType": "Receive", "referenceNo": null, "submittedAt": "2026-03-16T12:24:15.511Z", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "paymentNumber": "PAY-202603-0001"}	::1	curl/8.7.1	2026-03-16 12:24:15.549
9c5a9589-f69e-4806-87d0-4517afee5966	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	2b55f181-ba45-4472-869e-38be33cc1bcc	\N	{"id": "2b55f181-ba45-4472-869e-38be33cc1bcc", "date": "2026-03-16T00:00:00.000Z", "notes": null, "party": {"id": "bc79a01d-761b-4b09-a3c7-ec329ddab228", "name": "PT Gabah Makmur", "email": null, "phone": "08123456789", "taxId": null, "address": null, "isActive": true, "createdAt": "2026-03-16T12:18:32.442Z", "partyType": "Supplier", "updatedAt": "2026-03-16T12:18:41.428Z", "outstandingAmount": "5000000"}, "amount": "5000000", "status": "Submitted", "partyId": "bc79a01d-761b-4b09-a3c7-ec329ddab228", "accountId": "49e18d26-dd22-4fc6-ae37-07db6f036bed", "createdAt": "2026-03-16T12:24:15.628Z", "createdBy": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "updatedAt": "2026-03-16T12:24:15.628Z", "cancelledAt": null, "paymentType": "Pay", "referenceNo": null, "submittedAt": "2026-03-16T12:24:15.627Z", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "paymentNumber": "PAY-202603-0002"}	::1	curl/8.7.1	2026-03-16 12:24:15.645
e28d9fd9-fc0b-4e67-8d0b-48f8449da7e6	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:24:21.321
d7362759-a09a-438e-8363-37fd5ed08dd7	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:26:51.707
6b6798be-9985-476b-b745-fb4fa789ca62	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	CREATE	unknown	10349201-fc38-4795-8975-e888c7a68559	\N	{"id": "10349201-fc38-4795-8975-e888c7a68559", "date": "2026-03-16T00:00:00.000Z", "items": [{"id": "aafded06-7c33-4a30-adb9-6700137dc044", "item": {"id": "518fc3d4-6924-4649-b378-3937da9eaf89", "code": "GABAH-001", "name": "Gabah Padi", "unit": "kg"}, "itemId": "518fc3d4-6924-4649-b378-3937da9eaf89", "lineType": "Input", "quantity": "1000", "createdAt": "2026-03-16T12:26:51.828Z", "rendemenPct": null, "productionRunId": "10349201-fc38-4795-8975-e888c7a68559"}, {"id": "8c1a3826-1fb4-40df-a07c-e2c11d1eac99", "item": {"id": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "code": "BERAS-001", "name": "Beras Premium", "unit": "kg"}, "itemId": "77b38a80-5fca-4eb8-9c15-9c7dd5345db7", "lineType": "Output", "quantity": "650", "createdAt": "2026-03-16T12:26:51.828Z", "rendemenPct": "65", "productionRunId": "10349201-fc38-4795-8975-e888c7a68559"}], "notes": "Giling batch pertama", "createdAt": "2026-03-16T12:26:51.813Z", "runNumber": "PR-202603-0002", "updatedAt": "2026-03-16T12:26:51.813Z", "createdById": "f56b0571-bb3c-412a-91a7-acff8d4ffbd8", "isCancelled": false, "referenceId": null, "rendemenPct": "65", "fiscalYearId": "86cdd2ca-9f54-42dd-8352-8e447263a368", "referenceType": null, "referenceNumber": null}	::1	curl/8.7.1	2026-03-16 12:26:51.834
2d861d05-f5b4-47cb-911b-5dd51d8f77a8	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:29:06.943
e8538841-50e8-4f74-ae61-a2f41d97a5d5	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 12:29:13.07
7775996d-3f8d-4466-9c90-3f9cb9d1cc9a	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 14:57:11.971
1de768c2-b387-44d3-8157-1094d7435604	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 14:57:17.971
7c1561bc-efac-43c7-a200-20056f36ed19	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	LOGIN	user	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	\N	\N	::1	curl/8.7.1	2026-03-16 14:57:22.964
52dad471-0f31-4679-a9d5-922bdc829304	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	unknown	2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7	\N	{"id": "2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7", "slug": "default", "email": null, "phone": null, "taxId": null, "address": "Cirebon, Jawa Barat", "logoUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAA0UAAANqCAYAAABCfeBWAAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kb9LQlEUxz9qYZRhUERDg4Q1aVhB1NKglAXVoAZZLfryR6D2eE8JaQ1ahYKopV9D/QW1Bs1BUBRBNNda1FLyOk8DI/Jczj2f+733HO49F6yRjJLVG3yQzeW1UNDvmo8uuOwv2OnGRjOdMUVXZ8ITEeraxx0WM954zVr1z/1rLcsJXQFLk/CYomp54Unh6bW8avK2cIeSji0Lnwp7NLmg8K2px6v8bHKqyl8ma5FQAKxtwq7UL47/YiWtZYXl5bizmYLycx/zJY5Ebi4ssUe8G50QQfy4mGKcAMMMMCrzMF4G6ZcVdfJ9lfxZViVXkVmliMYKKdLk8YhakOoJiUnREzIyFM3+/+2rnhwarFZ3+KHxyTDeesG+BeWSYXweGkb5CGyPcJGr5a8ewMi76KWa5t4H5wacXda0+A6cb0LXgxrTYhXJJm5NJuH1BFqj0H4NzYvVnv3sc3wPkXX5qivY3YM+Oe9c+gY08mfP56nFPwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAIABJREFUeJzs3XeYXVXZhvF7khAIIQGkd5TepEtTQAVBxYoUkSYoKr0JduwVFSwgClLFhgXED6SDdBBEREBApLfQSwghme+Pd8ZMJlNO2Wuvvc+5f9e1riQz5+z1nj1B95PVQJIkSVJKqwEn5y5CkiRJknLYHHgK6AVWz1yLJEmSJJVqZ2AaEYh6gR/kLUeSJEmSytEDHMGsMNTfngUmZqxLkiRJkpIbBxzHnIGov30kX2mSJEmSlNZE4ByGD0S9wI3ZqpMkSZKkhBYDrmfkQNTfNsxUoyRJkiQlsQrwHxoLRL3Az/OUKUmSJEnFWwl4nMYDUS/wErBgjmIlSZIkqUhLAPfSXCDqbwdnqFeSJEmSCrMAcAutBaJe4OryS5YkSZKkYswDXE7rgagXmAksXHbhkiRJktSuscDvaS8Q9bfdSq5dkiRJktrSA/yUYgJRL/DrcsuXJEmSpPZ8meICUS/wDDBXqZ9AkiRJklq0P8UGov62ZYmfQZIkSZJasiOxMUKKUPSdEj+HJEmSJDVtHWAaaQJRL3B7eR9FkiRJkpozLxFaUgWi/rZCWR9IQxuTuwBJkiSpor4HrFpCP+8soQ9JkiRJasp7ST9C1N/OLukzSZIkSVJDlgKepLxQdF85H0uSJEmSRjcWuITyAlF/W7CMDydJkiRJozmS8gNRL55XJEmSJKkCNgSmkycUHVTC59Mw3H1OkiRJgknAmcC4TP2vk6lfSZIkSQLgZPKMEPW3m9N/REmSJEka2lvJG4h6gWnA+NQfVJIkSZIGGwv8nfyhqBd4feLPqmG4pkiSJEndbDdg7dxF9KlKHV3HUCRJkqRuNRH4Wu4iBnCzhUwMRZIkSepWhwJL5i5igNfmLkCSJElS91gCeIH864gGtiuSfmINy5EiSZIkdaMvEdPnqmSR3AVIkiRJ6g5rAjPIPzI0uD2R8kNLkiRJUr/zyB+AhmoziS3CJUmSJCmZt5E//IzUFk730SVJkiR1uzHAP8gffEZqqyX79BqWGy1IkiSpW2wNrJW7iFG42UIGhiJJkiR1i31zF9AAp89lYCiSJElSN1gW2C53EQ1wpCgDQ5EkSZK6wT7U49nXkaIM6vAXQ5IkSWrHeOCjuYto0ITcBXQjQ5EkSZI63fuARXMX0aCpuQvoRoYiSZIkdbo6bLDQz1CUgaFIkiRJnWwNYPPcRTTh5dwFdCNDkSRJkjrZJ3IX0CRDUQaGIkmSJHWq+YDdcxfRJKfPZWAokiRJUqf6EDApdxFNcqQoA0ORJEmSOtUeuQtogaEoA0ORJEmSOtFrgI1yF9ECQ1EGhiJJkiR1oq2o57Oua4oyqONfFEmSJGk02+QuoEWOFGVgKJIkSVKn6QG2zV1EiwxFGRiKJEmS1GnWBJbMXUSLnD6XgaFIkiRJnaauo0QAU3IX0I0MRZIkSeo0dV1PdD/wYu4iupGhSJIkSZ1kPuBNuYto0Z25C+hWhiJJkiQ1awHgHbmLGMaWwPjcRbTojtwFdKtxuQuQJElSrSwK/IU4HHUF4NW85cyhzuuJHCmSJEmSKm4Z4sG9t6/tnLecId3FrPrq1t6a4H5IkiRJKsjKwH3M/hB/I3EmUFUsSf5g005buvhbIkmSJKkIrwceY+gH+S0y1jXYW8gfbFptL1CtgNlV3GhBkiRJI9kEuJxYSzSUw0usZTSr5i6gDXcQ4UgZGIokSZI0nK2AC4nd5oazHdUJI6vkLqANbrKQkaFIkiRJQ3kv8GdgYgOvPTRxLY2qSjhrhdtxS5IkSRWyC7HVdqPrYV5m+Ol1Zfov+dcGtdp2LP52SJIkSWrFW4DpNP9Q/8UMtQ40L/mDTTttzeJviSRJkqRmrQI8TWsP9Q+Rd2nG2sPUVYf2GC5rycqbL0mSJICFiDVEI22qMJIliZ3qcqnzeqK/ADNzF9HNDEWSJEmaG/g9sEKb18m5LqbOoej83AVIkiRJ3awHOIVipoHlnEJ3ZoM1Vq3NBBZJcD8kSZIkNehTFPuQv1m55f/PTU3UWKV2Q4qbIUmSJKkx21P8Q/6xpX6C0AO80GK9udtXEtwPSZIkSQ3YAHiJ4h/yc0yhm7ug2nO0XCNrkiRJUldbBniEznnQn7/A2stszwDjEtwPNcnd5yRJkrrLGGJTgsUT9rFDwmsPZZ6S+yvKhcCruYuQoUiSJKnbHAC8MXEfO1Duc+aEEvsqkltxS5IkSSVbiTTriIZq65f0mSDOKMo9Fa6VtnSKm6HmOVIkSZLUHcYAP6e8UZVNS+oH6jl97p/Ag7mLUDAUSZIkdYcDST9tbqBNSuyrjqHopNwFSJIkSd2kzGlz/e3eUj5ZeHPCz5GivQQsmOROqCWOFEmSJHW2sqfN9VuetDvcDVS3kaIzgadzF6FZDEWSJEmdrexpcwOVNYWubqHo+NwFaHaGIkmSpM61EvD1jP1vXFI/ddqS+3rgb7mL0Ow8QVeSJKkzjQVOJm9gcKRoTsflLiCx8cR6qYFtgSG+1gO8ADzf114Y9Ovgrz1NwoNuDUWSJEmdaU9gs8w1bADMBUxP3E9dQtHTwG9yF1GABYC1+9o6wFrAEkTYmTdRn9OBfwP/GtTuAqa1e3FDkSRJUueZG/hC7iKIUaq1gRsT9/NC4usX5efA1NxFNGEM8DpmBaD+ELRshlrmAtboawPNAO4GbmP2sHQHBYQlSZIk1de+5N92ur8dkPizArw94+drpq2U6gYUZDywNXAscBUxdS33PWu1vQicC+xHBDtJkiR1kQnAQ+R/KO1vZayh2TDj52u0/SXZp2/P/MDOwC+BZ8l/n1K1O4FjgG2oz3RLSZIktehg8j+ADmznpv24QJyJlPtzjtbek+rDt2BpYjTxL8Ar5L83ZbeXgD8D+wMrtHkvJUmSVDETgcfI/9A5sN2S9BOH+TJ+vkbaP8m7lr+H2Azhc8AN5L8fVWu/a/3WSpIkqWqOIP8D5uD2dNJPHHqIDQxyf9bh2rbpPvqI5gU+DtzeQI3d2l4hNpCQJElSB5gETCH/Q+ZQbVLCz93vgYyfb6R2ARHayrQ48FXgyTZr74Z2RIv3WJIkSRX0OfI/YA7XVk/4ufvdlPHzDddmUu4oxFrEgb3TCv4cndouJw45liRJUgdYgJimlvshc7i2TbqP/j8XZPx8w7WTkn7i0EPc3yp+/iq354gNOgAPb5UkSeoEhxLBqKrKOOzziRL6aMZLwOcTXn8e4EPAIcx5oKlGtz/w3/4/GIokSZLqbR7KOSC1HcuU0MeUEvpoxneAhxNcdyyxecIXgEUTXL8bnAWcnrsISZIkFWdH8k9FGq2dkurDD7Bfps82VHuE2Ca8aJtQzbVTdWoPAws1e+MlSZJUbf9H/gfN0drFyT79LG/M+PkGt48U/NkWBX5egc/VCa2M9W2SJEkq0RLADPI/aI7W/pbqBgwwOePnG9hupbgdzcYSI2BV3kSjTu1Lzd1+SZIk1cHh5H/QbKTdlOoGDHJPiZ9puFbUSIRT5Yptp1P+eVGSJElKrAf4J/kfNhtpZYWi35X4mYZqJxbwGZwqV3y7HJi7mR+CJEmS6mF98j9sNtpuTnQPBvt8iZ9pcLuT9jZXGAvsi1PlUvxcXjPazXdLbkmSpHraI3cBTShr2tItJfUz2HRgF+CFFt+/OPBLYMuiChIQ27S/A3gqdyGSJEkq3njigS/3v8I32v6e5jbMYdkSP9PAdngbNW9BbOGd+2fUae1lYNMmfg6SJEmqmfeR/6GzmVbWCE4P5U8/uxAY00KtY4AjqcfugXVsOzX+o4jpc/9t5g1Sh7maGO7uJt8D3p+7CCmjjYDHchchtWmP3AVUVC8xKrVlSf1NAXYHZjb5vgWBU4F3FV6RAD4D/LqZN4wDlktTi1QL9+QuIIOF8b97dbeizg+RclkYeGfuIppU5lbIN1NeKNqLmPrWjPWBs4DlC69GEP/4+81m39TKUJ8kSZLy2ZL6bZZVZii6oKR+fgz8qYnX9wAfI2apLJ+iIHEUs87uakrd/oOSJEnqdlvkLqDiLgNeAuZN2MdtwCebeP0E4ARgtzTlCDgU+H6rb3akSJIkqV42z11AC8ocKXoZuCjx9T8ITG3w9ZOB8zAQpdILfJQ2AhEYiiRJkurkNcBauYuogT8nuu4MYEfg1gZfvxAR0BzdS+NVIqCe2O6FDEWSJEn1sRnljroU5bmS+0sVij7K7OuI5h/htUsQU/k2TFRLt5sGvJcmd5kbjqFIkiSpPuo64nBfyf09RPEHxn4KOHnAn9cmRoKGshxwBbBmwTUovAC8nQLDr6FIkiSpPuq4ngjg/gx9nlvgtY4Bvj3gz2sSo3b/GeK1qwBXAisW2L9meRLYCri0yIsaiiRJkuphErBe7iJaVPZIERQ3inAmcBiztnleCfgG8LMhXrs2MUK0dEF9a3bXAusC1xV9YUORJElSPWxKfQ8fzjFSdAPwRJvX+AvwYWBm35+XJUagPgVMH/TajYk1RIu22aeGdiwxffSBFBc3FEmSJA1vcu4CBqjr1DnIM1I0g9gKu1XXAx8AXun782LETnInEecUDbRh3/cWaKM/De0FYse/g5n1syicoUiSJGloGwL/ZPjF9GWrcyjKMVIE8IsW33cn8E7igRxiK/QLgSnAdwe9djliR7qJLfal4f0T2AD4beqODEWSJElz2gK4GFgG+HjmWgDmAd6Qu4gWPdvXcrgIuKfJ9zwEbEMEIIi1XOcRGyfsSYxA9ZufWLu0WFtVaiinARsRATU5Q5EkSdLs3gmcTzwMAxwAzJ2vHABWAMZnrqFVuUaJINYCndDE628j1m71T/ebAJxDBNJPA/8e8Nq5gLOANdovUwNMI86D2hN4qaxODUWSJEmz7Az8kRiZ6bcY8KE85fzPcpn7b0eO9UQDnUw8aI/mUuCNzApx44nQsyVwOfDDAa/tAY4ntoZWcW4FNgFOZNZuf6UwFEmSJIV9iO2Xxw3xvcOIB+Fcls3Yd7tyjhRBTIMbbU3K6cC2wDN9fx4LnAG8A3iR2XegAzgS2LvYMrvac8BBxJbzN+cowFAkSZIEnySmWQ0XfFYnHppzcaSoPceP8L2vAnswa2ezMcQZRDv0/fkw4N4Br9+JOKdIxTidOPD2B8CruYowFEmSpG7WA3wN+HYDrz0scS0jqfNI0X9zFwBcA/xj0NdmEGtXPs+sqVo9wPeJkSGAC4CfDnjPpsCp6crsKrcSG5rsDjyauRZDkSRJ6lpjiHUin2nw9W8F1klXzojqPFJ0Te4CiNAzcLToBWA7Yu3KQF8BDuz7/XPAR5gVmJYBzib/pht19zxx5tB6wBWZa/kfQ5EkSepW3wX2a/I9uUaL6jpS9F/ggdxF9PkFEYYeIc58On/Q948EPjvgzwcxq/YxwCnAwmlL7HhnEFPljiXjVLmhGIokSVI3+jjxr9XN2hlYvOBaRjMXsFTJfRalMiMBxAjF54GNmXMx/77ANwf8+VxmnyZ3EPCWpNV1tn8SU+V2I0Jp5RiKJElSt3kb8KMW3zsOeH+BtTRiSer7zFalUARwDHPuhrc78OMBf36a2Imwf9rcmrixQqtuBfaiYlPlhlLX/8AkSZJasTqxPfPYNq6xY0G1NKrO64kuz13AKN5PnGM00H7MGs2Ym5jy5Tqi5pxP/OPD2sT9nZ63nNENtQ+/JElSJ1qEmBY1uc3rbE5MoStrx6y6rid6BLgndxEj2Ab4FbMPEvyu72v9vkQ82Gt004gA+X3gtsy1NM2RIkmS1A3mAf4IvLaAa/VQ7hS6uo4UXcGsKWhVsznwB2K9Vr+HgY8xq+bNgSNKrquOphDhcTlit77aBSIwFEmSpM7XQxzGuWmB1yxzCt2SJfZVpKpOnduAGDGcMOBrvcCuwJN9f54MnMbwh/kK7iDWXi0LfBF4LGs1bXL6nCRJ6nSfIx54i1TmFLp21j/lVMWF9esBFwKTBn39m8ClA/78A+o7QpfSk0Sg/BVxsO3MvOUUx1AkSZI62U7AlxNct38K3XEJrt0JngRuz13EIGsTgWiBQV+/DjhqwJ/HAhcD44l1R68ppbrq+g8x9fRs4Goqdr5QUQxFkiSpU63D7GfNFG1HyglFVV2XM5K/Uq1RhLWIoDM44DwP7MLsu6PNAE7va2OBDYG397UN6I4pdTcyKwjdRj3/DjbFUCRJkjrReCIQpdxKuawpdHV8IK3SeqI1iEC00BDf25cYCRnODODavnYUsCix1fTbiVGkoa5ZR9OJ6YN/BM4BHspbTvkMRZIkqRN9Fnh94j56gPcBxyfup256ia2tq2B14BJiO/bBzuhrzXh8wPvGEiNH2wDr9vW1ItXfyGwqcajqLYPa8zmLys1QJEmSOs26wGdK6mtL0oeiuo0UXQw8kLsIYFUiEC06xPf+QxzS2o4ZxHqk6wZ8bW5gZWJ0avUBbSXyPHc/xJzh5y6idg1gKJIkSZ1kPHAK5T3jbFxCH3ULRSnXcTVqZSIQLTbE914FPgg8l6DfacQozK2Dvj6eCEarA6sBCwPzEbvgTRrw+4Ffm2eI608Fnh6lPcOsMDSlsE/W4QxFkiSpk5QxbW6gZYlzhB4usc8qe4E4FDWnFYn1MUsM8/0vANeXVw4ArxAbFjRzsOk4ZoWk6UTgmVZ8aYLqz3mUJElqVJnT5gbaJPH16zRS9BvgxYz9v44IRMMdeHsp8O3yymnLq8SozwPEZh4GooQMRZIkqROUPW1uoNShqE5yTp1bngg9Sw/z/aeA3XA9jYZgKJIkSZ2g7GlzAzlSFO4FrszU93JEIFp2hNfsRRduNa3GGIokSVLd5Zo21299YqQqlbqEolPJc2DrMkQgWn6E1xxPHEQqDclQJEmS6mws+abN9ZsbWCfh9V9NeO0inZahz6WIQPTaEV5zG3BYOeWorgxFkiSpzj5EvmlzA6WcQleHKV9XENPnyrQkEYhWGOE104jtt6eWUpFqy1AkSZLqai7gqNxF9EkZiqpwEOpoTim5vyWIc4hWGuV1hzPnmUHSHAxFkiSprvYgtmCugvUTXvv+hNcuwjPAWSX2txhwMbDKKK/7E/Dj9OWoExiKJElSHc0NfD53EQMsS7rnqqqPFB0NPF9SX4sSgWi1UV73ALHbXF02qVBmhiJJklRHezPy9stlG088sKfwKDA90bXb9STwg5L6Whi4CFhjlNdNBz4ATElekTqGoUiSJNXNBOJcoqpZJtF1Z1LdzRa+RTmjRAsRgWitBl57CHB92nLUaQxFkiSpbj5G7DxWNSlHrqq4rugxylmzsxBwIbB2A6/9JXBc2nLUiQxFkiSpTiYCn85dxDBSjRRBNdcVfQN4KXEfixK7zK3bwGtvB/bBdURqQc6DziRJkpq1H+nW7rSrm0aKHgJOSNzHEjS2qQLAi8D2wAtJK1LHMhRJkqS6mAQckbuIEaQMRVUbKfoa8HLC6y9NY+cQ9dubGCmSWuL0OUmSVBf7EetLqirl9Ll7E167WfcBJyW8/vLAFTQeiH4I/DpZNeoKhiJJklQHPcRoQJWlHCn6W8JrN+srwCuJrr0iEYhe2+DrrwUOT1SLuoihSJIk1cGmxANzlS1OHCqbwhPA3Ymu3Yx7gNMSXXtV4HIaH3GbAuxIuoCmLuKaIkmSVAd75i6gQYuRblOEa8gfDI8kzUGyaxKbKjS6iUYvsAvVW2s1mvmIn+EywDxEiJ570O+H+vM44CngcWIr9McH/X5qmR+iExmKJElS1U0gRgTqIOUsnGuA3RJefzS/BX6X4LrrEucQNbNe7It976miCcAKxJqo/rZy369LJOrzBWYPS48CtwI3AreQdlOMjmAokiRJVfdeYHLuIhrUk/Da1yS89mimAPsnuO6GwAXAAk2853zgqwlqacUywNbE5+gPQMuQ9u/BUObraysM8b1XmRWQ+ts/cdrhbAxFkiSp6vbIXUATUj4M/5M4j2diwj6Gsy8xAlGkTYHzaC7w3g/sCswsuJZGTQbeTAShrYBVMtXRjHHEaNy6wEf7vjaNGEHqD0k3ALfRxQffGookSVKVLUU8gCr+xf8GYMuS+/1tXyvSFsCfaS7gTQd2AJ4suJaRzAVsxKwQtBEwtsT+U5kbeENf6/df4CxiiuT15AueWRiKJElSle1KvXbLTT1t6hrKDUVPEOdDFWkr4Bxi7U0zDiYe1lNblpiyuRVxryeV0GcVLE9sb3448CDweyIkXQ3MyFdWOQxFkiSpqnqo19Q5KCcUlWlfIhgV5R3Ew3azW5f/Aji+wDoGGwe8HfhY3691CuIpLA0c2NceY1ZAuoIYsew43f4DlyRJ1bUhsFruIirm2hL7+g3xIFyU9wJ/pPlAdBsRVlKsd1ma2MnuXmL06p34fDzYYsAniC3THwF+RnM7BdaCI0WSJKmq6jZKBOlHip4gdhJbq4R+itxtbkditKfZZ8+niTD1YoG1jAW2JYKWIag5CxPTCZ/KXUjRDEWSJKmKeoD35y6ios4ifSj6BMVNm9sVOJXmw8cMIkzdXVAdSwJ7Ax8h1g2peXcB+9CBu9SZjCVJUhWtBCyeu4gWlHE+TdE7wQ12BsUd0roXcBqtPXMeClxUQA3rA38gtvP+MgaiVr1M7P73XO5CUjAUSZKkKto8dwEtKiMU3U6cWZTCtcw6y6ZdnwBOorV7chLwwzb7X54IeDcSU/A6YSvtnA4kzjbqSIYiSZJURXUNRWVJMVp0HxEeXi7gWgcDx7X43quIbcBbnaK1IPAd4E7gQy1eQ7M7AzgxdxEpGYokSVIVbZG7gBaVtV1x0aHoeWA7YvvldvQAXwK+3+L7HwC2B6a18N65gUOINUiHA+NbrEGzu4MY9eu4dUQDGYokSdJSuQsYZDnqu+7joZL6KXIK3UxiQ4N2rzcGOBb4Qovvnwq8h+aDWQ+wE3FPvge8psX+NaepxDqiF3IXkpqhSJKk7jWWmGZ0PuWshWlUXafOPUYxU88aVdRo0UHE34F2zEXsMHdAG9fYE7i5yfe8iVgH9SvgtW30raF9gnTr1yrFUCRJUneaTBxWeTiwJrBe3nJmU9epc/eX3F8RoehHfa0dE4jd6nZt4xpfJQ6LbdSKxEGwVwBvaKNfDe8YIuh2BUORJEndZwXgGuAdA7724Uy1DKWuI0X3ldxfu1PozifW4LRjMnAe8K42rnE2cFSDr+0hdse7hZhqpzROBQ7LXUSZDEWSJHWXNwPXA6sP+vouxEL13JYgziiqo7JHigDObPF9twE7097GEIsAl9DeyN4/gd2IdU2jWZg4b+inwLxt9KmRnU0ccNvIz6RjGIokSeoeHwcuYOiF6AsC7y63nCG9KXcBbSh7pAgiIExt8j2PEzvNPdtGv8sQU9fWb+MaTxJ/555v4LXbALfi6FBql9J+WK4lQ5EkSZ1vLmLdyPHAuBFet2cp1YysruuJIE8oehI4pYnXP0hMT/xvG32uDFwJrNrGNV4FPgDcO8rrJhA72p0PLN5GfxrdDUToLHOzkMowFEmS1NleQ6z52K+B124LLJm2nFHVedF8julzEGcCNXKGzF3AG4lDTVu1DvBX2t8y/UDgslFe83riQf3ANvvS6G4n1hg2MmrXkQxFkiR1rmWB64C3Nvj6MbS3g1gRlsvcfztyjBRBhJ2zR3nNP4ipie3U+EbgcmDRNq4BcAIxajmcMcChRCBao82+NLr7gLcBU3IXkpOhSJKkzrQksQh+xSbf92HynVk0L7F4v45eBJ7O2P93R/jetcCWNH8o6kDvINajTW7jGhDrkEYa+ZmPCHjfBca32ZdG9ziwNTGtsqsZiiRJ6jyLABcRW283a1Vgw2LLadgymfotwn00NoUtlauIUcHBLiYeetsJbDsTQWVCG9eAuEcfAF4Z5vuLEyNR27XZjxpzHxGW78pcRyUYiiRJ6iwLAhcCq7VxjW0LqqVZTp1rXS9zjhb9kQgYL7Rx3Y8T236PtEFHI54ndpp7Ypjvr0aMaFXpEOFOdhOwMbGWSBiKJEnqJJOJXbrWbvM6WxVQSyvaXbyfUzuHqBblD8zaze10YAda30msB/g0sfan3emU/TvN/WOY728BXE29Q3Gd/B9xzx/NXUiVtJv6JUlSNUwEzqWY3ds2IdZ2tDPC0Io6PxRfnrsAInwcQxx+exCtH77ZA3wbOLyguvYh1iMN5YPEluKuHyrHCcD+dOE5RKMxFEmSVH/zEFOlijr4dFzftc4r6HqNqutIUS+xpqcKjiceeFtd3zSWeHDeu6B6vgKcPMTXe4AjgG8W1I9G92ngW+Rd+1ZZTp+TJKnexgNnUfyUtxxT6Oo6UnQL8EzuIvpMp/WH3rmBX1NcIDodOGqIr48DjsNAVJbpwIeI+20gGoYjRZIk1dc44BfAOxNcO0coqutIURWmzrVrIrEmaeuCrncJ8BHmfAifC/gt8J6C+tHIngHex+gH5XY9R4okSaqvY4kF7Cm8nvYP6WzGWOq7JfcVuQto0yLApRQXiG4DtmfOrbfHEOuHDETluIVYH3hZ5jpqwVAkSVI97QLsm7iPtyS+/kCLU98ZLH/NXUAbViB2fivqbKpHiINeB08n7AF+QPy9VXpHAxsBd+QupC4MRZIk1c9qwE9L6KfMKXR1nTp3O8OfvVN1GwDXACsWdL0Xiamc9w/xvS8B+xXUj4b3EPBW4JPAtMy11IqhSJKkeplIbKwwsYS+tqb9M2oaNV9J/RStrlPn3k5Mq1qkoOvNAHYEbh7iewcDny+oHw3vt8S010tyF1JHhiJJkuqjB/gJsHpJ/S1LueuK6qiOmyx8GPgTxQbrfYlDQQfbA/h+gf1oTi8AewI7AU/lLaW+DEWSJNXHR4FdS+5z1ZL6qetWwXVaT9QDfA74ObGxRVG+ydDTOd8LnFRgP5rTNcDawKnU97+hSjAUSZJUD+sRC9XLVlYoqqP/AA/mLqJB44iDXb9S8HV/BXx2iK+/hTjzqMjwpVmmAV8ANif+HqrxAkYvAAAgAElEQVRNdd3lRZKkbrIAsV5g7gx9O1I0vPNzF9CgeYFfAu8u+LpXENO2Zg76+urA2cTBwireGcSI3325C+kkhiJJkqqtBzgZeF2m/lcrqZ86hqJTcxfQgIWJ9UMbF3zdO4lDQQfvcDaRCPB13Tijyi4hdpW7KXchnchQJElStR1CrM3IxelzQ7sduCF3EaN4LTGatXLB132c2L1u8KL+HuA4ytsIpFvcBhwBnEc9//GgFlxTJElSda0EfCNzDcsR069Sq9vDXtUXtq9HLMIvOhBNBbYD7h3iex8Gdi+4v272CLG5yjrEzn5V/vtWe4YiSZKqqQc4lmqsyyj6wbruZhLrOqrqbcRW4YsVfN0ZxLbPQ42QvR74ccH9dasXiU0UVgJOBF7NW053MBRJklRN2xFTlKqgjHVFdfpX8AuBh3IXMYzdgT+TZk3PXsT6pMEmEeuI5knQZzeZQZxDtgKxS+CLecvpLq4pkiSpeuYhRomqoox1RXUKRVXcYKEH+BTw9UTXPxg4bZh+T8DRxHY8SIwInUR9tnjvOIYiSZKq5whikXxVuNnCLM8Bf8xdxCBjiTOs9k10/S8zfEjfB/hgon47WS+xTugEYgMFp8hlZiiSJKlalgc+nbuIQYpemzKUuowU/ZrYbKAqJgBnkm6Hwh8BXxzme8sB30/Ub6d6mBgROhG4P3MtGsBQJElStXyP6q3NmFRCH0+W0EcRqjR1biHgHGDTRNc/EziI4QPrfcT5We8FtgfeTIxaaXa9wF+IUaFzcVSokgxFkiRVxzbEgZhVU0YoeqCEPtp1N3B17iL6LE9Mu0o1tfHPwJ7ETnsjeZTYHOAnxEGx7yEC0lbAXIlqq4u7iA0ofgb8N28pGo2hSJKkahhPrAuposkl9PEc8Cwwfwl9taoqZxNtRIwQLZro+n8FdgCmN/m+KcTUsJOABYB3AR8gwv7cRRZYUU8CF/W1C4mRNNWEoUiSpGo4mOru4FXGSBHEaFFVQ9HzwPG5iyDCymmkm2L5dyLMtLtu6hng9L42CXhnX9sAWIXYta7uphEB8kIiCP2d0UfWVFGGIkmS8luMOKyxquYl1orMSNzP/cCaifto1ffJu+4p9ZbbAP8mRnWeLfi6zwO/6msQI4/rEQFpA2BDYm1S1fUSwad/JOhKqrXphtpgKJIkKb99gYm5ixjFfBT/sDxYVdcVPUPeXdbGAz8F9kjYx4PA24DHE/bR7zngsr7W7zXA+swKSRsAy5RQy1AeJtYD9bd/9/16D/ByppqUmKFIkqS8JpDufJkiTSZ9KKrqFsVHE8Eoh4WA3wFbJOzjSSIQ5VwD8xQx+nLhgK9NIkZRFx3QFhvm9wsNcc1XiCluQ7WX+9p9zB587gZeKPSTqRYMRZIk5bUrsWtX1XXrDnRPkm8DjJWIXeBWStjHC8C2wO0J+2jV833t7gZeOxexHm06EXpewfU9aoKhSJKkfMYAh+QuokFlhKIqjhR9k3gwL9sWwO+JaWWpTAPeDdyYsI+yTCd2v5NaMiZ3AZIkdbFtgNVyF9GgMrblrtpI0aPAcRn63YOYRpYyEM0AdgIuTdiHVBuGIkmS8jk0dwFNKGMq0oNU4xygft8AXiqxvzHAV4FTSH/w6d7A2Yn7kGrDUCRJUh6vB7bKXUQTytho4BViwXsVPEjs+FaWCcAvgc+W0NchxEG0kvoYiiRJyqNOo0SQfue5fteU1M9ovkZ52y8vRkxj27GEvo4CjimhH6lWDEWSJJVvCWCX3EU0qawtqasQiu4Ffl5SX2sC1wEbldDXl/uapEEMRZIklW8/0q8ZKVpZI0XXltTPSPYhpvKltg1wNbBcCX19HfhiCf1ItWQokiSpXBOAT+QuokkvEVsel+E28myB3e8E4KIS+vkEcQZRGVudfwv4HNXaxEKqFEORJEnl2oa0Wy2nUNYoEcRW0deX2N9A9wNHJO5jLPB9YqvvsYn7Avgu8GkMRNKIDEWSJJXrvbkLaEFZ64n65VpXtDfwXMLrzwf8ETg4YR8DHQN8EgORNKpxuQuQJKmLjAPelbuIFpQ5UgR5QlHqaXNLA38C1knYx0A/JHY4NBBJDXCkSJKk8mxG/abOQfkjRdeV3N/9xIhKKpsAN1BeIDoOOAgDkdQwQ5EkSeWp49Q5KD8UPUm5h7juTbrNHT4MXAYsnuj6g50AHICBSGqKoUiSpHL0AO/JXUSLyp4+B3BVSf2kmjY3F3Ascd7R+ATXH8qJwL7AzJL6kzqGoUiSpHKsBbw2dxEtyhGK/lhCH/eRZtrcQsD5wIEJrj2ck4GPYSCSWmIokiSpHHWdOgfwnwx9XkD684pSTJtbi1g/9JaCrzuS04CPYiCSWmYokiSpHHWdOgdwS4Y+XwbOSXj9zwMXF3zN7Ymd88ocEfwFsBdxvpOkFhmKJElKb1lgvdxFtKgXuDVT379JdN3Tga8VeL0xwJeAs4CJBV53NL8C9sRAJLXNc4okSUqvzqNEdwMvZuq7fwrdpAKveSUx1ayo3dkmESGr7J/xb4HdgFdL7lfqSI4USZKU3rtzF9CGHFPn+hU9he4/wPuAaQVdbwViulzZgej3wIcwEEmFMRRJkpTWGGDj3EW0IWcoguKm0D0LbAdMKeh6WxMbKqxR0PUa9Qfgg8D0kvstwrzAcsCawIrA0sROfROBsRnrkpw+J0lSYq8F5stdRBtyh6IiptDNAD4A3F5APT3AwcDRlP+Py2cSa4iqFIheQ/wdXwRYdJRfR1tv9SowlRghfHnA718gRvn+3dfuBO4i37ROdSBDkSRJaa2du4A25Q5F/VPoPtTGNfanmANa5yEOe929gGs160Tg4+TdVGEysWHIBsCGfb++rsDrjyPC71ABeNMhvvYQs4LSwHYv1QqOqgFDkSRJadU5FD0DPJC7CGIKXauh6BjgJwXUsBSxlucNBVyrWccCh1Dc5hCNmBdYlwg+/W0VYqSsKpbqa28e9PVXgKuBC/vaTbhDn0ZhKJIkKa06h6JbKPdBfDjnEeFsmSbfdy5weAH9b0wEoiUKuFazvkacqZT65zAO2JI4a2kzYq1UXdeejyc+y5bE/XsauIQISBcB9+QqTNVlKJIkKa26h6IqmE6MlhzdxHsuB3ah/RGCDxMjTePbvE4rPg18M+H1xxGjLDsQu/ItnLCvnBYkwt72fX++l1kB6WLgqUx1qWJ6bbYubkWfZl4Hp5H/vttsOduSlGf+hJ+jjLZX8bekZZOJHeQaqftcYEKb/Y0jpt7luvcHtFn/SJ9ra+BnxE58uf+O5W4zgauAvan3hihqU12HRSVJqoO1chfQphtzFzDAc8SD/Gh+RYx6TG2jr0WAvwAHtXGNVvUSD+g/LPCacwFvI+7fo8SOfh8htsPudj3EJg4nAg8TG2msn7UiZWEokiQpnTpPnbsfuDV3EYP8gJGnw50A7Ep7O49tRCzMf0sb12jVq8SUv58XdL0VgB8DjxAhzyA0sknAPsQ/BtwEfIIY7VUXMBRJkpROnUPR2cSoRZXcD/x6mO99m3iIbXUNUQ+wL/BX4lDRsr1CrHn5VQHXej3wS2J76n0xCLViXeA4YvToZGI0qUo776lghiJJktKpcyj6Y+4ChvHdIb72GeBIWg9xE4HTiVGVuVq8RjumAtsR5zG1YzNiPdUtwM74nFeEeYkDc68iRk4/kLUaJeN/LJIkpTGW+q4peoYYMamim4DLBvx5P+AbbVxvZeBa2jscth3PA9sQu6G1ogfYltht70rgnQXVpTktQXV2ZFTBDEWSJKWxFO3vgJbLubS3Lie1o4lpcrsRU5xa9X5i/ciaRRTVgqeItUutBNCxwI7A34hznDYvsC7NaTqxgcdduQtRGp5TJElSGgvmLqANZ+cuYBTnAVsx+4hRM8YBXwc+WVRBLXic+AzNbmYxngiDRwIrFV2UhrUXcEXuIpSOoUiSpDQWyF1Ai6YRO5VV2UxaD0SLE5s15BxZeRB4K7ERQjO2BI4HVi26II3oy8AZuYtQWk6fkyQpjbpu5Xsxsc6lE72RWJOUMxD9B3gTzQWiRYBTgUsxEJXtTOCLuYtQeoYiSZLSqOtIUVV3nWtHD3AIMbq0RMY6/kUEov82+PoxxEGudwC7J6pJw7uKuP9V25peCTh9TpKkNOo4UtQL/Cl3EQWbBJwE7JC5jiuB9xCbKzRiDeAnxOiWyncP8F7g5dyFqByOFEmSlEYdR4quBR7NXUSBVgeuJ38g+iPwNhoLRPMSW4z/HQNRLk8RW5tPyV2IymMokiQpjTqOFP0mdwEF2okIRLnX4JxAHPg5tYHXvh24DfgUzubJ5XHgzcCduQtRuQxFkiSlUbeRoueBk3MXUYDxwDHAr4CJmWv5AvAJ4kylkYwDvgP8H7B84po0vAeJNV//yF2Iyue/QkiSlEbdRopOBJ7NXUSbliJGuzbNXMdM4GPEPR1NFbYIV6wh2orGN8FQhzEUSZKURp1GimYCx+Yuok1vJkaHFs1cx1Ri6l4jG1a8iQhxiyetSKP5F7A18HDuQpSP0+ckSUqjTiNFZwH35S6iRWOINTgXkT8QPUUcyjpaIOoBDiXOHTIQ5XUzcSiugajLOVIkSVIadRop+l7uAlq0GHAasbNbbvcD2xBnCo1kMvBzYPvkFWk01wDvAJ7JXYjyMxRJkpTG+NwFNOhq4LrcRbTgrcAZVGOk5VZgW0YfbVgT+B2wcvKKNJpLiHOjXshdiKrB6XOSJKVRl4etuo0SjQO+ClxINQLR5cQmCaMFou2J8Gkgyu80YDvq89+oSuBIkSRJaTyfu4AG3EscLFoXywBnUp1DTc8CdgNeHuV1ewIn4T9G5/YKcADwM6A3cy2qGP/jlCQpjedyF9CAYxj9DJ2qeDfwd6oTiH4I7MzogWg/4vwnn7nyug/YDPgpBiINwf9AJUlKo+ojRc9Sj8Na5ybC29nAazLX0u9TwEGMHiiPBH6UvhyN4nxgfeDG3IWoupw+J0lSGlUPRSdQ/RpXJA42XS93IX1mAHsDp47yuh7gy8DnklekkfQCXyTWoM3MW4qqzlAkSVIaVZ4+9wTwjdxFjOKDRHCblLuQPi8BHwDOG+V1PcB3gUOSV6SRPAXsAvwldyGqB0ORJElpVHkU5kiqezbLvMAPiBGZqniUWNN0wyivGwscD3w0eUUayQ3ADtT3QGJl4JoiSZLSqGoouo7Rp3/lsibxQFulQHQL8AZGD0TjiK2eDUT5vAR8kthQwUCkphiKJElKo4qhqBfYn+qtr+ghwsQNwOqZaxnoT8Rudw+M8roe4DhiupbyOAdYDTgamJ65FtWQoUiSpDSquKboZ1RvB67JwC+JrZLnyVzLQN8F3kdjB3wejiNEuTxI/JzeA9yfuRbVmGuKJElK48ncBQzyNPDZ3EUMsgGxu9zrchcywKvAvkSAbMT7gW+lK0fDmAEcCxxFY8FVGpGhSJKkNP6du4BBPgtMyV1Enx7gYCJMzJW5loGeIXaYu7jB128InEF8HpXneuBjxGG+UiEMRZIkpfFfYBpx+Ghufyemp1XBwsShsdvlLmSQe4ia7mjw9csRa44mJKtIgz1FnP30U0Y/OFdqimuKJElKYwbVGS3an2o8RG4L3Er1AtEVwEY0HojmB84FFktWkQZ6GDiMCKLHU42/y+owhiJJktJp9CE7pdOAqzLXMAH4IXHw6eKZaxnsFGBrGl8DNhfwG2L7cKV1N7GBxeuA7+HaISXk9DlJktLJHYoeBY7IXMN6xLqb1TLXMZRPE+uaeht8fQ8R7t6WrCJBnA31DeAsHBVSSQxFkiSlc3vGvmcCOwOPZep/LLFV9Veo1mYKAFOBXYHft/Des4AFiW2gq/a56u6vRBg6n8aDqlQIQ5EkSenkHCn6LHB5pr6XJ6btvSlT/yN5BHgX8LcW3tsLXNTXFgF2J6Z3rVJYdd3pz0QYyj3NU13MNUWSJKWTa6OFc4FvZ+i3hxiBuYVqBqKbgTfQWiAa7AnigNfVgM2B04GXC7hut3gIOAZYh9h4w0CkrAxFkiSl8yJwf8l93gfsQUyfK9OCwC+JcDC55L4bcTYRXh4s+Lq9xLSv3YElgQOJHfY0pweJILQZsCxwCBGgpewMRZIkpVXmFLrpwI7EeS5leisRBHYqud9GfQfYnvS7lz1NbMSwNrAxcBxwV+I+q+5B4PvApsSW2ocAV1N+aJdG5JoiSZLSuonydis7FLi+pL4A5gG+1tdvFb0C7AucVHK/vcB1fQ0iDGwNbNXXFiq5nrI9QGxI8VviHhiAVHmGIkmS0roI+FQJ/fwG+HEJ/fRbC/hF369V9DAxOnRt7kKIKY0n9rUxxEjS1n3tTcDc+UorxIPAjcANwKUYhFRDhiJJktK6GphG2gfffwMfoZxtjMcABxO7hY0vob9WXAnsQJzTVDUziQ0fbiY2w5hArLHZGtgEWInqHXA70ONE+LlxQKvifZaaYiiSJCmtqcRD+lsTXv8DwPOJrj/Q0sCpwFtK6KtVPyam872Su5AGTWXWNt/95ifC0cpDtEkl1TWd2GHvNmaFnxuIUSHPEFLHMRRJkpTeRaQJRdOJQFTGbmc7AicAC5TQVyumAR8HTslcRxGeZVYQGagHWIxZAWlZYl3XhEG/Dve1uYhNOJ4gRnxG+vVZDD/qIoYiSZLSu4iYblakGcAHgf8r+LqDzU/sqLZb4n7a8QDwfuYMEZ2ml5iq9ihwReZapI7iltySJKV3M/BMgdfrJc4i+l2B1xzKlsQ5MlUORJcDG9D5gUhSQoYiSZLSmwFcUuD1Pkrs/JbKfMCPiJ3ElkvYT7uOITYoeDx3IZLqzVAkSVI5Lhr9JQ05kLTn7mwJ/APYL2Ef7XoZ2JU4CHR65lokdQBDkSRJ5SgiFB1JrO9JYeDo0GsT9VGE+4BNSTtSJqnLGIokSSrH3cB/23j/l4hzbVLYkuqPDgFcTKwfujl3IZI6i6FIkqRy9NL66MZ3iFBUtInEyFPVR4cg7sG2wJTchUjqPIYiSZLKc0oL7/khMW2u6DNjtiBGh/Yv+LpFewnYGTgCeDVzLZI6lKFIkqTy3A1c2eBrZwKHAQdRbCCaCPwAuAx4XYHXTeE/wCbAr3MXIqmzGYokSSrXyQ285jlgO+B7FBuI+keHDijwmqmcD2xI1CtJSRmKJEkq12+JKWHDuQfYGDivwD7rNDrUC3yNCIVPZa5FUpcwFEmSVK7ngbOG+d4lwBuA2wvsb3PqMzr0BLGZwueIA28lqRSGIkmSynfKEF/7MREIihodmQgcC1xO9UeHAK4A1gEuyF2IpO5jKJIkqXyXM+vMohnAvsQucNMLuv7mwC3AgQVdL6Ve4KvAW4GHM9ciqUsZiiRJKt9M4FRiVGhr4PiCrjtwdGiFgq6ZUv90uc/jdtuSMhqXuwBJkrrUScDpxMYKRdii75p1CEMQ0+U+iKNDkirAkSJJkvJ4gGIC0WuAE4md5eoQiJwuJ6lyHCmSJKmeeoCdiOlyi2aupVFPALviZgqSKsZQJElS/SwPHAe8PXMdzbgc2AVHhyRVkKFIkqT6GEecN/RVYN7MtTSq/zDWL1G9zRTGAgsDiw1qCxI7Ab4MTOtrQ/1+4K8PAM+UW76kohiKJEmqh3WBnwHr5y6kCbmnyy1NHIa7InMGn8WIQFTk+uopwL+Buwb82t9eLLAfSQUzFEmSVG0TgS8ChxAjG3VR9nS5ycCGRAjqb0uW1He/hfvapkN872FmD0zX9bVXSqtO0rAMRZIkVdc2wE+INUR1UcZ0ufHAWkTw2ajv11WJzSeqasm+tuWAr71I7Bp4UV+7jbh/kkpmKJIkqXoWBb5PjLTUyRPAh4ALE1x7KWAHYHtiRGjuBH2UbSLwzr4G8ChwMXH/LgYezFSX1HUMRZIkVUcPsCfwXWKxf52kmC63KBGCdgI2p9ojQUVYnAiVH+r78x3ECNKFwF+ITR0kJWAokiSpGlYCTgDenLuQJr0KHAV8C5hRwPUWBN4H7Ay8hXqtoyraqn1tf2ITh9OIg3pvz1mU1ImK3HFFkqSqe4XYarlKxgOfBW6lfoHoLmJTga/TXiCaRIyO/Al4DDgJ2JruDkSDLQwcCvwLuJIYUZyYsyCpkxiKJEndYDpwPLE18xOZaxloE+BvxLlDdVsj81Nim/AbWnx/DzEl7izgceAMYDtgrkKq62ybAScTUxWPB9bLW47UGXptti5uF9N9TiP/fbfZymrTiYf35aiWycCPgJnkv0fNtieA97Tx2XuI8HNVBT5LJ7WbgE8A8zf+o5DUz5EiSVInmkH8S/oqwD7AfXnL+Z8eYq3M7cB+1G/jgPOJrbDPbuG944APArcQ0+SGOstHrVsXOA54BPgBcTitpAYZiiRJnWQmcDqwGrAX8J+85cxmDWJ0+peUf6hou14GDgDeQWwb3Yx5gI8BdwJnEqFK6Uwgflb3EGdFTc5bjlQPhiJJUifoJcLGGsDuxAYAVTEJOBr4O/XbSAFiZGcDYrpfbxPvmwQcTgTTnwCvK740jWAi8AXi/h9ChFNJwzAUSZLq7rfE6MMuxLkuVdFDTBe7AziM+h2D0UuEuY2A25p43zhipOI+4DvAEsWXpiYsBHwP+DfwYer391AqhaFIklRXvwfWBnakuYf2MqwBXEJMF6vbVDmAB4GtgE/S3IGhGxO70f2A+h0+2+mWAX4O/AN4L/VbzyYlZSiSJNXNOcQWxNsTD3hVMnCq3JZ5S2nZb4DXE6GuUQsBPwOuAdZJUZQKsxrwB+JntWXeUqTqcAhVklQX/wd8kdbPxUmpf1e571Lf6WLPA/sTG1U0unZoDDEl61tEMFJ9rI871En/YyiSJFXdBcBRwLW5CxnGGsCPgS1yF9KGq4DdgHubeM86xBbQmySpSClNJUZaz8tdiFQVTp+TJFXVJcCbgG2oZiCaTIwM3UJ9A9EM4PPENKpGA9Fk4BjgbxiI6ug54G0YiKTZOFIkSaqaK4iRocsy1zGc/l3ljqa+U+UA7gY+BFzfxHvWI3b7c3vtenqC+EeGm3MXIlWNI0WSpKq4GHgLMWpxWdZKhrcmcCnwC+odiH4IrEvjgagH+DhwNQaiunoAeCMGImlIjhRJknL7E/A14LrchYxgMrHJw4HA2LyltOUeYC9iNK5R8wEnEOdAqZ7uBLYmgpGkIRiKJEk59BLTsL5OrMmpqh4iDBwNLJ65lnb0EmcHfRZ4sYn3rUn8nFZNUZRKcTOwLfB47kKkKjMUSZLKNAM4A/gmcEfmWkazIfB9YLPchbTpbmJ06K9Nvm8P4HhgQuEVqSxnEz/HZ3MXIlWda4okSWV4BfgJsBKwJ9UOREsDpxHrbeociHqJXeLWprlANC9wEnAKBqK6ehU4DHgfBiKpIY4USZJSeolYj/Jd4KHMtYxmIvBJ4AjqHwbuIg5VvarJ9y0N/Bl4feEVqSwPAjsRm2JIapChSJKUwnPAj4iRiicy1zKaMcTW1N8AlspcS7t6iSl/nycCaTNWAi4Eliu6KJXmfOIQ3im5C5HqxlAkSSrSk0QQ+hHwTOZaGvFGIkRskLuQAvybGB1qZYRgbeAvwGKFVqSyzCSC8Df7fi+pSYYiSVIRHiV2aDsBeCFzLY14LfAtYIfchRSgl5ie+AVgagvv35SYMrdAkUWpNI8ShwlflrkOqdYMRZKkdtxP/Ov0ycDLmWtpxGTgM8DBwNyZaynCncTo0DUtvn8b4A/Ufw1Vt7oY2JUIRpLa4O5zkqRW9C/kX5HYtrnqgWgs8FGi7iOpfyCaCXwHWJfWA9EOxMG5BqL6eYxYO7Q1BiKpEI4USZKa8Q/iwNWziDOH6uCtwPfonB3V7iAC6bVtXGNv4Kf4j6N1MxM4jlg/VIc1e1JtGIokSY24iBiZuJBYw1IHKxPrnN6Vu5CC9I8OfZH2RubeBZxYREEq1fXAJ4CbchcidSL/hUiSNJwZwJnAesQ0nQuoRyBakNhR7jY6JxDdTmyI8Cnan6p4LvAO4JZ2i1Ipngb2ATbBQCQlYyiSJA32IrGt9grE+T035y2nYXMBBwB3ExspdMJsiGnErnLrAtcVdM1e4Dwi7O4C/Keg66p4PwdWAX6GW21LyfXabF3cLqb7nEb++26rZnsE+DQx0lInPcB7iNGU3PewyHYxMQUwtfHEtKxHSv58tpF/9puO9EOTVLzc/+HbbDmbochmizCxN/XckW1z4rDS3PewyPYEsbNYT4H3qRETie3Kn22jdlt77Q/ARqP9oCSlkft/AGy2nM1QZOvmdgWx5qaOU6nXItbG5L6HRbeTgIUKvE+tWAj4NnEQbO770Q3tVeJ/l9do5IcjKZ3c/2Ngs+VshiJbt7WZxHbadf3X6OWJv8MzyX8vi2x3AFsUd5sKsTSxlfkU8t+fTmxTgR8Rf6clVUDu/1Gw2XI2Q5GtW9pU4nyTFamnRYjNH6aR/14W2fo3Uqjy1MW5gZ2YtR27rb32LHHW12LN/BAkpZf7fxxstpzNUGTr9DaFONdmEeppPiI0PEf+e1l0u4RyNlIo0uuArwEPk//+1anNIP7/Zh9g/qbvuqRS5P4fCpstZzMU2Tq13Q3sC8xLPY0H9gceI/+9LLpNAXan/I0UijQOeDdwDvHAn/ueVrVdSfw9Xry12yypTLn/B8Nmy9kMRbZOa9cCHwDGUk9jgA8C95D/XqZoJwMLF3a3qmEp4LN07s+s2XYDcBiwTDs3VVL5cv+Ph82WsxmKbJ3QXgHOAN5AffUA2wA3kf9+pmh3AFsWdbMqqgdYiTjz6HfA0+S/72W1W4jtzFdo+y5KyqITTvuWpG71OPCTvvZI5lra8Qbgm8CbcxeSwCvEovpvEpsqdLJe4K6+djwxWrkesBWwNbAZMS2yEzwEXN/XzgH+lbccSe0yFElS/dwEHAv8mno/aK9CLNrfPnchiVwGfBy4M3MducwgppLdAHyDWN/2RiIkbQWsm6+0pjxPfMMoLs0AACAASURBVIbrB7SHslakZmxCjOCdkbsQVZuhSJLqYQYxJekHwNXEv8rX1VLAUcBe1Hft00ieJNaU9E9VVXgJuKCvAUwmptut3Pdr/+9XBhbIUSBxkOotzB6A7iDOxVK9zE+E8Y8To7XSiAxFklRtTwI/JaYjPZC5lnYtChxB7Io3IXMtKfQCPyM2HZiSuZY6eA74W18bqAdYiDkD0+uAicA8xNlJcw/4/WjPM08TOxmO1h6l3qOvir8/7yMOxl0icy2qEUORJFXTrcQUuTOJg1frbBHgk8B+1HeL8NFcAxzAnA/4al4vESqnEPe1EWOZFZQGhqUXibV3rxRfpipoaSIMvSd3IaofQ5EkVcdMYtH2scDl1H/q1cLA4cQ5LRMz15LKo8To1y9wilVOM4jpeS/lLkRZjCVGoL9OHPgsNc1QJEn5PQOcCBwH3Ju5liK8hlhTcyCd+4DyKnAM8BViGpikPN4MHE3sdCi1zFAkSfncTmyccDoxzafuFgQOBQ4CJmWuJaW/AAcTC/Al5bE68G3gnbkLUWcwFElS+f5MTJG7iPpPkYPYKewQIihMzlxLSvcSn/McOuPnJtXREsCXgL2BMZlrUQcxFElSOaYAJxM7yd2duZaizE+MCh3a9/tONZVYq3A08HLmWqRuNR+xRvFwOneNojIyFElSWlcAPwF+T+ds9TuZWC90GPnOkynLb4id8+7PXYjUpcYRZ5p9CVg8cy3qYIYiSSres8CpwAnAvzLXUqRJxLbThxGbKXSyfxLB79LchUhdajywG/ApYMXMtagLGIokqTjXE6NCv6aztgaejzhj6JPEoZqd7BngC8Rhua9mrkXqRhOIkaEjgWUy16IuYiiSpPa8SJxRcwJwU+ZaijaROPvjCOLMoU7WC5wEfAZ4InMtUjeaD/g4sWZoscy1qAsZiiSpNf8gRoV+QeedUzOJWQ8ni2aupQzXEtMCb8xdiNSFFiD++zuYzp+WqwozFElS414mpsb9BLiOztuWeWFiHc0BdP4GCgCPEVN0TgdmZq5F6jZLAvsTU3M7eSt/1YShSJJG9//s3XeYZHWZt/G7J8KQYRDJOYgiQZQgIgooQUkigpKjOey67uqa3lXXnN01rdJkFMyAIIKKmAAlSJSggEqQzJAm9fvH0233NN2VuqqeE+7PdZ1rZuim6svQXV3f8zvn+d1EFKGTgQeSs/TCWsTwhOOBOclZ+uFJ4LPAx6jeKp9UZAPAjkQZOhDfh6pA/GKUpIktIMZofwX4BdVbFQLYmFgpORyYmZylH4aIVaH3AncmZ5HqZGngYGIVeuvkLNKELEWStKS/EEMTTiQur6qirYB3E2dq67Ij/MXE9LyqDcOQimxd4A3AsVR/cqVKzlIkSXE51dlEEfo51b2/ZCdiutqe2UH66HqiDP2Yaq72SUUzALyUuERuH+pz4kUlZymSVGe/A75JDE94ODlLrwwAexBlaKfkLP10D/A+oui635DUe2sTm60eAWySnEVqm6VIUt3cQwxMGCRWEapqOvAq4jK5rZKz9NPjwKeATwLzkrNIVbcscABRhF5CnISRSslSJKkOFgLnEKtC5xNDFKpqFnG29t+JQQp1MUT8/30/8PfkLFKVTQNeTBShA4lNnqXSsxRJqrLriDfKpwL3JmfptWWA44gNV9dMztJv5wPvAv6YHUSqsI2JInQYsE5yFqnrLEWSquZh4HTiXpIrqP7N9SsRNzS/jfpNd7qGKIEXZgeRKmpDYH9iRWi75CxST1mKJFXBEPBTogh9H3giN05frE8UoWOI6/rr5G/EXkOnAIuSs0hVMgA8m7hP6ABgy9w4Uv9YiiSV2Z+JInQScEdyln4YAHYA/oU4e1u3UbfzgI8BnyUGKkiaugFgW2IwywHU615E6Z8sRZLK5gliT6FvApdQ3T2FxppBvFn5F+p5Ccsi4GvA/6O6G+pK/TSdGNE/siK0Vm4cKZ+lSFIZLAYuAk4Dvgc8khunb1YgLo97G/W9sflHxCS9G7KDSCW3HrA78DJgV+J+REnDLEWSiuxyogh9C7g7OUs/rQe8FTgWWC43SpqLiPuGfpsdRCqp5YFdiBL0MrwsTmrIUiSpaG4hitDpwJ+Ss/Tb9sQlcq+ifvcLjfgt8J/AxdlBpJKZTtwb9DJiRWgHfJ8ntcxvFklFcA9wJlGELqf6Y7THmgHsR5ShHZKzZLqaWBk6l3r9/5c6NRvYhnjdeCHwErwkTuqYpUhSlnnAd4lVoYuBhblx+m554GjifqH1cqOkugl4PzE8ow5DMzKsDKwBXI9/x2W2OlGAdhz+dVtgVmoiqUIsRZL6aSHwY6II/Yh6jlVeF3gLcBxRjOrqduCDwKnUrxD326bAr4GHgF8Blw4fVwBPJubS5GYAz2W0AO1IvU+eSD1nKZLUD5cSRegs4P7kLFleQFwidyBx7X9d3QV8GPg/YH5ylrpZEdh7+ID4+7+C0ZL0a+r7/ZlpeeA5RAnaYvjXbYA5maGkurEUSeqVa4kidAaxKlBHs4mhCW8izvTW2QPAR4H/pZ4rhEU0i/i63BF41/A/u54lV5JuARakpKueGcQEuLHlZwtcAZIKwVIkqZv+TKwGnQZck5wl0zrACcRI7WckZ8n2KPBp4LPUZ3+pMtt8+Dh++M8LiWJ0w7jjRuCxjIAFN0Dcw7X+mGNzogBtTpwokVRAliJJU3ULUYTOBq6kvpPDphEbIr4JeCX1Hak94gngi8An8JKsMpsBbDZ87D/uY3ewZEka+f19VPt1YBmWLD3jj7ruLSaVmqVIUiduYrQIXUO13wA1syJwBPBGYJPkLEWwAPgq8N/E/UOqrnWGj5eP++fziTH7d485JvvzvH6FbWAasAIwd/hYdczvxx6rEZe61X31V6okS5GkVl3PaBG6jnoXIYAtiVWh1+EN0RCjngeB/6K+95ApzALWHj6aeYwoR/cR95o92eaxmLgkbVabv67IaNlZhXoPP5GEpUhSY38kitB3iFJUd7OI6XFvJDZLVJTjbwMfIFYQpXYsA2w4fEhSGkuRpPGuYrQI+SY3rE0MTjgOL50ZsRg4E/gIFmZJUslZiiQB/J7RInRLcpaiGGB0cMI+ODhhxCLgFGK89p+Ss3TiWcSAACenSZL+yVIk1ddlxP1BZxOjtBVGBie8Adg0OUuRLABOBD5GOb9engO8FzgIWAtLkSRpDEuRVD/fAN6HN8OPtyVxr9ChODhhrKeArxOjte9MztKJLYmv91dlB5EkFZelSKqfX2QHKJDlgUOITVa3Tc5SNI8DXwE+RTlHa29DlKH9soNIkorPUiSpbgaIyXHHAq/GVaHx5gFfAj4D/CM5SyeeD7wfeEV2EElSeViKJNXFasDhwDF4r9BEHgY+P3w8kJylE9sTZWjP7CCSpPKxFEmqsunAy4hVoX3wNW8i9wOfJVaHHk7O0okXEmXoZdlBJEnl5RsESVW0HnA0cBQxaUxPdw9xv9BXiEvmymZnYsPYl2YHkSSVn6VIUlXMJm6qPwbYjbh3SE/3d+DjxES5J5KztGsA2IUoQy/OjSJJqhJLkaSyew5RhA4DVknOUmS3E3sMnUiM2S6TAaLovh/YKTmLJKmCLEWSymg54DXEvULbJWcpupuJMnQKsQFrmQwALyfK0A7JWSRJFWYpklQWA8SEsWOJQrRMbpzC+w2x4eoPgcXJWdo1AOxFlKEXJGeRJNWApUhS0W0IHDp8bJScpQx+AHwS+FV2kA4MAK8kytDzkrNIkmrEUiSpiFYGDiLuE9oxOUsZzAdOBj4N3JicpRMzgYOBdxH3iEmS1FeWIklFMRvYmyhCexNvlNXYQ8D/Al8E7k7O0olliCEZ/wqsk5xFklRjliJJmQaIlaDDiJWhlXLjlMYdwGeAb1DOPYbmAm8ePpwYKElKZymSlGFjoggdCqyfnKVMriLuFzqL8k2SA1iXWBU6BpiTnEWSpH+yFEnql7nE1LjDcIx2u35ClKGLgKHkLJ3Ygrhf6BBgenIWSZKexlIkqZeWIqaJHQbsia857VgEnAF8Crg6OUsnBoAXAf9OjNeWJKmwfIOiOlsM/CU7RAVNA3YiitCrgRVy45TOPODrwOeIe4fKZhqwD1GGtk/OIklSSyxFqpMngd8Bvxw+fgM8mpqoOgaALYlhCa8l7h1Re+4GPg98FXgwOUsnZgGvIy6T2yw5iyRJbbEUqcoeBi5ltAT9HngqNVG1DBD3ihw0fGycG6e0biTuFzqNcn59LgccD7wDWDM5iyRJHbEUqUruYrQA/RK4lrgvQ931bEaLkCsCnTsP+AJwIXEpZ9msBrwVeCOwYnIWSZKmxFKkMruZJUvQbZRzMlcZPIvRIrR5cpYyexQ4Efgf4E/JWTq1AfBO4ChikIYkSaVnKVJZDBETuMaWoLtTE1XfJowWoS2Ss5Tdn4AvAScBjyRn6dTziT2GXk0MU5AkqTIsRSqqR4DLgcuIAvRr4h4h9dZGjBahLZOzVMGPiUvkfkI5L5GbAewPvB3YMTmLJEk9YylSESwkVoEuI6bDXQbcRDnfRJbRBsTZ/4OAbZKzVME84hK5L1HeS+RWAo4F3gKsnZxFkqSesxQpw22Mlp/fAVcBT6Qmqp91iSL0GmDb5CxVcTPwRcp9idxmxPCEI4A5yVkkSeobS5F67QGWXAG6DLgvNVF9bQLsBxwAbJecpUrOJy6Ru4Byrm4OALsTl8jtmZxFkqQUliJ101PAlSxZgm7FiXBZphE3x+83fDg+u3vmAYPEJXI35Ubp2BzgUOBtOFFQklRzliJ1aiFwPXHp20gJugaYnxlKzAZeQpSgfYDVc+NUzi3EJXKDlPcSubWIvYVOAFZOziJJUiFYitSKh4nycxUxEOEqohA9lRlK/7QCsBew7/Cvy+XGqaQLiEvkzqecl8hBXDL5duBAfO2XJGkJ/mDUeH/h6QXodrwErmjWJFaC9iNWhmbmxqmkecTQhC8BNyZn6dRM4h6ytwPbJ2eRJKmwLEX1NR+4jiUL0NXAQ5mhNKkB4FmM3h/0/Nw4lXYl8FXgdODR5CydWhk4DngzcbmcJElqwFJUDw8wWn5GCtCNeP9P0U0nzu6PFKGNcuNU2mPAGUQZuiI5y1Q8i9GR2ksnZ5EkqTQsRdVyP3DD8HH9mF//ipe/lcXSwK7E/UH7AM/IjVN5VzG6KlTWwQkzgFcAbwBelpxFkqRSshSV052Mlp+xxz8yQ6ljGxIDEvYk7g9aKjdO5T0OnEmUocsp7wmDNYFjicvk1kzOIklSqVmKimsRscfP+OJzI+W9z0FhKeDFRAnaC9g4N05tXEMUodOIiYplNA3YDXg9sZI4PTeOJEnVYCnK9ySx+eP4y95uwZHXVbI+o6tBL8X7PfrlCWJV6GvEXlplXRVaFTiS2Ftow9wokiRVj6WoP+4nVn1uGz5uHfPr34lVIVXLbGBnRleDNs2NUzvXEqtCp1LeiYoDwAuJe4UOBGblxpEkqbosRd2xiNjLZ3zhGSlBZb1UR+1Zl9ES9FJgmdw4tfMk8C2iDP2W8q4KrQAcSlwi95zkLJIk1YKlqHWPMPlqz53AgrxoSjIL2InRy+I2z41TW9cTRegU4MHkLFOxDbEq9FpgTnIWSZJqxVIUFgB/I0ZXjxwjf76DKD4PUN4zz+qedYA9iBK0G7Bsbpzaegr4NlGGfk15vzfnAAcTq0JuyCtJUpI6lKLHeHrRGf/7+4DFWQFVaKsQY7J3JUqQG6jmugoYJFaFHsiNMiXPIorQEcTlcpIkKVGZS9FiYoDB3Uy8wjPy+4cp71lk9d8c4pK4kRK0NXHDu/LcRwxMOIkoRWU1CziAKEMvTs4iSZLGKFIpWkhsPtrq8SBObdPUzQC2JQrQrsCOOOWrCBYC5xCrQj8G5qemmZrnAEcBhxGjtSVJUsH0qhQtJFZoHiHKSyslxxUd9cMAMRBhZCXoxcDyqYk01sjlcacTrwtltTJwCFGGnpecRZIkNTG+FC0iisxIoRn/+1Y/9iQWHBXH2oyWoF2BZ+bG0ThVuTxuOrA7UYT2wxVHSZJKYwawGaNl5gksMyq/lYFdGC1Bm6Sm0USqdHncJkQROhxYIzmLJEnqwAzgpuwQ0hStQgxHeBFRhrbB4QhFVZXL45YHDiLK0I7JWSRJ0hQVadCC1Ko1iQK08/Cvz8mNoyaqcnncNKJ0HwkcCCydGUaSJHWPpUhFNwBsyGgB2hnYIDWRWlGly+PWJ/YTOgJYLzeKJEnqBUuRimYasfIztgQ5GKE8qnJ53DLAq4hVoZfkRpEkSb1mKVK2mcTI4pECtBOwYmoitesu4FuU//K4AeL+oKOI+4WWy40jSZL6xVKkfpsDbMfoStAOw/9M5fIQcDaxInQJ5d5IeVNiT6HXAhsnZ5EkSQksReqlAWAtYPvhYwdgW2J1SOXzBPBDoghdADyVG2dK1gFeQxShrZKzSJKkZJYiddMc4lK47ccc7ttSbguJAnQG8ANgXm6cKVkVeDWxKrRTchZJklQgliJ1aoC41GhsAXouMD0zlLrmEqIInU2M1C6r5YH9iSK0G359SpKkCViK1KoVgRcwWoC2A1ZOTaRuu5K4NO5bwJ3JWaZiaWBvogjtDczOjSNJkorOUqSJzACezWj52R54Vmoi9cotRBE6A7gxOctUzCRWgg4B9sPJcZIkqQ2WIg0Q9/1sy+gq0POJfVpUTXcBZxJF6ApgKDdOx6YR9wYdAhwIzM2NI0mSyspSVC8DxNSt5wHbDB/PA56RGUp9UZUR2gPE1+0hxPS4tXLjSJKkKrAUVdcAsAFLFqBtgFUyQ6mvqjJCe4AYm70/UYQ2yY0jSZKqxlJUDdOISXDjC9AKmaGU4nHgPGJV6FzKO0J7OvBCogjtD6ybG0eSJFWZpah8ZgCbsmQB2hpYNjOUUj0K/IgoQhcQxaiMZgO7AgcA+xD7CkmSJPWcpajYliKmvm3NaAHaihg5rHp7kNhM9Wzgp5T30rjlgL2I1aC9cGqcJElKYCkqhmnAesAWY47nEpfEudmkRvwD+B7wHeBnwILcOB1blVgJOoAYoz0rN44kSao7S1H/rcLTy8+z8fI3TewuogR9B/gl5Z0aty6j9wftRJwIkCRJKgRLUe+MXPo2tvxsAayeGUqlcAdxWdx3gN8Ci3PjdGQA2JwoQQcQl4BKkiQVkqVo6sZf+jZSfrz0Te24hShBZwO/p5wbqk4nNv4dWRHaODeOJElSayxFrZsBrA9sNuZ4Nl76ps5dz2gR+iPlLEKrAi8H9hz+1X2wJElS6ViKnm55YuT1ZuOOjYGZiblUDVcxeo/QDclZOjEd2JYoQXsSK0MDqYkkSZKmqK6laBqwJk8vPpsBayTmUvUsBn5F7CP0XeDW3DgdcTVIkiRVWtVL0VLECs/44rMpsExiLlXbo8D5RBE6D7g/N07bRlaD9iKK0La4GiRJkiqsCqVoBWLQwfrDx3rARkT5WR/fzKk/bidK0A+BXwDzc+O0zdUgSZJUW2UoRXMYLT0jv479/UpJuaTLiBL0I8o3KGHsvUF74WqQJEmqsSKUolnAOoyWnfHl5xlpyaQlPQFcSJSgc4mNVcvoHcB/4mqQJEkS0J9SNB1Yi8lXetbEM9QqrruAc4gVoYuBx3PjdMXWWIgkSZL+qRulaBqwGhOv8qxHrAIVYUVKatXVjF4W93tigpwkSZIqqpWyMkCcVZ5spWddYsqbVFYLgJ8RRegcYmiCJEmSamKkFC3P5Cs96wPLJmSTeul+4r6gHwE/AR7JjSNJkqQsM4AHcIKbqm8IuILYP+gC4LfAotREkiRJKoQZWIhUXfcSBeh8YmrcP3LjSJIkqYgcgKAqWQT8itHVoKtwSIIkSZKasBSp7O4gStD5xMjsh3PjSJIkqWwsRSqbp4CfM7oadCNxv5AkSZLUEUuRyuAmRleDLqEaG6hKkiSpICxFKqJ5wE8ZXQ36S2oaSZIkVZqlSEVxJaOT4n4DzM+NI0mSpLqwFCnLXcRghJ8MH3fnxpEkSVJdWYrULw8CPyOK0EXEfUL9HpCwFLAp8Owxx/3AMX3OIUmSpAKxFKlXHgN+SRSgi4GriX2E+mFs+dmc0QK0ITBt3Ode3KdMkiRJKihLkbplPnEv0MhK0OX0/r6gpYBNWHLlZ3NgI55efiRJkqQJWYrUqcXA7xldCfoVvRmVPRtYj1jl2Wj41w2BjbH8SJIkqQssRWrHtYyuBF0CPNSlx12W0bKz0bhf18biI0mSpB6yFKmR2xhdCfoZcE+HjzMLWANYC1iXpxeg1aacVJIkSeqQpUhjjYzJvogoQX9p4d+ZA6xJFJ6RX8cflh5JkiQVlqWo3u4iJsRdQpShG4kx2QPAcsAGwKrAXOAZTFx4Vu57akmSJKmLLEX1cgdwHbECdA9RfuYCLwL2Z7QAzSUueZMkSZIqz1JUbQuIlZ+RgrPO8CFJkiRpmKWo2mZmB5AkSZKKzlHHkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1ixFkiRJkmrNUiRJkiSp1mYAp2eHkBJdlx0gwW+A6dkhpERPZAfos/vwZ73q7ZrsAJIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZIkSZLUpoFxfz4CeEdGkAJZCDw2fMyb5NeHgT8DfwL+DgylJJW641Jg2ewQHfpX4KLsEDXx/4B9s0N06CPAWdkhKuog4D3ZIRI9ATza4Hhk3J/vA/4CLErIKqmBGeP+vCqwZUaQEnsMuIUoSDeP+fVa4sVQKrotgOWzQ3ToLViK+mEZ4O2U9+tklewAFbYKvm9o11PEe4Ubxh1/Ap5MzCXV2vhSpPYtQ/xAGP9DYRFwGfDT4eO3wPz+RpMq75XAWsBfs4NU3MGUtxBJRTObOBm1xbh/vpi4CmVsUfoDcA1ekSL1nKWod6YDOwwf7yNWlH5BFKQLgevwRU6aqmnAscAHk3NU3fHZAaQamAZsOHy8Ysw/vws4HziPeP/wcP+jSdU3LTtAjSwD7AV8BvgjcQborcCKmaGkCjgWT/D00lbAC7JDSDW2OnAUcV/c/cQJ1v8grlAZf2+4pA5ZivJsCnwe+BvwNeKNh6T2rQnsnR2iwk7IDiDpn6YDOwMfBa4C7gT+DzgAL3GVpsRSlG8OcBxwJfBr4FDiemNJrXt9doCKWhZ4XXYISZNaEzgG+A5wN/AVYPPURFJJWYqKZQfgFOLSuv1xWVxq1cuBDbJDVNDBwHLZISS1ZGliZfc64CfEJfu+z5Na5DdLMa0PfJd4UfOMj9TcALHiqu7y0jmpnHYHziVOsr4ZT25ITVmKim03YhTn54GVkrNIRXc0MCs7RIVsA2ybHULSlGwCfJHYtuAzxElXSROwFBXfdGJK3Z+I6TNeUidN7BnAftkhKsRVIqk6lgfeAdwKfA/YLDeOVDyWovKYC3xz+Fg6OYtUVA5c6I7lgNdmh5DUdQPEyaNriAl2y+TGkYrDUlQ+RwKXAusm55CK6CV4BrQbDiEmz0mqppnEXkc3EOO8vQpFtWcpKqdtgN8T9xxJWtLx2QEqwEvnpHpYmxjn/WNg4+QsUipLUXmtAlwAvAvP8EhjHYmXmE7FtsSJF0n18XLgWuBDxP6JUu1YisptGvBx4BNYjKQRKwEHZocoMVeJpHqaBbyX2OdoH3xfoZqxFFXDO4F3Z4eQCsSBC51ZnrifSFJ9rQf8ABgElkpNbs8EIwAAIABJREFUIvWRpag6PgK8ITuEVBA7As/NDlFCr8VpVJLC4cAvgDWzg0j9YCmqlv/BMbrSCC8Da88A/p1JWtILgCuAHbKDSL1mKaqWAeBk4BXZQaQCOAzHSrfj+cBW2SEkFc4zgZ8DRyfnkHrKUlQ904EziGuCpTpbDu+PaYerRJImMwv4BvBFYo8jqXIsRdW0LHAi/v+VfKPfmhWAg7NDSCq8NwM/AeZmB5G6zTfN1bUL8KbsEFKy5xH77qix1+HeJJJaswtwObBFcg6pqyxF1fZx3KFacjx3Yw5YkNSu9YCLgE2Sc0hdYymqtqWBk4j7jKS6OgRYMTtEgW2H48sltW9V4lI6R3arEixF1bcD8NbsEFKiOcCh2SEKzFUiSZ1alyhGq2QHkabKUlQP78b7BVRvJxCXiWlJKwKvyQ4hqdQ2B87FLRBUcpaielgVOC47hJToOcCO2SEK6FDiMltJmortgO8Cs7ODSJ2yFNXHv+GLlerNgQtLcsCCpG7aHTgF72NWSVmK6mNN4PDsEFKiV+PeGmPtQKygSVK3vBr4H7xcWSVkKaqX/wBmZIeQkswGjsgOUSCuEknqhROA/8wOIbXLUlQvGwAHZYeQEjlwIayErwWSeueDxH1GUmmUbdXgRGL0Y7fNBlYgJjGNHM8AtgVW68HzZToUOD07hJRkY+AlwMXZQZIdBiyVHUJSZU0HTga2Bh5PziK1pGyl6ArgzD4+3wAxg387YHtgX2D9Pj5/L+xGFMCHs4NISV5PvUuRAxYk9cMmwEeBt2UHkVpRtlLUb0PAX4aPbwHvBPYiNkPdLS3V1MwE9sbVItXX/sAzgbuzgyR5IbGviFQXXwBO7dJjDRD78aw8fKzS4PerED9z6+ytwA+o94kolYSlqD2LgB8NH88mJqy8ODVRZw7AUqT6mgEcDfx3dpAkx2cHkPrsDuDyhOedRrxX2Jl4r7Az1bskvxWDwBZ4hYoKzkELnbuOWC36L2JFqUz2BOZkh5ASHU8999JYGQcsSP2yGPgjcQL1IGB1YDPi9ec04K950fpqbeBz2SGkZixFU7MQ+ABRjh5IztKOOcDLskNIidYFXp4dIsHhuImzlGUIuAn4OjH0aB1iKuybgFsSc/XDkcR92VJhWYq642LgVURJKou9swNIyeo2bMABC1KxDAF/Bv6XWEE6CLgyNVFvfZ2Y7CsVkqWoe35OnO0pi62yA0jJXkFc1lEXLyLeeEkqnkXAWcDziCs5qjiYYFXg49khpMlYirrra8BXskO06DnU854KacQ04NjsEH3kgAWp+IaAC4Fdia1Avpcbp+sOAzbMDiFNxFLUfe8F5mWHaMFSxEaWUp0dRz1G5q4CHJgdQlJbfkdMi3028KvkLN0yHXhPdghpIpai7rsf+GJ2iBY9NzuAlGx14jK6qjsCByxIZXU9MdL7P4AFyVm64XBg/ewQ0niWot74DOVYLbIUSfD67AA9NoCXzkllt4i4H2db4NrkLFM1A3h3dghpPEtRb9wHfCs7RAssRVLc1LxBdoge2hnYNDuEpK64BtgBODc7yBQdRWyNIBWGpah3LsoO0IJnZQeQCqLKKymO4ZaqZR6wH/Dl7CBTMIO4HFAqDEtR7/wsO0ALVsoOIBXE0VTznpu5xB5qkqplIbENyLuyg0zBMdRrWwQVnKWod+4mbo4sshWI+w2kulsV2D87RA8cCczKDiGpJ4aAT1Le+3Nm4mqRCsRS1FtXZAdoYgawdHYIqSCqNnDBAQtSPXwc+Gx2iA4dC6yZHUICS1Gv/SM7QAtWyA4gFcSLgc2yQ3TRLrgXmVQHQ8A7gVOyg3RgFvC67BASWIp67f7sAC2wFEmjqjSUoEr/LZIaW0zco/O77CAdcGNpFYKlqLfuyw7QghWzA0gFciTVuKT0GcAB2SEk9dUC4LXAo9lB2vR8HM+tArAU9VYZVoqWyw4gFciKwEHZIbrgSOImZkn1chvlvD/SKZlKZynqrTK8KVmUHUAqmDK+oRhrGg5YkOrsdODU7BBt8hI6pbMU9dbc7AAteCg7gFQw2wNbZoeYgpcAG2aHkJTq3cD87BBt2AH3LFIyS1FvrZIdoAWWIunpyjykoMzZJXXHX4FvZodok/dBKpWlqLdcKZLK6TDKeb/dalRzE1pJ7fsYMXyhLLyETqksRb21RnaAFjySHUAqoGWBQ7JDdOAoYlNmSbodGMwO0YYXUo73TaooS1HvDAAvyg7RxKPAwuwQUkG9nvg+LotpwHHZISQVykcpz0ClAVzpViJLUe9sTuwVUmReOidNbmti/4yy2BXYIDuEpEL5M3Bydog27JEdQPVlKeqdl2YHaMHN2QGkgivTeG4HLEiayEcoz2rRVtkBVF+Wot7ZMztAC67ODiAV3MHEhq5F90xg3+wQkgrpVmLvojJYC1g5O4TqyVLUG1tiKZKqYGliEl3RHY0DFiRN7ozsAG0o8z5xKjFLUW+8PztAiyxFUnNFH7jggAVJzVxKeQYreQmdUliKuu+5lGMDsoXADdkhpBLYHNgpO0QDuwPrZYeQVGiPApdlh2iRK0VKYSnqrqWBb2SHaNENwFPZIaQmnqIYmw8WeeBCEQYslOUMtFRnF2cHaJGlSCksRd0zAHwT2DY7SIuuyA4gteAx4EfZIYid1udmh5jAGsA+2SGAc7MDSGrqZ9kBWrQ5MCs7hOrHUtQ97yEmVZXF97MDSC0azA5A/IA+MjvEBI4CpidnuBn4TXIGSc39hnJcITIL2Cw7hOrHUjR1s4DPAB/ODtKGx4ALs0NILTofuDc7BHGZWpFeM6dTjAELg8BQdghJTT0B/Do7RIu8hE59V6Qf8GW0IfAr4B3ZQdp0LvHiKJXBAuDU7BDARhRrU+aXAesmZxgCTknOIKl1ZbmEzlKkvrMUdWYu8G7gD5TnHqKxvpsdQGrTSdkBhhVp4EIRBixcBNyZHUJSy8oybGGT7ACqH0tRe7YE/o94E/DfwPK5cTryFHBedgipTdcQJyGy7Qesnh0CWBN4RXYIilNWJbXm8uwALVohO4Dqxx3QJzcb2BrYDth++Nf1UxN1x0+I/QqkshkEtknOMB04GvhIco6jyR+w8CjwveQMktozH3gIWDE7SBOWIvVd2UrR0fRmE8XpxAvESsDKw7+uSDVX0r6YHUDq0BnAp4GZyTmOBz4GLEp6/qIMWDiLGNoiqVzux1IkPU3ZStHzhg915vfAT7NDSB26DzgH2D85xzrAHuTtzbMHsHbSc481mB1AUkfuJwZFFVkZb09QyVVxJUST+yiOzlW5DWYHGJY5cKEIAxZuAy7NDiGpI/dlB2jBCsBAdgjVi6WoPm7E6/9Vfj8G/pEdAtibnHHYaw8/d7aT8ASLVFb3ZwdowXRgTnYI1YulqD4+DizODiFNUVH2LBoAjk143qMpxuv2ydkBJHWsDKUIvK9IfVaEH67qvTuA07NDSF0ymB1g2DH0d+jDDHKK2Hg/B/6SnEFS58pw+RxYitRnlqJ6eAsxhlOqgmuAK7NDEPsVvbKPz7cnsFYfn28y7k0klVtZVooctqC+shRV32nAD7NDSF02mB1gWD8HLhRhwMJjwNnZISRNiStF0gQsRdV2D/C27BBSD5xO3F+UbXdgoz48zzrESlG27wDzskNImpKyrBRZitRXlqJqeyPlefGT2jGyZ1ERHN+H5ziGYrxeD2YHkDRlZRl17YRL9VURfsiqN74NfDc7hNRDg9kBhh0FzO7h4xdlwMLtwC+yQ0iaslWyA7To4ewAqhdLUTXdAbw5O4TUY0XZs2gucEAPH39vYI0ePn6rTsax/lIVzM0O0CJLkfrKUlQ99wEvoxhvFqVeWkAMEimCXg5cKMKABXBvIqkqXCmSJmApqpbHgL2Am7KDSH0ymB1g2M7A5j143HWBPXrwuO26FLglO4SkrnClSJqApag6FhKX8FyeHUTqo6uBq7JDDOvFis6xFOOmaPcmkqqjLCtFj2QHUL1YiqrjCOAn2SGkBIPZAYYdAczp4uPNJKbOZXsCOCs7hKSuKcNK0ULitUfqG0tR+S0m7mc4PTuIlOR04gdothWAg7r4eK8AVu/i43Xqe3gZi1QlZVgpehhHcqvPLEXl9iBxv8FXs4NIif5BcfYs6ubAhaIMWBjMDiCpq8pSiqS+shSV1w3AC4ALs4NIBTCYHWDYdsDWXXic9Ykpktn+BlycHUJSV5Xh8jlLkfrOUlRO5wLb4zQoacR5FGcMfTdWeIoyYOFkYFF2CEldsxSwfHaIFliK1HeWovL5GLAvTmWRxirSnkWvA5abwr8/Ezi6S1mmyqlzUrVsnx2gRQ9mB1D9WIrK4wZgF+DdeOZWmshgdoBhyxLFqFP7AM/sUpap+C3ueSZVzUuzA7TohuwAqh9LUfE9QRShrYBfJGeRiqxIexa9ns4vfzu+m0GmwFUiqXrKUoqK8lquGrEUFdt5wLOJS+bmJ2eRyqAob+S3JAahtGsDijFg4SngW9khJHXVssQwmDK4OjuA6sdSVEx3AK8i9in5c3IWqUyKsmcRdDae+7iup+jMD/CafqlqdgJmZIdowWPArdkhVD+WomK5DDgE2Aj4Lm5cJrXrXmI6YxEcDKzUxufPojgDFgazA0jqurJcOvdHvHdaCSxF+RYDZwEvJKbCnElM0pLUmcHsAMOWAg5v4/P3BZ7RoyztuAv3P5OqqCylyPuJlMJSlOcR4NPEPQQHAb/GlSGpG84D7ssOMaydgQtFGbBwKsW5BFFSd6wEbJMdokXeT6QUlqL+uo4oQrsTZ4TfCdyemkiqnvkUZ8+izYAXtfB5GwG79ThLq4oyrEJS97yYYmwI3QpXipSiDDfcldkjwE+B84ePO3PjSLUxCLwtO8Sw1wOXNPmcogxYuII4eSOpWo7KDtCiIeKeIqnvLEXdsQi4jdjo8MbhX68j3mB4f5DUf1cRl2BsmR0EOBB4OzEEYiKzKM4blsHsAJK6bmtiU+gyuJmYPif1naVoYvOBeQ2OR4G/MFqAbsV9hKSiGQQ+mx0CmAkcCXxiko/vB6zatzSTW0AMepFULe/PDtCGK7MDqL7KVoreAXytx8+xEAuOVAWnA5+kGK9zJwCfIqZNTvSxIvghcH92CEldtRVx4qUsfpgdQPVVhDcL7ZgPPJ4dQlIpjOxZtG92EGLK5G7AT8b9840pzphcByxI1VOmVaL5wDnZIVRfTp+TVGWD2QHGmGhFqChjuO8lhsFIqo4tgf2zQ7ThAmJAlZTCUiSpys6jOJeE7QusMebPs4l7jYrgNBwKI1VNmVaJAM7ODqB6sxRJqrIi7Vk0HThmzJ/3B+YmZRlvMDuApK56LnBAdog2LMD7iZTMUiSp6gazA4xxPKP3chZlwMJVwDXZISR1zQzgS9kh2nQh8FB2CNWbpUhS1RXpTf9awJ7ApsAuuVH+aTA7gKSuei/wouwQbfLSOaWzFEmquiGK9cb/BIozYGEhMbpcUjXsArwvO0SbFgI/yA4hWYok1cFpxA/eItiLJe8tynQu8I/sEJK6YjXita5s7+0uAh7IDiGV7RtHkjpxLzGJrggGgBWyQwxzbyKpGlYkxuqv0ewTC+g72QEksBRJqo/B7AAFcz+xUiSp3OYAPwK2yg7SgQeAM7NDSGApklQf51KcPYuK4HRiZLmk8ppFDCnYKTtIhz4DPJodQgJLkaT6KNKeRUUwmB1A0pSsCPyYmGhZRg9RvtHhqjBLkaQ6GcwOUBDXAldmh5DUsQ2A3wAvzQ4yBZ8DHs4OIY2wFEmqk6uAP2aHKIBBYlS5pPJ5IfBbYLPsIFPwCPD57BDSWJYiSXVStD2LMizCywilMpoFfBj4BbBqcpap+jxx+ZxUGJYiSXVzGlEM6up84O7sEJLasiVwGfCfwPTkLFM1j7h0TioUS5GkurmH4uxZlMG9iaTyWAv4NHA5UYyq4Iu4WasKyFIkqY4GswMkeZDYz0RSsT2HeJ36M/AvwMzUNN3zGDGGWyqcGdkBJCnBOcSeRatkB+mzM4Ens0NImtAA8CLgXcDeyVl65QvAfdkhpIm4UiSpjuYTm5fWzWB2AElPMx04gBix/QuqW4huAj6UHUKajCtFkupqEHhLdog+upG4L0FSvnWBnYmVod2B9VLT9N4i4HDgiewg0mQsRZLq6kpiz6ItsoP0ySDuTSRlGACeRRSgkSK0dmqi/vsoMT1PKixLkaS6Gtmz6NPJOfphMXBqdgipggaAZYGViXsUR35dBZgLbA3sNPz7uroKL5tTCViKJNXZacAnKP++H81cCPwtO4SU5ARgjy4+3mxGi8/KVGcyXC/MJy6bm58dRGrGUiSpzkb2LHpldpAec28i1dnGw4f67/3EZcpS4Tl9TlLdVb0wPAJ8PzuEpNr5DfCp7BBSqyxFkuruHKq9u/qZOPFJUn89DhxBTJ2TSsFSJKnunqLaexZVfSVMUvG8Gbg5O4TUDkuRJFV3U9ObiUtYJKlf3gOcmB1CapelSJLgD8C12SF64CTcm0hS/3wG+Fh2CKkTliJJGt2zqEqGgFOyQ0iqjZOAf8MTMSopS5EkhdOo1k3BFwN3ZIeQVAs/BI4lNoqWSslSJEnhbuDH2SG6aDA7gKRauAQ4GFiYHUSaCkuRJI0azA7QJfOA72WHkFR5VwH74Nh/VYClSJJGnQM8mB2iC74NPJYdQlKl3QLsATycHUTqBkuRJI2qyp5F7k0kqZf+ALwUuCc7iNQtliJJWtJgdoApug24NDuEpMo6HXgRcGd2EKmbLEWStKTfA9dlh5iCk3EClKTuW0yM3D4UeDw5i9R1liJJWlLZ9yw6OTuApMp5CNgL+BTuQ6SKshRJ0tOVdc+iXwB/zg4hqVKuB54PXJAdROolS5EkPd1dwPnZITowmB1AUqX8ANiemDQnVZqlSJImNpgdoE2PAWdnh5BUCUPAfwEHAI8mZ5H6YkZ2AEkqqB8RexatlB2kRd8hNm2VpKm4HHgjcEV2EKmfXCmSpImVbc+iwewAkkrtfuB44nI5C5Fqx1IkSZMryyaotxNDFiSpXUPAV4FNga/jSH/VlKVIkiZ3BTF5qejcm0hSJ64AtgNeT6wUSbVlKZKkyZVlzyL3JpLUjgeAE4hL5S5PziIVgqVIkho7lWKvwlyK43IltWYe8AXiUrmvUc792KSesBRJUmNF37OoLPc9ScpzG/AOYC3gbcB9uXGk4rEUSVJzg9kBJvEEcFZ2CEmFdRGwL7AJ8Dng4dw4UnG5T5EkNVfUPYu+h29yJC3pSeAU4jK5a5OzSKXhSpEkNfckcEZ2iAkMZgeQVBh3Av9BXCJ3PBYiqS2uFElSawaJXd6L4m/AxdkhJKUZIkZqnwf8ePj3Dk6QOmQpkqTWjOxZtHl2kGEn4xsgqW4eAC4gStAFwL25caTqsBRJUmuGiElvH88OMsypc1I9/J4oQecBl+HJEKknLEWS1LpTgY+Sfz/mb4GbkjNI6q6HgBvGHVcA92SGkurCUiRJrfs7ccnKnsk5XCWSyusunl5+bgDuJlakJSUYX4r+ClySEaRFf88OIFXQr4BlskNM4pHsABP4Erl/X0PAtxKffyJ3UuyfHXdlB6iwuyj2//teWgzMAx4dPsb+fqJjHnEP0EMZYSVJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJkiRJktR3A9kB+mRDYPYkH3sQuKuPWepibWA9YPXhY2XgUeAB4P7h4zri778o1gKWn+RjjwN/6V8U1dyKwBoNPn4DMNSnLM0sA2wCbArMAe4bPu4F/gwsyou2hI2AWZN87AHg7j5mkfptZeCZk3xsiHhNkWptolK0CvFmtRNDxBvfkR+KVwE/B34NPNnhY07VGsDtwIxJPn4DsHkfcswFrm3w8TOBt0/xOU4Fdmvw8RcDN03xOSYzDdgReOXw8awW/p3FwNXAxcBPgAvJe6M3kyg9k70RnQesCTzShyzXEd+HE7kC2If4u+vU+4A3Nfj48cAPp/D43TId+FuTz7mN+Lpe0IXn+xRwaJPPeR1wUReeq5nTgNc2+PiewPl9yDGRGcTXyP5EEVqLyU+wPQz8EvgZcC69e/1pZh3ia2X6JB//I/Dc/sXpqgOBL3Xw7w0R/3/uHT7uAf4AXAD8tWvpJvc54OA+PA/A74B92/x3vgns1eHzPUWc+LuP+LlyCfE90Oz1rJe+T+O/g52J79VeGwT2mORj9wO7AP+YwuPvCZzY4ONfJ34GSi1ZlXix7OYxj3gBXKeP/x0j/quFfI2KRLes1kKOQ6b4HOc1efznTPHxJ7Mv8UZ+ql8nfyR+SE7rUc5GXtNCvrf1Kct9TXJ8aIqP/8kmj/+aKT5+t8ygta+bf+/Ccz2fWNFo9lydvklqxzOB+U1ynNuHHBPZnyg2nXx/LwZ+TH9eb8f7WAv5XpyQqxsOo/s/s68DPkGs+PfKiT3IPdlxaQf5vteDHD8j3rT323o0f337dp+y/KBJjguZ2nuA/Zs8/uen8NiqoV6UopFjAdHQ+/WmdxZxSUSzXD/oQ5ZWStGjwGZTeI5+l6LnET9suv11cgOwQ5ezNtPKf8ef6M8lp81K0WImP9PWiqqVoseIH/qdmk6cIW/lufpRij7QQo7FxOVg/bIucRa5W9/jlwNb9in7UjT/nhoCzu5Tnm7rRSkaOZ4CvkxvTmie2MPc44+ilKKR4xJ6WzjH+0QLmRYQq7691qwUDQEfnMLjW4rUVb0sRSPHT5n83o1uOrTFPIuA9XucpZVSNERcYjenw+foZyk6nLgksldfIwuA99CfAr11G7n6cZavlTdw99H5D9WqlaIhprZy8vY2nqfXpWgm8PcWs3y2x1lGzCZKTLe/x+cTJ8kmu7S5W45uMc9C+vtGtVt6WYpGjqfo/kr5iX3IPXIUrRQNEZeK7dpBrnYtPfxcrWT6cB/ytFKKFgG7d/j4liJ1VT9K0RBx3XKvfxj+ro08n+xxllZL0RBwUofP0Y9SNI3mb6q7eXygC5mb+WYbec7rQ55WStEQ8BviTXS7qliKhoBXd/AcaxErtK0+R69L0SFtZHmIGHLQa//TRqZOjl16nP/KNrL8d4+z9EI/StHIcSawbJdyn9jH3EUsRUPEa89WHWRrx7Ft5LmXyYdSdUsrpWgky5odPL6lSF3Vr1I0RG/PdL6gzSwP0PkKTSvaKUVDxAtZu/pRij7X5Dm6eVwLLNeFzI3MBZ5oI9NiYOMeZ2q1FHX6PVTVUvR32l+BbveNT69L0a/bzPOGHudpp6R1cny1x/l3ajPPP4jL7cqkn6VoCLiGmI44VSf2MXNRS9EQMXxhhQ7yterqNvMc3sMs0HopGvn/1u7Jc0uROpZxQ/tYb6Z3bzDf0ubnr0TzyVP99EV6fwapXUfR2SUUTwG3EpOOWnU/MWXt0Q6erx3H0t6boAHi67Yo3g68KjtEQawOfKSNz98H2K9HWTrxPNq/l66XX4sDxES+Zp4kpiJ+h7iRvNUJjbcC/9JZtJa1+3NgLv2biFZWWxD3X3WySq2nWwN4V48ee2fan6rY7vdML72QGJIi9UUnl689xORnEpYn7s3ZCDiA5mf5ZxA31L2ugxyNrAYc1MG/9xbga13O0qmlgLOIN0r9GAPdzHbAV1r83IXAd4mz3r8hRrPPH/7YLGLF6hXE5U4TrV4tIN7o3zaFvK2YTmdn2o8E/pOYqlgE3yTOBt6SHaQA3gicTNwD08gyxImHIunkzcjmxH0JvRgTviON90qCGAX9IeJSlxEDxL5F2xIrNUfy9BMPi4ifI491I+gk1iR+DrXrLcTY4Kq4iMnPjq9HvGl+LvFa3OrVErsSPw+OmWq4Bt5JlOxu6MVr9YeByyb45zOIwRQbAC8hSmQzbydW/e/rWrrQyWvKtsD2wG+7nKVT/0qsGH0/O4jqqdnlc61ucDcX+EyTxxoiVgIm21CvU+9r4XknO3bpcpYR7V4+N3J8p43n6NXlcwPA71vMeztxdqcV04iVp3njHuO4DnO26wA6+38yRON9fqaqncvnRo6raH3Fq6qXz40cf2Dy/WhGfLrDx+7V5XOr0vngkl69WXhPk+c9o8XHWYcoqovH/Lsf7XbYCXyIzv4+h4hCWBbNLp87scXHmQa8jDgZ1erf0yumkPvEJo+9/xQeuxuaXT63TwuPMUCcoP1rk8caAo7obnzWIk4wdvL1f1qXs4zVzuVzI8dDRMlshZfPqau6VYpG/G+Txxui8ykjE5lJXKM72XPd2iRLOyWkHZ2WoiFa39S1V6WolT18hojVoZU6ePx1iY0o+/2C9TMm/2+5iziLPdnHb6B347k7KUVDxKZ0rah6KRoC3tHgcbciVjM7edxelaJmBaTR69YipjaSfDLNXrvbXYXZitiD5Cq6fyJsvNnEZqSd/hxotfAVQbdK0YhliHtHW9m363qan4CYzIlNHrsKpWjEC2i+99hZ3Qo+7CMNnmsxjcvvfGK/tF7opBQNESdmWxkCYSlSV3W7FM2mcUkZIpbJu6XZG/hXE8vCk318Ib3Zk2EqpWg+rd1r0ItSNIPYn6dZxtM7eOzx9qbzH7Dt2oLG/z0fBL7R5HO6WebH6rQUDdHaTbJ1KEWPMvF45Wm0N5Vy/NGLUjQDuLPBc/6KuM+lUa5P9CDXWU2e86gOH7fXw1OgeVHYl8Z7U80n7lErg26XohG70trJg+M7fPwTmzxulUoRxOpoo8f7U1dSh9nEJa2TPdeFNB9V/4Eu5hmr01I0RGuX8FuK1LF+DFp4iomvux2rm2ckGl1DezfpnN/pAAAT7UlEQVRxqcmXG3xOp/eZ9NJM4FvAKgnP/VKaD8N4iNZXsxo5lzg72Q+NblBfSKy6NPo6gWLdkDriy3R/k94yWhb4wgT//PXEWdsi2Y/GmyZ+hViFvbfB5xxD7EfSTc0GoxxCZzfb93p4CjT+3vwrcA6Nv79nEl8rddboXqSx3trrIBXxyyYf7+b7oIOJE9yT+TIxXv2hBp9zAsUbpnEC3b8HXfqnfk2fu6rJx5/RpefZmsb3s/wfcY3tt4gR3JM5juKNZV0bOJXeXbI1mVbOhr2bxm/YiqbZpMEfEaubVwwfk9mb3m/62645xBn+bu0lUmSLm3x8P5b8+l2d5vvQPDmlRJ1p9Ab+fuDbxMrFNxp83sp0/83CPU0+vjvwQ+LG7CLZDnh+g49/nTj5cjqNh9icQO8v8yu699F84M2zaf1+jzpr9j5oObr3vqPRa8rfie/bx4l7/SazOnBgl/J001eBZ2WHUDX1qxQ1uySqW29EGr0QLGJ0styTNJ4utApxFrSf7qTxWRuAPYh7D/rplU0+fjm932uk246m8ZSlL0/y+/Gm0duBCxOZD9zU5HM2ozhTFHvpOppPp/oSowXxczTeD+QPxJuFfnouMTZ3MicSq+0Q32eNimC3Vy6vaeFz9iBeA24DPk5My8zW6O9hIXFyDOKewUZvClejsw2Bq+Rxohw2s2+vg1RAs/dbi4iTtlO1A42/D79OfB9A88vRMq6GaPa6swwxEr4fG1dLXb+nCGIZvtFjvm/KqZtvwvmDcZ+/MUtOQxp//KELmcZqdk/R5cRZ7UaZhogXs5dM8hzdvqdo0yaPNwS8t83HzDaNxjeY3sySq3FzgAcbfH4vNv1tdE/R48T/x0ZDIEaOyS4Drco9RVcTZ6ib/V18mnjz3uhz5hMF5bQmn9fte4q+3uC5FhPbG4x1TpN8jQpWu5YnClmzr7Pxx63E3iIZBWk1Gmc+e9znb97gc4cozljiRnp1T9FYDzR5jvM6eMwTmzzmN4l9rKZyTGWvv27fU9Tsfuc7p5B1rNMbPMcCYlT9WD9rkqvb38fN7inamTjx1+x15pRJHt97itSxTvYpatfzgBc1+Zzbu/A8zTbhHH/G/2airO02yeePXIr3q6lHa9kPic0S/63B50wnJiNtTUxI66V1W/icq1t8rMOIvUs69WFGz5hPRbNL3r5CvHCOeBw4ick3rf3/7Z17sFVVHcc/lwuCoqiMRvnCV0SaqWCmpFba1PgAcRRLbcxMclRu9EIrJ9M0snTUMR85GteaQhttMkwxH6lIkSZSii9GBc0HmKLoFQjuvac/vnfH6bD3+u3H2nufe+7+zKw/9Oyz1rqHvddev/V7fINQvCI9M4uRHs+NxnWXo3y+hXlPqEReQN7TKxzXTMcW5JxJPM+IT6yQt3vYWHvqWnQPR9EBzMs4r4B30O+aVFhyV+CcvrYUGSK3YueW+sAKeWt8DzyFfq8oYzIIxbN0r1qdJ3Ab3HkUJ0pbyKOe6dhha0XQju118bEPskLegtDweq7FLUXSgbTGiuJd9Dc8jDtP8osoT2sgREVUlIhPT9EI4Bmjvx6yV/lpRwuK6+QyLBfH0qm5OeO86onjKQIZqvOMa2vAA2wclujbU3RyjHmEVfgKw5qb1VxhT0m42zHGGrRRbWSsMbcnPM0twPIUBdxgzKuGjIatGvpvJU8RyPs337jW6idIKC7SUzTDGGtyyHcGIUMj6jvrcRdtSEo7Ms6yPLtBW4a8l3mFbQ9B+RJR4z9L+HvAquznCrFrBorwFP3MGOPNFH12Gn36aFmKQPj0FF0QY64+ImbON8YIq5g6BB2wRn1nLe6iDUmxPEX79l33ZeO6YG778v9UnqKK1OT1chqEbuglKATLxV/I7vE4GvdJ1XXoYWhkDnqJRnEstqK7b7rRS9oqXPBJ5D3JE8tYXYk/l38RjCXaMwhKaA8rwPEM7tyVj5Cf6K+Ladieul2Qp6voAh1F0ovyxNak+G43Wqt8xPInYRDy9kXxMjrVbaQX98noYPxWz+xBRvJSD32NRtpHjyAPjG+Oxb1mNXqBA6zKfp/HXzGg/orlRR1JPA2ZgcYe6CDuvBjXZtUpGoI7/+s54N6Q/78edxGXoRQnqF5PJ7ZBPxR5oX0dmlYMcNIYRSPQCXVYuwlYBHSheOBRMfqLU3fewuWWXtc3lzDqk27DGEw5ZVlfBU7Erq51Du5QmqxYFcyswhDNxjTcxoHrXmzGhNS1KMzAVUELdKLpUwusGVlCOl2NS/CfPxiHibgFV4MKaWH8ArcRNxW/G9SVKI/xZsKNiqSMBxagUGGfuJ7BNUSHm7reEaBwvLRaPK3CSzGuKUJ/qpmYRvg+aBY6RFuOisHE0bN7EB2+ZWEK7rLeUYfDoIMW137jDIpJt2jkLGyDfFf8eEMrKkKxwud8Ntfpe1wsEc7fGN/fAbdA3XL8lGWNGz5Xz3nGd2oobGF03/W+w+e+ZvTXQ/wKMGWHz41AscpR/Vtx51aIgU/R37jhcwHHOq4P2no25Pa1WvhcQDvJhFmfZGPjoajwuXsdY6zH9lAHBkpU+5KneTYyDn/hdDX85SqMM8bpNL6/M1rPor7/MuVsCuNQRPhchzHGOpIfsnYaffpoeYbP+WrrkEcpKwscY6zB1jmcY8zTV3nuuOFzAWPQwZ/1O36z7/oqfK4iNUWV5A5jJfFKfVq4RDjBFuCMClMJGAUcn2hG/rgI+JNxzUjkds9DT8PSKRmENCr6A6fg9nxZ94kVYlCm6O/vsBf6wWgj3cphQD0oFC5OQY4eFHLno3hHUvYADnN8boX1QnnCwo+hk+8JyNOzJGN/V+NnQ2j9vZandxlwl+Pz7VEO6kClcaPayGvYkQ0V4fwAFfzIwn7AAY7Pb8HO+2rGaAjQGvOVGNf9BK1LFRWpKevk6y2U25H1hWqJcIISRC2sJMIOJJxaNL3o71uEO3n6Y6jssG/iFNX4KMVUlcpCG7bxPB07VNIKD5mKEmrLEACdAeyPNCqi2A6Va41bMbA/8hRwIXa+3eXIq1QG1r34cfTMZ2E8uhcWZOwnigV9bQY6yZ2ETmgPJFn+2mYo3Mi1obPYBnd1wRrxwrStA4MOlHc4EBlnfN5Y0cwH8z30m3WPkTczgR976McyWD6FvaZYh+SHoPd90VU6QUbdlbg9f4OB3wI/LGRGFQOGvMPnHiN5GFcU38p5rvVt/4xzTRM+F3AgcrFbc3zT+Dzp7/6BGGPGMTpBp8unOtqjxjhZwucsjRqfzUcZ2aThcwE7Gt+Ne5/01/C5+u8tdHzvWaLL9+cdPrclyrks4l6cnXGuadgFaZc9nWCe3bhL71p8N8FYWVsW3Zu8yDt8bjj2++eyFP12Gn0ek3HeWckzfK4Lf56XbdFBXBH3//Ue5ps0fC5gCNINs+Zovd+q8LmKRORlFL0BfAd/3ilLhNN3ixIKi0sWowjgGx7+hjTG6CKjz1VkL6kOqiDjGieLUXSH0bfP5iNpP61RBDIALQFgq/V3owh0ohm2ketB+mNR5G0Ufd3o32dbh59nMy3jkUfO2qTUSH/o1I6KABT1m7pCaMsib6PoUqP/Gumqb3YafbaiUdQD3Ia7yEpSzs1hnlFtNeGyFUlIaxSB8nbjrCeuVhlFFZHkmVO0Hrmub0chYNsjlfNuT/1bIpy+OZ541fTy4nJUOrZoLKXyETT3IrM7cHiB4wWiv2VxF/CjEsdvFh5HoSmNXEWxgsz1tKFqSkVhlejNm4XoMOdgZOi7SOuBmUx8rTQfnIidsN5K7I8MeRcrUahbRTjL0e9zEaqUNhnlsPnAdwl+i02Jl9+TFy+x4RCgosI7abw2Xah6VSM1ZME/19deJLqkrA+KTvoLyrJeWPC49ZwK7A3sVuCYtwPfM66Zgk7QLQOqDM6ieI2eDsrbeIMSdycAh5Y4h2bgRyg5fq++/34BhVqVxeHISC+S09HvkFWH6WgkKv1Wiu8+hUr+utaRtMUWin4PDANOQ0ndrc4mKN+rUSS8kVvwd9jZn5iNQnEbWYvWmmAv1JXjHI5BB85FcibKYS6rsMadKA/L2pdUVHjBCp+Lk3yfN2PJHiKUpr2CTl/TkDV8LmAfVF4zzfzT5nLNj9H3MpRwnZY8wueGIy2lou+TOCWVXWQJnwsYhSqYpZl/K4TPBYxH/x69xAvxyTN8bq7Rd17txAxzBm28etHa7ypo4GKqMceLU/RpyTHk1V7ENhSKJI/wuR2IF3b8Huk35Z1G380ePjepvKn9j3mU8wwcnWHOWcLnAtqRpEuauTdzZEtFyZRZkjsLlghnXmxH+WVZ/0E27YU0xDmRGY3yj9J4ZrbFn8ZPPSdTjtJ1WaK/9axAxs1APMGtZyHybP8ceKDEeYwBPlfS2Fm8KfugfMo2ZGjfhE5qd07Yj6sqIsC/Es+svBLBO9EcG+I8aEOegCeJdwBwBflUnquw2ZsN2nNFU9azF9CDDmheK3keFS1Gs4rRuRiBW5jwXfTCShu6dxRwtuPzDlT2sUyuBw5Cm/4imIf0kqxN3WYoZ2MSinN+wbh+B1TS97S+7/rGKn18HPB6yr73xK0V81UUQ74uZf8+eAgl4Q6EUB8X51P+yb51WHAx6cNP21GYa5QO1wFIx+TRhP2+H2kmNQo0Hw4sRqHEndjP0PHYa1XSMvFbAyc5Pn8L5W7UEvYbMJkNYpBhdCBPQn+nDRm4e6HiJEcSvzz6Mqq1pUwsw+QC4L6UfW8C/JHoKp2HoZDXrPpKWVgBnID+xrLX94oWoT8aRafgFuH8NdlOhBcjT0zUYvAJ5N7NqiOSlTOQdoSv8uYWp6MQP0vTCeCzwPMo3GYRqsi2CBiKEk2DdiD5iM7ChkU7inlI9DQt84FvE53fFYj+lqFvVc8lyICeWPI8yqRMwxS0Xp3i+Hw12ly+nWGM2cgQj6ID92FSI8NQlayoIgbDkSE3E+XPzUVhZa+ixPtRqBDOSUjfxMUK4K8J5gZK9nYdpPwKPeNpeRodqkStT59Ga+/iDGMUxWSkZRfGTtj6a2GsQgbUO2knFYPz8OtxP5LW8ZyPxB0Wuwqt/e9lGONW3DqQ05BXsUweRBIAPrSeKipCaeacojZU0c41v70ivx2fG40xZqXo01dOUT1jkWcsbixtVgPqYOLpJeXRkobB3Wb0lzY3op4ZxhhpxUF95BTVszWw1JhrfWulnKKk5JFTdJbRp48yz/sYY6wl3oFGgPU7+GyXJvxb48gxjE3YZxjWbxBHELYIrJwi3209OvjKSmfB8056ANfMOUVnO+ZVI75+oIsJxhhdpAtP95FTVE8b8mrFvQ+qnKKKRDSzUWSJcPqq+HWAMc4apKKehDyMItDmPu5i4MOrdCoKTSzyZXYrybyaOxtzXIEfD9U22KJ5afRXfBtFoPCpuAJ/lVEU3ZIaRW3YQqZRp/hJsYQNz43Zz2AkAVDEs72c5BurSUaf9yfsL4qDjXG6gK08jZWFIo2it/FnDHQWOO8arWMUtaPQRdfc9vQ01j+Ncaxy7WH4NopAnrNlRr9Bq4yiikj6W6EFK4bWleORhL+hggZRBGVZm4GbgWsKHG8WehmsKmCs1Sgk6DiShT2cifvenoWfkKo3kMHmouyE1IBHcedIVOTDZ3B7LRaS/kCkEWv9O4N4hwvdSF9oIra+UBa60fOddC2xnilfHpyHUMGBKIajQ6KBwmJkwM8peyIDnImosFEU1n2bhOuMz8uQvAhjJZIGKTtUuqIFaVZP0e64y3C/gXJWfHG6Y6waycuy5uUpAp2A/d3ov4bf/KMxaOHN61TvbuBDKea1KW7F6x78iv4e5BirBvyH5KK/eXiKAmYb861ReYpcYyb1FM0x+pvqZdZiGNocuMabkrDP7VARB9/PdzfpQlg/bPS7gvSyCWF0GOM9T/mHi3l7irpQzltjwY2sdOY878bWKp6i+4x5ZS3BX88W2CH6SdfEPDxFAdOMvmtUnqKKhDSrUWSFc4QJymZhc5RE6hozSXnuPI0iUMiYtSHyXZRhE+SVecUYN0n7MzI00nKa0X8eArNPGGN+P2F/eRpFm2OHc1VGkZ8NwC64wzhX4X+jeZljvBrpiw+MQ17RrKGzvajASdrwnquN/mem7DeKLZFR4BrzKM9jJiUvo6gL+CnJctGS0JnTvKNaKxhFexpzeh3/xYuuM8acm7C/PI0iUHVgV/+VUVSRiGY0iiwRzl7yUYq/xjFmjWSx63kbRSC3usubllelumHAdOARY/yothS4kmzGUIAVA53Hi8xKpE8q+punUQR6sb7nGKMyiqJbEqPoUqOvq7zNegNjjDFrSN8kLWPR32U9Z2HtTmRcpWUE7lPrHpLrJ8XhBseYNSRXUCY+jaJn0KbxCPKRSain0+O847RWMIquNeaUR4l0q4hLL8mE2/M2irZA93FU/5VRVBFJWCzoUNzu19UUr9OzPe5qN++QrbxyFDuinIAoaqjkcpx8l2Gopn4U/0YVVLJyBNHhWr8nW9nfOGyL/q0ORTpEo/raSKQd8lpfW44WrjvwF/+8Ge4NfQ0JUabVsIpiC5T35OJ24udnnEB0Sfhu9DdkZQLR4Yn3o6TVsmnDXcp6JXrB+uQQosusA9wDvByzr2NwJ+In6SsJx+Eus7wQeNzDOKPQ+rgfG57z96F3yFLgORRe9jzyTi7JOJ61Hr9NPtpBo9F6FkUveg/4Xlfisht22fMwaug3W4E8DCuQd6goDgI+WOB4v0T/VnE5FHfuzr2kEx3OwhTckiRzyefg+gsoND2Kh4mvWXQYbrH2P6C1PQuuZ+JJdIBbUbER/wWekN+QR8RhBAAAAABJRU5ErkJggg==", "companyName": "PT Pangan Masa Depan", "defaultCurrency": "IDR", "fiscalYearStartMonth": 1}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 15:02:24.302
38b71e22-7529-44dc-9bac-c9a05ec26d9b	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	unknown	2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7	\N	{"id": "2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7", "slug": "default", "email": null, "phone": null, "taxId": null, "address": "Cirebon, Jawa Barat", "logoUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABsgAAAG1CAYAAABUJnF2AAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kctLQkEUhz+1MMowqEVEkIi1siiDqE0LpRdUCzXIaqPXV6B2uVcJaRu0DQqiNr0W9RfUNmgdBEURROvaFrWpuJ2rgRJ5hjnzzW/OOcycAWs4o2T1un7I5vJacMLvmo8suOwv2OnAgpuuqKKrM6HxMDXt404ixW56zVq14/61pnhCV8DSIDyqqFpeeFJ4ejWvmrwt3Kako3HhU2GvJhcUvjX1WJmfTU6V+ctkLRwMgLVF2JWq4lgVK2ktKywvx5PNFJTf+5gvcSRycyFZ3TI70QkygR8XU4wRYIgBRsQP0YuPPtlRI7+/lD/LiuQq4lWKaCyTIk0er6gFqZ6QNSl6QkaGotn/v33Vk4O+cnWHH+qfDOOtG+xb8L1pGJ+HhvF9BLZHuMhV8lcOYPhd9M2K5tkH5zqcXVa02A6cb0D7gxrVoiXJJtOaTMLrCTRHoPUaGhfLPfs95/gewmvyVVewuwc9Eu9c+gF0m2fsAqi1mgAAAAlwSFlzAAAuIwAALiMBeKU/dgAAIABJREFUeJzs3Xe4JFWd//H3nBnCMMWIpEJFCSKCgIFgFpEyICCsKCpJUKKurpn1p7tm17Dq6iqwZtew6CqKii4KJQZUzBgRlKAiSwnoAoXkM78/qgdnhpm5t7ur+1R3v1/P0w9z+3Z9z2dmdO69/a3vOSBJktSnqsz2qsrsxalzSJIkSZIkSYMIqQNIkqTJUpXZc4CzgMekziJJkiRJkiQNYlHqAJIkaTJUZbYO8O/ACb2ndkoYR5IkSZIkSRrYgtQBJElS91VltilwGrDnCk8vAzbMi/qGNKkkSZIkSZKkwbjFoiRJWquqzO4P/ICVm2PQ3GjjFJkkSZIkSZImjg0ySZK0RlWZHQR8B9h6DS/ZeXxpJEmSJEmSpHZ4BpkkSbqTqswWAK8GXsXat2R2gkySJEmSJEkTxwaZJElaSVVmS4CPAgfN4+VOkEmSJEmSJGni2CCTJEl3qMpsK+ALwP3neYkNMkmSJEmSJE2ctW2ZJEmSZkhVZjsBXwM27/PSjfOi/ssIIkmSJEmSJEkjEVIHkCRJ6VVldj8Ga46BU2SSJEmSJEmaMDbIJEmacVWZ7cjgzTGAnVqMI0mSJEmSJI2cDTJJkmZYVWb3pWmO5UOUcYJMkiRJkiRJE8UGmSRJM6oqs+2Bc4Athixlg0ySJEmSJEkTxQaZJEkzqCqzLYCzgLu1UM4tFiVJkiRJkjRRbJBJkjRjqjJbDHwBuFdLJTdpqY4kSZIkSZI0FjbIJEmaIVWZLQA+BuzRYtkFVZmt12I9SZIkSZIkaaRskEmSNFveDDxlBHUXj6CmJEmSJEmSNBI2yCRJmhFVmR0DnDii8jbIJEmSJEmSNDFskEmSNAOqMtsdOHmES2wwwtqSJEmSJElSq2yQSZI05aoy2xA4FVhnhMs4QSZJkiRJkqSJYYNMkqTpdzKw3YjXsEEmSZIkSZKkiWGDTJKkKVaV2RHA4WNYygaZJEmSJEmSJoYNMkmSplRVZvcGThrTcjbIJEmSJEmSNDFskEmSNIWqMlsAfAzYcExLbjCmdSRJkiRJkqSh2SCTJGk6HQM8bIzrOUEmSZIkSZKkiWGDTJKkKVOV2abAm8e8rA0ySZIkSZIkTQwbZJIkTZ+3ABuPeU0bZJIkSZIkSZoYNsgkSZoiVZk9HHhWgqXXS7CmJEmSJEmSNBAbZJIkTYmqzAJwCrAgwfLXJlhTkiRJkiRJGogNMkmSpsczgPsnWvuaROtKkiRJkiRJfbNBJknSFOhNj/1zwgg2yCRJkiRJkjQxbJBJkjQdngHskHD9qxOuLUmSJEmSJPXFBpkkSROuA9Nj4ASZJEmSJEmSJogNMkmSJl/q6TGwQSZJkiRJkqQJYoNMkqQWVWW2IMGyL0+w5or+lBf1bYkzSJIkSZIkSfNmg0ySpJZUZbY98P4xr/kwYJdxrrkav068viRJkiRJktQXG2SSJLWgKrMtgbOAw6oyWzLGpY8f41prYoNMkiRJkiRJE8UGmSRJQ6rKbFOa5ti9gPWBfca07kbA08ax1hxskEmSJEmSJGmi2CCTJGkIVZltCJwJ7LDC008e0/KHA4vHtNbaXJg6gCRJkiRJktQPG2SSJA2oKrP1gS8Au63yqf2qMltnDBGOHcMa8+EEmSRJkiRJkiaKDTJJkgZQldki4FPAXqv59EZreL7N9XcC7j/KNebpBuCy1CEkSZIkSZKkftggkySpT1WZLQA+BBywlpf93YhjrG3tcTovL+qYOoQkSZIkSZLUDxtkkiT1753AEXO85sBeI21UutIg+2bqAJIkSZIkSVK/bJBJktSHqsxeDfzDPF56D2CPEWXIgQePovYAvpU6gCRJkiRJktQvG2SSJM1TVWbPB17TxyVPHlGU/enG1/BbgPNSh5AkSZIkSZL61YU31yRJ6ryqzJ4GvKvPy0Z1DtmTRlS3Xz/Ki/rG1CEkSZIkSZKkftkgkyRpDlWZ3Rf4INDvmWI7VGW2Q8tZFgCPbrPmEL6ROoAkSZIkSZI0CBtkkiStRVVmi4FPA9mAJdqeItsB2KjlmoP6XOoAkiRJkiRJ0iBskEmStHbvAXYZ4vq2zyF7SMv1BvX7vKi/nzqEJEmSJEmSNAgbZJIkrUFVZkcAzx6yzB5VmS1tI0/PQ1usNYzPpA4gSZIkSZIkDcoGmSRJq1GV2Y7AKS2UWgDs3EKd5boyQWaDTJIkSZIkSRPLBpkkSauoymwh8DFgSUslW2mQVWW2AcNt99iWy4HzUoeQJEmSJEmSBmWDTJKkO3sRsFuL9dqaINsOWNhSrWF8Ki/qZalDSJIkSZIkSYOyQSZJ0gqqMtsWeG3LZdua+tqipTrDWAb8R+oQkiRJkiRJ0jBskEmStLL3ARu0XLOtCbK7tVRnGP+TF/VvU4eQJEmSJEmShmGDTJKknqrMngUUIyi9aVVmeQt1ujBB9u7UASRJkiRJkqRhLUodQJKkLqjKbFPgbSNcYhegGrJG6gmyi4CvJM5wJ1WZrQ/cB7g7sCmwySqPDXsvXbaax/XA1b3HVSv8ugIuyYv6trH9RiRJkiRJkjQ2NsgkSWq8Eth4hPV3Bs4eskbqBtlJeVEvS7V4VWbrArvR/FnuCOzQe2zFaKbib67K7FfA+cBPlz/yov7LCNaSJEmSJEnSGNkgkyTNvKrMtgaeO+Jl2jiHLOUWi1cBHxrnglWZLQYeCuwJPLr368VjjLAe8KDeY8Vcv+dvDbPlzbOLUzYPJUmSJEmS1B8bZJIkweuAdUe8RhsNspQTZG/Ki7oe9SJVmW0BPBV4CvBwRv/3Moh79R5PWuG5uiqznwMfzIv6g2liSZIkSZIkab5skEmSZlpVZrsAh41hqZ2qMlsw5JRRqgmyPwAnj6p4VWab0zTFngY8itFslzhqGbAl8KXUQSRJkiRJkjQ3G2SSpFn3ZsbTkMmArYFLB7m4KrMlwIZtBurDa/OivrnNglWZLQCeCDwfeBywsM36CdwAHJAX9ZWpg0iSJEmSJGluNsgkSTOrKrMHA/uOccmdGLBBRrrpsQuBj7RVrCqzDDiKpjG2fVt1E1sGHJEX9fmpg0iSJEmSJGl+bJBJkmbZC8e83jBniKU6f+z/5UV9+7BFqjK7B/BS4NnA0qFTdcs/5UX9udQhJEmSJEmSNH82yCRJM6nXsHnqmJe9yxDXbtZaivn75LCNn6rM7gq8nGZibHErqbrlE3lR/0vqEJIkSZIkSeqPDTJJ0qx6LrDOmNfcaIhrb20txfz8kebPaCBVmS0G/oGmOTbM77vLzgOOTh1CkiRJkiRJ/bNBJkmaOb3mzXEJlh5mguz61lLMbRnwrLyo/zLIxVWZPRP4F+Aerabqlt8Df5cX9c2pg0iSJEmSJKl/NsgkSbPoMGDTBOsOM0lVt5ZibiflRX1WvxdVZbYp8H7g79qP1Ck3AAfkRV2lDiJJkiRJkqTB2CCTJM2iYxKtOwkTZBcCJ/Z7UVVm+wIfAvLWE3XLMuDwvKh/mjqIJEmSJEmSBmeDTJI0U6oy2xp4SKLllwxx7TgmyG4DjsiL+sb5XlCV2QbA24ETRpaqW16ZF/XpqUNIkiRJkiRpODbIJEmz5mkJ1759iGvHMUH2xryofzDfF1dl9mDgY8D2o4vUKR/Li/pNqUN0XQghAJukzqE73AbcEGO8JXUQSWmEEO4CrJs6R4fdEmO8NnUITYYQwgLSbNU+Sa6OMS5LHUJaLoSwENg4dQ5xC3AzzdfdmDqMtJwNMknSrHlGwrVvHeLaG2i291vQUpZV/QB4w3xeWJXZQuCfeo9Z+V7iv4CjU4eYEJsD/5s6hFYWQriV5t+RejX/Xd1z1wGXABcBl8UYh/n3S1JaHwCemjpEh10eQtgmxnhb6iCaCLvRfN+sNVtI83OL1BXbAL9JHUJ/E0K4nV6zbIXHzcBNwDW9x9W9xzWr/Pdq4MoY4zjPadcUW/S61795x9Qh1HnXv+qfX3556hDz8brXv3kBsEPqHOq86171zy//Y+oQGr+qzO4DPChhhIHfYM6LOlZl9leG26ZxTW6k2VpxzjeGqjLbDvg46bapTOHfgRfmRe0P+ppk6wAb9R79ui2EcClNs+w3q/z3cu8AlTThtgSeCHwxdRBNhONTB5CkKbAQ2KD3GEgI4U/ApTQ39V2yyq8vjzEOs4OPZsgi4FepQ6jzTmNy7jhcB/83rbmdChyaOoSSeHri9YedwKgZTYPsxLyoL5zrRVWZHQv824gydNU/50U9r8k6aYotAu7Te6zqphDCb2maZRcB3wW+HmO8boz5JGlYJ2CDTHMIISwFDkmdQ5IENDuXbM7qb95dfoPfT4GfAOcDP4kxutOJ7mRWtkWSJAmau4NTGrZBdj2QtxFkBe/Mi/o9c72oKrO3ACe2vHaXReC5eVG/N3UQqePWB3buPZa7PYRwHnA2cBbwfbdolNRxTwwhbBVj/F3qIOq0Q5itG8UkaVKteIPfHUMfIYSKpmG2vGn2I+ASz02cbTbIJEkzoSqzDYA9Esdoo0HWpg8DL17bC6oyC8DJzNZ2MrcAh+VF/ZnUQaQJtRB4RO/xauD6EMLXaZplZwEX+kOopI5ZABxLc76qdCchhAXM1vfDkjSNcmCf3mO5P4YQzgHOAc6JMV6aJJmSCakDSJI0Jo+g2YY1pauHvL7NQ2g/Axy7tnO1qjJbRHPe2Cy9GXA9sK/NMalVGwJPojnP7wLg9yGED4cQDg0h3CVtNEm6w9EhhNTfK6q7diPtWcaSpNG4B3A48EHgkhDCZb2fVZ4ZQrhn4mwaAxtkkqRZsVfqAMCw+123NUH2FZoJqdsBqjJbXJXZ+iu+oPfx55itcxauAh6TF3WZOog05bYEjgI+QXPH5ikhhF3SRpIktgAOSB1CnTVLN4xJ0izbiuZnlf+kubHvghDCG0MIu/amiTVlbJBJkpKryuyeVZntNOJl9hpx/fm4YsjrL2shw7nAQXlR3wJ3NML2zov6puUvqMosA74M7N/CepPid8Aj86L+Ueog0oxZApwA/CyE8M0QwjNCCOumDiVpZtkE0Z2EEJYyWzeNSZL+ZgfgFfTOKwshvD2E8PAQgn2VKeFfpCQpqarMNgW+Chw5wjW6cP4YDD9B9vMhr/8JsH9e1H8FqMpsXeC1wNeWv6Aqs42BEnjMkGtNkl8Cj8iL+qLUQaQZ9yjgVJo7NV/vliaSEnhcCGG71CHUOYfQ3NAhSZptW9Oc4/5t4PIQwkkhhMfYLJts/uVJkpLpTSr9D80dOU8e4VK7kP78MRh+gmyYBtmvgSfkRX0t3HG+2EeAT+ZFfWPvuS2AbwAPHjLnJPkS8Ki8qP+YOoikO+TAPwGXhRA+G0J4rNuZSBqjY1MHUHf0vv44WShJWtXdgOfS3HD82xDCK0MId0+cSQOwQSZJSqIqs/WAzwO7957ariqznUe03I4jqtuvVA2yy4DH5kV9FUBVZgtpmmM/z4v6J73ntqbZfnFUfwddcwvwwryo98+L+i+pw0harUBz88RZwAUhhKfbKJM0Bs8KIayXOoQ6YzfgQalDSJI6bRvgDTQ7YZweQtg3hLAwdSjNjw0ySdLY9Ro0pwJ7r/Kpg0a05P1GVLcff8qL+vphCuRFfR3NWVn9uBJ43PIJqarMAvBemq0B3tp7bgfgW8C9h8k3QS4CHpoX9btSB5E0b/cFPgl8PYTwgNRhJE21zRjtzgaaLE6PSZLmayFwIM1ONZeGEF7ttvHdZ4NMkpTCe1n9Gw+jejOiCxNkP22pzs/6eO3FwN55Uf8WoCqzBcC7gKcDz8yL+vaqzHKaM+C2bClf130E2HX55JykibMn8OPefv+bpA4jaWrZFBEhhKU0549JktSvewKvodk2/hMhhF0S59Ea2CCTJI1VVWZvBY5ew6cfWJXZNiNYtgsTZOe3VGe+2yyeBeyRF/UFcEdz7C3A84AX5EV9SVVm6wKfpfnGbdpdDhyUF/Wz8qK+IXUYSUMJNPv9XxRCeI7bl0gagb1CCDukDqHkDgGWpA4hSZpoATgU+FkI4fMhhIemDqSV2SCTJI1NVWYnAi+b42WtTpFVZbY+zXaCqbU1QTafBtk7gSeucrbWa2j+7D8PfLj33HuBh7eUq6tuA94O7JgX9edSh5HUqo2Bk4EfhRD2TB1G0tQ5LnUApdM789JJQklSmw4AvhtCKEMIj/V85W6wQSZJGouqzI6mmWCaS9vbLN6Tbny9a2uCbG1bLN4MPCsv6hflRX378ierMns58CrgT8BxeVEvq8rsxcBRLWXqqu8Au+VF/dK8qOvUYSSNzAOAb4QQTnWPf0ktOiqEsDh1CCWzG/Cg1CEkSVNpb5pdf74XQjjARllaXXjDUJI05aoyO4hmWmk+Ht47F6stm7ZYa1A3ARe2VOsi4JbVPH8lsFde1B9Z8cmqzF4AvKn34TF5Uf+pKrMnAG9tKU8XXQ4cAzwyL+p+zmyTNNmeAfwqhHBQ6iCSpsJdgaemDqFknB6TJI3aHjS7/HwjhLB76jCzygaZJGmkqjLbG/gvYL5nxATgwBYjdKFB9sO8qG9ro1CvzgWrPP0DYPe8qM9b8cmqzI6j2W4R4P15UX+xKrP7Ap9i/n8fk+QK4PnAdnlRfzAv6mWpA0kauww4LYTwRs8mk9SCE1IH0PiFEJbSnD8mSdI4PAr4QQjhY+6IMX42yCRJI1OV2dbAacB6fV7a5t3/XWiQndVyvRWnoj4O7JkX9R9XfEFVZkcA/9H78GLgxVWZbQR8AbhLy3lSq4AXAffOi/o9eVHfnDqQpOReAXwphLBx6iCSJtrDQwg7pw6hsTsEWJI6hCRp5hwOXBRCeEMIYcPUYWaFDTJJ0khUZbYOzaTSRgNcvndVZm01cbrQIPtqy/V+DtwOvCwv6iPyor5pxU9WZXYw8BFgARCBI4Abgf8Gtm85S0q/pJkY2zYv6neu+ucgaeY9AfhhCOEBqYNImmhutTdDeufA+HcuSUplfeCVwG9CCMe6K8bo2SCTJI3KW4AHD3jtOsD+LeXYrKU6g/oLzRaIbfo2sH9e1G9b9RNVmR1As6Xl8q/x/5IX9XeBtwOPazlHCjfT/P72zIt6597E2F9Th5LUWdsA3w0huFWWpEE9M4TgNNHs2A14UOoQkqSZlwPvA74VQtgxdZhpZoNMktS6XpPmRUOWOaCNLMDiluoM6mt5Ud/eZsG8qL+TF/WZqz5fldkTgE8Di3pP/Qh4XVVmRwMvaDNDAj8DTgS2zIv6sLyov5U6kKSJsRj4rxDCO0IIi+Z8tSStbCnw9NQhNDZOj0mSuuRhwPkhhFeEENZJHWYa+QOiJKlVVZltRbO937B2a6EGNFsLptT29oqrVZXZXsDpwLq9p26i2VpxB+CkcWRo2e3AuTS/p9Pzor4sbRxJU+BFwINCCE+NMV6TOoykiXIC8KHUITRaIYSlNOePSZLUJesCbwQODiE8O8b4k9SBpokNMklSa6oyCzTb3921hXLbVmW2JC/qG4ask3L7vduBL456karMHgacQbNX9XIvy4v6gt7nNwXuDzxwhcfOpJ+uW9WFwHnAOcAZeVH7Braktu0FfDmE8NgY4/Wpw0iaGHuEEHaNMf44dRCN1CGA22lKkrrqgcAPQghvAV4fY/Qc9hbYIJMktel5wMNbqrWAponzvSHrDNtgG8bZeVH/7ygXqMpsN+BMVv5h/qvAycs/yIu6Br7Teyy/biGwPSs3zR4IbD7KvD03A1cCvwW+23uclxf1n8ewtiQ9GDg9hLCfP1RK6sPxuP3e1AohLMC/X0lS9y0EXgE8OYRwaIzx/NSBJp0NMklSK6oyuxfNyHebdmH4BlnKCbKPjbJ4VWa70DTDlq7w9F+AZ+dFHdd2be9ctAt6j1NXqHk34AHAPYANe7U3XM2vV/14A5pm5P+u8rhi1edshEnqgL2BU0MIB8cYb0sdRtJEODSE8FKnT6fWbsCDUoeQJGmedgTOCyE8H/hAjHFZ6kCTygaZJKktpwBZyzV3aaFGqgZZDXxuVMWrMtsBOBvYeJVPnZAX9R8HrdubeOt76q0qszBXU06SOubvgPeHEI6OMfrvl6S5ZMBhwH+kDqKROC51AEmS+rQe8D7g0SGEE2KMdepAkyikDiBJmnxVmT0D2HcEpSe5QXZaXtQjWbsqs3sDJXfeDvETeVH/9yjWnIvNMUkT6ijgbb2ttSRpLsf778X0CSEsBQ5NnUOSpAEdRnM22U6pg0wiG2SSpKFUZbYx8K4RlZ/kBtlItlfsbWVZAndf5VN/oDkDTpLUnxfR7OMvSXN5ILBH6hBq3SGsfJ6vJEmTZgeaJtmRqYNMGhtkkqRhvZo7TzK1ZdOqzLYYssYNrSTpz4/zoi7bLto7H6wEtlrNp4/Mi/r/2l5TkmbEG0IIz00dQtJEOCF1ALWnNxF4fOockiS1YDHwkRDCe0MI66QOMylskEmSBlaV2TaM/k2CYafIUkyQvbrtglWZbUZz5th2q/n0O/KiPqftNSVpxrwnhHBA6hCSOu8ZIYSNUodQa3YDHpQ6hCRJLToO+GJvC2HNwQaZJGkYrwPWHfEak9Yg+35e1Ge0WbAqs7sCZwH3W82nfwm8ss31JGlGLQA+EELYLHUQSZ22GDgidQi15rjUASRJGoEnAN8MIax6PIdWYYNMkjSQqsx2YTyHWU9ag6zV6bGqzJYCZwIPWM2nbwYOz4v6pjbXlKQZthlwUuoQkjrv+N7WfJpgvTvrx/HzjCRJKTwAOC+EsHPqIF1mg0ySNKg3MZ6vI8M2yMZ5Btl38qI+s61iVZktAb4EPHgNL3lOXtTnt7WeJAmAg0MIT08dQlKn7QQ8InUIDe0QYEnqEJIkjdA9gW+HEIrUQbrKBpkkqW9VmT0C2G9My92vKrNhvl5VjG+KrLXpsarMFgNfAB65hpeckhf1h9taT5K0kpNDCFukDiGp045PHUCD600A+ncoSZoFS4EzQwhuEb0aNsgkSYN42RjXWgzcY9CL86KOwC/ai7NG38yL+uw2CvUmxz4P7L2Gl3wXeGEba0mSVmtj4D/cQk3SWhwcQtgkdQgNbDfgQalDSJI0JouA/wwhHJU6SNfYIJMk9aUqs22AJ4152bsOef04tiF8VRtFVjhz7HFreMmVwFPzor6ljfUkSWt0IHBY6hCSOms94MjUITSw41IHkCRpzBYAH3KSbGU2yCRJ/Xoe4//6sdGQ14+6QXZOXtTfGLZIVWYbAyVr3lbxNuDgvKivGHYtSdK8vDuEMPAUs6Spd7yTppMnhLAUODR1DkmSElgAfCSE4NfBHhtkkqR5q8osA45OsHTXJ8iGnh6ryiwHvg7svpaXvSgv6nOHXUuSNG8bAe/zDXBJa7A9sFfqEOrbIcCS1CEkSUokAB8LITwjdZAuWJQ6gCRpohwJ3CXBusNOkP0ciIzmxpCzhm1aVWW2Jc3k2PZredlHgZOGWWdQVZmtR3MO3JarPDal2V5oxce6wDrAjcD1vcd1K/z6auAy4FLg0ryo6zH+ViRpEPsC+wNfTB1EUicdD5yTOoTmp3fDw/Gpc0iSlFgAPh5CuD3G+OnUYVKyQSZJ6sffJ1p3qAZZXtR1VWYXA/dpKc9yN9BsOTmwqszuDZwNbL2Wl/0EOCEv6mXDrDXPPPcAdqU5tHz5f+81wvWuodcsA34GnAt8Ly/qG0e1piQN4BUhhDNijCP/d1jSxDkohLB5jPFPqYNoXnaj+f5WkqRZtxA4NYRwc4zxC6nDpGKDTJI0L1WZPRDYMdHybUytnU/7DbIX5UV90aAXV2W2I01z7O5redk1wEGjahhVZbYV8ERgH+BhwOajWGctNuk9dgcO7j13a1VmP6Jplp0LnJsX9TVjziVJK3oozTZqTolIWtU6wLOAt6QOonk5LnUASZI6ZHmTbM8Y449Sh0nBBpkkab6ennDthS3UOJ+/NWDa8Lm8qN8/6MW9huNXgc3W8rIIHJIX9WWDrrOaddeleZN3H5rG2A5t1W7ROjRvRj8UeCmwrCqzX7Nyw+yShPkkzaZXYoNM0uodF0L41xhjTB1EaxZCWAocmjqHJEkdswHwxRDCQ2KMf0gdZtxskEmS5qvN5lK/bm2hxk9bqLHcFcCxg15cldlDgDOZe+vIV+RFfdag66yy5u7AUTSHkm/cRs0xWkAzvbgjvT/3qsyuAL4NnJ0X9fsSZpM0O4reD43fSx1EUudsCzyW5uYnddchwJLUISRJ6qC7AWeEEB4ZY7w+dZhxskEmSZpTVWa7AfdOGOG2Fmqc30INgGXAkYNu+VeV2aOBM4BsjpeeBrx1kDVWWCsHDqdpjO08TK0OujtwEPDJ1EEkzZRXAAemDiGpk07ABllnhRAWAMenziFJUofdH/hkCOHAGGMb78NNhJA6gCRpIjwt8fpDf2HOi/qPwFUtZHlHXtRnD3JhVWb70EyOzdUc+xXwrLyolw24zv2qMvsocDnwNqavObbcCXlRfzZ1CEkz5YAQwi6pQ0jqpANCCGs7V1Zp7QY8KHUISZI6bl/g31KHGCcbZJKk+Tgo8fpt3bky7DaL59NMD/StKrMnA18A1p/jpdcBT86Luu+R9qrMHlKV2enAL4AjmO5J8VfkRf2B1CEkzaT/lzqApE5aCBydOoTW6LjUASRJmhDPCyE8L3WIcbFBJklaq6rMtgS2SxyjrQbZOUNceyNwaF7Ut/R7YVVmhwGfBtaZx8uPyIv6oj7rP7oqsxI4j2brrwX9Zpww78iL+k2pQ0iaWU8PIaT+uiipm44NISxMHUIrCyEsBQ5NnUOSpAnyjhDC7qlDjIMNMkmaUFWZ7VeV2Y5jWOrRY1hjLje0VOe0Ia59aV7UF/R7UVVmxwIfo7mreC6vz4v6C33U3rS3leLXgb37zTahPgq8NHUISTMtAC9JHUJSJ90T2Cd1CN3JIcCS1CEkSZog69CcR7Y0dZBRm+atlyRpalVldjDwCZo36Ppu2vQdkegpAAAgAElEQVSpCw2y/22jSF7UF1Zl9ivgfn1e+sW8qE/ud72qzF7I/Pdu/jLwmj5qH0Vzvtgm/eaaYGcARw96Nps0Yu8E/pw4w0JgKbDRWh7TPmE6LgeHEJ4/S4dXS5q3E4AvpQ6hlbi9oiRJ/bs38N4QwqExxql9H8YGmSRNmKrMjgQ+SPNG6KOBd494yalpkPV8lv4aZL9jgPMkqjJ7JfCGeb78YuDwvKjjPOreB3gv8Jh+M024bwFPy4vaN6PVVe+JMV6cOsTahBAWATsDD13hcd+koSbXJsCjGG7rXknTad8Qwr1ijL9PHUTQ2x5q19Q5JEmaUM8AzqZ5H3IqucWiJE2QqsyeC3yYv23Xt2dVZiObBqjKbAtg+1HV70PbDbL5qoDH5kV91bwvKLMFVZn9C/Nvjv0VeHJe1H+Zo+66VZn9M/BzZq859lPgSXlR35g6iDTJYoy3xRjPjzH+R4zxqBjjDjSNnicCrwcuSxpw8jw5dQBJnRSAY1KH0B2cHpMkaTjvDiHslDrEqDhBJkkToiqzE4G3rPL0ZsBOwC9GtOwjRlS3H7cB825QzSUv6p9UZXYpsM0cL/0/4Al5Uf92vrWrMgs0Wyr+Qx+Rjs6L+udz1H0kzdRYv1tDToNLgH3yor42dRBpGsUY/wycCZwZQngt8CTgBcBeKXNNiINCCC+MMc45/Stp5hwTQnh9jPHW1EFmWe/clENT55CkhL4JfCDBugFYH1i8lsfGNGd3bkmzTby6azHwqRDCHjHGqbtx2QaZJE2AqsxeD/zTGj69F6NrkHXhDpFqBGdOfZbm/LY1+SuwX17UP51vwarMFgLvA57dR4535EX9ybXU3IimKXoss3lu0JXA4/KivjJ1EGkWxBhvB04HTg8h3J+m2X8YzQ+3urN7ALsD308dRFLn3A3YH/hc6iAz7hBgSeoQkpTQb2OMH0sdYi69Gxq2pGmYLW+a3Ydmi9z7Mpvvh3TNTsCbgBemDtI2t1iUpI6ryuwdrLk5BqM9I2yHEdaer8tHUHNt2yzeAhyUF/V35lusKrN1gI/TX3Ps68A/rqXmPsAFNNvCzOI3g3+mmRy7JHUQaRbFGH8WYzwG2Jpmwkyr5zaLktbk+NQB5PaKkjQJYozXxRh/FWP8SozxAzHG18QYD4sx7gjchebs3xcCHwN+CbiDQxrPDyHskTpE22yQSVJHVWUWqjJ7L/CiOV46ygbZjiOsPV9r3X5wQN9l9eeaReDwvKi/Mt9CVZmtD3yG5uDS+boceHpe1LetoebzgDOALfqoOU0uAB7czwSfpNGIMVbAfjQN/dsTx+mip4QQZvEmBklze0IIYdvUIWZVCGF3mskDSdIEizFeH2M8N8b4rhjjM2OMO9NsybgfcArwh7QJZ0oA3h9CWCd1kDbZIJOkDqrKbBHwUeZ31+NmVZm1vhViVWYLaEbZU/tZ2wV7WzaevppPHZ8X9afnW6cqsw2ALwAH9LH8zTQTan9aTb2FVZn9O/BuYGEfNafJmcDD8qK+OHUQSY3YeCuwJ/4Auqr7MJvnQ0qan2NTB5hhTo9J0pSKMd4QY/xyjPG5wFbA/YFXAN8B2j6iQyt7AFO2zaINMknqmKrM1gU+TXPuy3ztNYIoW9EcxJnaqKaITlvl45flRT3vw2urMltK08x5XJ/r/n1e1D9YTb0M+Dzw/D7rTZN3AvvnRX1t6iCS7izG+B3ggcCXU2fpGLdZlLQmzw4hrJs6xKzpnWVzaOockqTRizEuizH+PMb4phjjI4DNgefRbMWo0XjtNE3J2yCTpA7pTW2dCvxdn5fu1X4ath9BzUG0PkHW8w3gmt6v/yUv6rfN98KqzDYGzqbZB7sfb8+L+oOrqbclcC7NFgGz6Fbg2LyoX5QXtVu4SR0WY/wz8BTgvNRZOuSg1AEkddbm9P99vYZ3CLAkdQhJ0vjFGK+OMZ4E7ELzns0naM6aV3sWA6dMy1bzNsgkqVvewmBvtO3ZdhCaH+hT+31e1P83isK987++CJySF/Ur53tdVWY58HWg34NJTwNOXE293YDv04ypz6Krgcf2M70nKa0Y4000U1OXp87SEQ8IIXRh4lpSNx2fOsAMcntFSZpxvcmyc2OMhwNb0rwfc0niWNPk8UzJtLYNMknqiKrMjgVeNuDlm1dl1vYZKJu2XG8QPxlx/dfSjN7PS2/S65s0dyL147vAEXlRx1XqHdird7c+602LXwIPzov6m6mDSOpPjPFK4EDgxtRZOiAAO6YOIamz9g4hdGVnhqkXQtgd2DV1DklSd8QYr4ox/itwX+Bo4I+JI02Lt4cQstQhhmWDTJI6oCqzAjh5yDJ7tRBlRZu0XG8Q5SiL50V92apNqzWpymxb4Fv0v/XkxcCBeVGv9CZyVWYvAT4LbNBnvWnxJeBheVFfmjqIpMHEGH8MHJU6R0fcP3UASZ3mRNP4+GctSVqtGONtMcYPAfcB/hEYyY5FMyQHXpg6xLBskElSYlWZ7Qh8Blg0ZKm2t1nsQoPsrNQB4I5tEL8DbN3npX8G9s2L+qoVai2qyuwU4G3M7tfhtwMH5EV9feogkoYTY/xv4JTUOTrABpmktXlWCGH91CGmXQhhKVOy3ZMkaXRijDfGGN8K3Bv4V+DmxJEm2YkhhM1ShxjGrL4xJ0mdUJXZXYAzgI1aKHefFmqsKPUWi5fnRf3rxBmoymw/mm0Q8z4vvZmmCXTRCrUCcCpwQnsJJ0oNHJUX9UvnO7knaSK8EQ++tkEmaW02Bp6SOsQMOARYkjqEJGkyxBj/HGM8kWanoDNT55lQGwKvTB1iGDbIJCmt9wPbtlRry5bqLHfXluv1K/n0WFVmxwNfYLBtEI/Mi/rbqzx3EvDUoYNNpq8CO+dF/Z+pg0hqV4zxjzRfz2bZA0IIC1KHkNRps3qD1Di5vaIkqW8xxt8D+wLPBf6aOM4kem4IYZvUIQZlg0ySEqnK7Fjg4BZLblaV2Xot1ru9xVqDSNYgq8osVGX2JuA/GOxr5T/mRf2pVWq+mtl8Y+Ra4Ji8qJ+QF/XvUoeRNDJvZranyDal/0ljSbPlkSGEnVKHmFYhhN2BXVPnkCRNphjjshjjKcADge+lzjNh1gFelzrEoGyQSVICVZndD3hXy2UXAPdosd4NLdbq1+3A2SkW7jUZPwG8fMAS76XZw3rFmscDrxku2UQ6A7hfXtQfTB1E0mjFGC8HZv3/626zKGkuTjiNjn+2kqShxRh/AzwS+GfgtsRxJslhIYQHpg4xCBtkkjRmVZktBj4FLB5B+Xu2WCtlg+ysvKivGveiVZltTLMV4DMGLPE/wPPyol62Qs2nACe3EG+S/AZ4Sl7UT8qL+orUYSSNzZtIP32ckg0ySXM5MoQwyNbdWosQwlLg0NQ5JEnTIcZ4W4zxDcCjgD+lzjMhFgCvTx1iEDbIJGn83gbsPKLabZ5DlnLf5Y+Pe8GqzLYBvg3sOWCJnwBPz4v6jjuMqjLbi2YabVa+3l4FPI9mauyzqcNIGq8Y4x+AH6TOkZANMklzuQvwtNQhptAhwJLUISRJ0yXGeB7wMODC1FkmxP4hhB1Th+jXrLxhJ0mdUJXZI4HnjHCJNhtkqSbIauBz41ywKrPdgfOAHQYscTmwf17U169Q84HA54E2z4XrqhuBfwG2y4v6pBWbhJJmztdSB0hoVDe/SJous3gm7ai5vaIkaSRijJcADwfOTZ1lQrwodYB+2SCTpDGpymwd4BSaseNRmYYtFj+XF/XYpteqMnsS8A1g8wFL/AV44opbCVZlti3NdotLh0/YadcBbwfukxf1K/Oivi51IEnJzXKDbNPUASRNhIdM6hkdXRRC2B3YNXUOSdL0ijH+GXgczXEpWrtnhhAGfX8tCRtkkjQ+L2b0d5dPwwTZ2LZXrMrsucDpwKBnQfwV2Dcv6l+sUHNz4CvAFsMn7Kzf0fzvecu8qF+aF/UfUweS1BnfAW5JHSKRu6QOIGliHJ86wBRxekySNHIxxptozrt8W+osHbce8NzUIfphg0ySxqAqs62BV41hqUmfILsYKEe9SFVmoSqztwInMfjXwluBJ+dFfd4KdTekmRzbbviUnfRd4OnAvfOi/rcVt5SUJIAY4400TbJZtGEIwZ+vJM3H4SGEDVOHmHQhhKU0b1ZKkjRyMcYInAi8O3WWjvv7EMLi1CHma1HqAJI0I97D4FNK/Zj0CbLX50V9+ygXqMpsfeAjNI2eQS0DDs+L+qurPH8EcLch6nbRBcB/AafmRX1x6jCSJsLXgL1Sh0hgAZDRbD8rSWuTAYcA70sdZMIdAixJHUKSNDtijMtCCC8ENgOekTpPR20KHA68P3WQ+fAOR0kasarM9gH2G9Nym1Vltm5LtcbdIPsNI95esSqzjYGzGK45BvCcvKj/e9Un86I+OS/qu9NMkD0L+BBw0ZBrpXAp8FbgQXlR3y8v6jfYHJPUhwtSB0jIbRYlzZfbLA7P7RUlSWPXmyQ7Elj1pmn9zYsnZXcNJ8gkafReN8a1FtBMkV3SQq1xN8hGOj1Wldm2wJeB+w5Z6pV5Ub93bS/oNZMupplUoyqzHHhk7/Eo4IHAwiFztOlK4Bya7S2/lhf1pYnzSJps16QOkNBdgD+kDiFpIuwaQtg9xvjD1EEmUQhhd2DX1DkkSbMpxnhLCOEpNLtn7JE6TwftQPP+1zdSB5mLDTJJGqGqzA5g/F8ocyavQXYRzTZ+I1GV2R7AGcDmQ5Z6B/Cmfi/Ki7oCTus9lp9V9jCahtlDaM6OuzvjmTy4BvhF7/Fz4Ny8qH85hnUlzY6rUwdIyAkySf04ATgmdYgJ5fSYJCmpGGMdQtgX+Dawfeo8HfRMbJBJ0uyqymwB450eW66tyaQ/t1RnPkY2PdZrUn4SGPaA0I8AL82LetmwmfKivp5mFH+lcfyqzDagaZTdrfffu6/h4w2BvwI1cH3vseKvV/34OuC3wC/yor5y2PySNIdZnyCTpPk6JITwkhjjtamDTJIQwobAoalzSJIUY7y6N0n2A2D91Hk65uAQwvNijDemDrI2NsgkaXSeAjwgdYgh/Bq4FVhnxOtcCJw6isJVmf098O8Mf+bm54Fj22iOrU1e1H+laWT9dm2vq8os5EUdR5lFkoZgg0yS5mcDmkPsT0odZMIcCixJHUKSJIAY4y9CCC/Br+er2hA4kOam9c6aiIPSJGnS9KbHXpM6xzDyor4FuGAMS72u7emxqsxCVWZvA97D8F/rvg48Iy/q24YO1hKbY5K6LMZ4M+M/x7IrbJBJ6tfxIYQFqUNMGLdXlCR1zSk0N1drZc9MHWAuNsgkaTQeD+yUOkQLfjLi+hfQ8p0kVZmt36v5khbK/Rg4MC/qm1qoJUmzZFbPIbNBJqlfu9CcTat5CCHsDuyaOockSSuKMS6jOVf0itRZOuYJIYQtUodYGxtkkjQaz0kdoCXnj7j+69qchqrKbBPgbODgFspdBDwxL+rrWqglSbNmJOdKTgB/vpI0iONTB5ggTo9Jkjopxng1zdbJIz2eY8IEOn5uqD/ASVLLqjK7J7B/6hwtGeUE2a+A/26rWFVm9wa+CzyihXKXAY/Li/pPLdSSpFm0SeoAiVybOoCkifT0EMLGqUN0XQhhQzr+JpskabbFGM8B/i11jo7p9DaLNsgkqX3HAgsTrt/muS+jnCB7eVvTY1WZPYSmOXafFsr9HnhMXtS/b6GWJM2cEMIiZnerQRtkkgaxHh1/86gjDgWWpA4hSdIcXsfsbjm/Og8IIWydOsSa2CCTpBZVZbaIZs/hlFr7IpwX9bXApW3VW8EH8qL+YhuFqjI7EDgH2KyFcpfTNMcua6GWJM2qWZ6C+L/UASRNrONDCAtSh+g4t1eUJHVejPFa4FWpc3TME1MHWBMbZJLUricBd0uc4aqW67U9RfYb4IVtFKrK7PnA54DFLZS7Atg7L+pLWqglSbNs09QBEnKCTNKgdgD2TB2iq0IIuwO7ps4hSdI8vR+4IHWIDtk3dYA1sUEmSe06OPH6N+RFfVPLNds8h+w24PC8qIfaBrIqs1CV2duBfwfauNP2Sprm2G9aqCVJs25Wzx8DJ8gkDef41AE6zOkxSdLEiDHeBrwkdY4OKUIIbdzc3jobZJLUkqrM1gX2Sxyj7ekxaHeC7LV5UX9/mAJVmd0FOB14cTuR+BNNc+zClupJ0qyb5QaZE2SShvHUEEIb24ZPlRDChjTnj0mSNEnOBL6aOkRHLAYenTrE6tggk6T2PAZYmjjDKA4BbWuC7NvAm4YpUJXZ/YDv02xl2YargSIvasfeJak926QOkJATZJKGsQ5wVOoQHXQosCR1CEmS+hFjXAacmDpHh3Rym0UbZJLUnienDkCzVWCr8qK+nOEbb9fRbK14+6AFqjI7CPgesP2QWZb7M01z7Bct1ZMkNR6TOkAiEahTh5A08Y4PIfhezcrcXlGSNJFijD8FvpY6R0fsF0Jo45iUVvlNlyS1oCqzBcABqXMAvx5R3R8Mef3z8qK+bJALqzJbWJXZG4DTgGzIHMv9H/DYvKh/1lI9SRIQQlhER7fOGINre3eJStIw7g3snTpEV4QQdgd2TZ1DkqQhvDt1gI7YlvZuem+NDTJJasfuwN1ShwB+NaK6Xxji2k/lRf2xQS6syuyuwBeBVw6x/qquBR6XF3VbW0dKkv5mV9JvN5yK549JassJqQN0iNNjkqRJ90Xgd6lDdMSjUgdYlQ0ySWpHV/6BH9VZWp+j2TqqX39gwB/wqzLbmWZy7YmDXL8G1wGPz4v6hy3WlCT9zSxPPfwmdQBJU+PAEMIWqUOkFkLYkOb8MUmSJlaM8Xbg5NQ5OuKhqQOsygaZJLXjYakD9Ixkgiwv6go4t8/LIvDMvKj/r9/1qjI7GDiPZouZttTAPnlRf7/FmpKklc1yg+ynqQNImhqLgGenDtEBhwJLUoeQJKkFHwRuSh2iAzrXIFuUOoAkTYkuNMiuyIv6uhHWPw3Ys4/XPz8v6q/3s0BVZguBNwL/2M9183AtTXPsvJbr3klVZpsCWwH36j3uCdwVWNx7bLDCrxcAf+09bug9/koz6XYJcCFwYV7UV4w6tyQNK4RwF+CRqXMkZINMUpuOCyG8pXfX+axye0VJ0lSIMV4TQvgEcHTqLIndL4SwNMY4yvcv+2KDTJKGVJXZvYB7pM4B/GLE9T8LvJOmqTOXV+VF3df4eFVmGwOnAo8fINvaXE2zrWKrZ45VZbY+8CCa8+eWHx6+LU0DrFVVmV1Pr1m2yuOivKhvbHs9SRrQP9A0/2eVDTJJbdqK5vvi/0kdJIUQwvLvryVJmhYfxQbZAmAPoEwdZDkbZJI0vIenDtDz7VEWz4v68qrMvg88ZI6XvjMv6tf3U7sqswfQnHO2zaD51uBKoMiLeuitJ6syWwIUNGeiPQzYifF9Hd2QvzXiVrSsKrPf87eG2beBrwyyraUkDSOEsBR4UeocCd0C/Dp1CElT5wRmtEGG02OSpOnzHeAaYJPUQRJ7KDbIJGmqPDh1gJ6vj2GN01h7g+yjwIv7KViV2SE0ezG3PXXwe5rm2G8HLVCV2bbAfr3HXsB67URrzQKau4uX32H8fOC2qsy+A3wJ+HJe1KOeLJQkaP79uWvqEAn9KsZ4a+oQkqbO/iGELWOMl6cOMk4hhA1pzh+TJGlqxBhvCyGcARyZOktinTqHzAaZJA3vvqkD0Bz0+b0xrPMZ4K1r+NzngaPzol42n0JVmS0C3gy8pKVsK7qYpjn2u34vrMpsE+AI4FnA/dsONgaLaM6K2xN4S1VmvwO+TNMw+5pbMkpqW++NzL5ujphCbq8oaRQCcAzwmsQ5xu1QYEnqEJIkjcDnsUH20BDCghjjvN4/HDUbZJI0vO1SBwDOy4v65lEvkhf1pVWZ/YTm7K0VfR14el7Ut82nTlVmmwKfAvZuNyEAvwIemxf1/873gqrMAvA4mr2gDwTWHUGuVLYCntN73FSV2Tk0zbIv5UV9WcpgkqbG3wMbpw6RmA0ySaNyTAjhDTHGeX2fPSXcXlGSNK2+SnOT+/qpgyS0KXBPmp2fkgupA0jSJKvKbCGwdeocwDfGuNZpq3z8I+CA+TboqjLbFfgho2mOnQ/sNd/mWFVmG1ZldiJwKXAmcDDT1Rxb1fo0Z6i9B7i0KrNfVWV2bOJMkiZYCGEP4NWpc3SADTKpW25IHaBF96DZ7nsmhBB2A3ZNnUOSpFGIMd4AnJ06RwdsnzrAcjbIJGk496IbDZWvjXGtFRtkvwb2yYv6+vlcWJXZEcC3aaaa2vY9YO+8qK+aR467VmX2auAy4C00f4+zaHP8xkzSgEIIdwdOZ7bvflzuZ6kDSFrJF4Bpmrg6PnWAMZqm3+u5qQNIkjrp86kDdEAXjqsBbJBJ0rC6sL1iRdN0Gou8qH9Ns43hH4DH50V99VzXVGW2TlVm7wQ+ymjeSP0G8Li8qP8yR47NqjJ7E01j7DXM9pZgtwJPzYv60tRBJE2eEMJimubY3VNn6YALYoxzfi2UNFZ/ojmDdVrsE0LYOnWIUeudaXlo6hwt+s/UASRJnVSmDtABTpBJ0pTYJnUA4DN5Ud8+5jVPoWlI/WGuF1ZltjlwFvCCEWX5CrDv2qbYqjJbryqzV9BspfhyYOmIskySF+RF/fXUISRNnhDCAuADwB6ps3TEqlsPS+qGaWpOLABmYVvsQ4ElqUO05Ac0NxVKkrSqy4BrUodIzAkySZoSWeoAwKfGvWBe1O/Ji/rCuV5XldkeNGeUPXpEUU4HDsyL+q9ryfAk4JfAG5meH7iHdUpe1KekDiFp8oQQFtJsTTtNd/gP67OpA0harTOYrjefjg4hrJM6xIgdlzpAi6apQStJalGMcRnNjRSzzAaZJE2J1D+k/pGO7m1fldlRwLeALUe0xMeBp+VFffMa1t++KrMv05xBce8RZZhEXwP+IXUISZOnd+bY2cDLUmfpkMuA81OHkHRnMcZbgFNT52hRDhyYOsSohBB2A3ZNnaMltwKfTB1CktRps94g2yqE0ImzrG2QSdJwUjfIPp0X9bLEGVZSldm6VZm9B/gwsN6IlnkbcGRe1LeuZv1Qldk/AT8Hnjii9SfVz4CD86KepkPrJY1BCOHxNI2gvRJH6ZrP9u4AldRNH0kdoGXHpw4wQtP0e/tijHGaphclSe2b9QbZAmC71CEAFqUOIEkTbt3E638i8forqcpsC+DTwCNHuMxL8qJ+xxrW35zmz+SxI1x/Ul1Ac27cn1MHkTQ5QgiLgNcC/4/mhxitzO0VpW77MfALYOfUQVry2BDCdjHG36YO0qYQwoZM19a9bq8oSZrLrDfIoNlm8RepQzhBJknDSTlBdl5e1D9MuP5KqjJ7KM15Y6Nqjt0KHLaW5theNNMNNsfu7GLgsXlR/yl1EEmTIYSQhRCeS/MDyyuwObY6VwLfTR1C0pr1JjynrVkxTed0LXco03NW8FXA/6QOIUnqthjjlcDlqXMkNqojWfpig0yShpNyguxdCddeSVVmxwDfAO4+oiVqYL+8qP9rNWsv31LxbOBuI1p/kv0O2Dsv6itSB5HUfSGEbUMIb6f5Ye0kOnR4cgedHmOMqUNImtMngNtTh2jRs0IIo9rGPJVpavp9IsZ4p23gJUlajR+lDpDY5qkDgFssStKwUk2Q/RH4TKK171CV2RKaRt3RI1zmKuCJeVHf6RuHqsw2Az4OPH6E60+yK4AiL+rfpw4iqbtCCDnwcOBI4ACcFpsvt1eUJkCM8X9DCF8B9k2dpSWbAgcBp6YO0oYQwm7ArqlztGjaJhYlSaNzaeoAieWpA4ANMkkaVqoG2cl5Ud+WaG0AqjJ7IM0P5juMcJlLgCfkRX2ncxaqMtuzt/6optYm3SXAPnlRX5w6iKTu6E0d/H/27jzMjqrO//g7hx0KQRQKEBRxAR1RAcX1Jzqljvu+geKgKMFtxt12tFvtHrUVwRUcQCEJiyhgABFFKEBRVERBFgFBWUSg2AkVAiQ5+f1RHRMgS3f63nvu8n49Tz3dJLfv+SQk6e77qfM9Tweevdy1XcpMPeoO4OzUISRN2iz6pyADmEmfFGQ0v5Z+cVGM8cLUISRJPeMfqQMk5g4ySeoDKUYsLgAOSbAuAFWZzQD+G/gK7f31/wl4RV7U1QrW/x/gC8BabVy/l50HvCov6ltSB5EGyItCCO28YWAyZgAZ8PCJa9Pl3n848AjgSaQdD9wvDnWEltRTfgLcSfPvYj/YPYTwpBjjZamDTEcIYWOa88f6hbvHJElTMejTftxBJkl9IMUOsoPyor4twbpUZbYFcATtvwP3DOANeVHf/aD1NweOBP6jzev3spOAPfOivid1EGnAHJY6gDrmPuAbqUNImrwY470hhB8A70udpYX2BT6SOsQ07QlslDpEiyymOe9OkqTJsiDrAiF1AEnqcZ0uyG4CRju8JgBVmb0UuIj2l2M/AF65gnLsiTS7yizHVu47NMWi5Zgktc/hMcabUoeQNGX9trtn7xDCBqlDTNO+qQO00M9jjNXqHyZJ0r8M/IjFEELy868tyCRpejo9pmrowcVRu1Vltm5VZvsDp9H+uzu+AbwjL+r7H5RhR5qzXrZp8/q9ahHwsbyoP5QXdUwdRpL6WAS+ljqEpDVyHnB56hAttCnw5tQh1lQIYVdgl9Q5WmhW6gCSpJ5TAYM8tn0DmiMCkrIgk6TpWdzBtX4HzOngekt3bZ0LfLwDy30S+OiDC56qzJ4EnAVs1YEMvehaYPe8qA9MHUSSBsCxMca/pw4haepijEvov11k+6UOMA0zUwdooTtozrmTJGnSYowRd5FtkTqABZkkTU+nPpFF4EN5US/pxGJVmc2oymxvmpGGu7Z5uQXAm/Ki3v/Bv76qzJ5MU45t2eYMveoE4Ol5UZ+bOogkDYjx1AEkTcuRNF9X94vnhBCemjrEVIUQNqY5f6xfHCmjY5UAACAASURBVBtjvC91CElST/pn6gCJuYNMknrcNR1a54i8qM/vxEJVmW0CHAMcQfsPzb6JZvfTCSvI8RSacqwrDu3sMvcC78uL+k15Ud+ZOowkDYhTYowXpw4hac3FGP8JnJ46R4v14k6sPWn/9xmd1G87EyVJnVOnDpDYeqkDWJBJ0vRc04E17gI+3YF1qMrsOcCFwNs6sNxFwG55Uf9hBTl2As6kC7Zad6HzgGfmRf1/qYNI0oBx95jUH/qtzNgrhJD87usp2jd1gBa6gubrc0mS1sQ9qQMkZkEmST3umg6s8fm8qG9p5wJVma1VldlngXOA7dq51oSfAs/Pi/ohIyqrMnsqTTm2eQdy9JJbgfcCz86L+pLUYSRpwJwTY/xN6hCSWuJEYF7qEC20MZ25ua0lQgi7ArukztFCsyfOt5MkaU0sSB0gMQsySepx17b5+f8CfKedC1Rlti1QAmPAWu1ca8I3gNfmRX33CrI8jaYce2QHcvSKCBwC7JAX9fc6dQ6dJOlfltChndyS2i/GuAD4YeocLdZLYxZ7KevqLKE5106SpDU16DvI1k8dwIJMkqYhL+p5wB1tXOK/8qJe1K4nr8rs9cCfgd3btcZyFgPvz4v6I3lRL15Blp1pyrFHdCBLrzgXeFZe1PvlRX176jCSNKC+5e4xqe/MSh2gxZ4xsTOrq4UQNqY5f6xfnBFjvD51CElST3MHWWJrpw4gSX3gGuDhbXjeE/KiLtvwvFRltiFwIJ27g3Me8Ja8qE9bSZ5dgDNoz+9jLyqBL+ZFfVbqIJI04P4OfCZ1CEkt91vgSuAJqYO00Ey6/2yvPYGNUodooX47z06S1HmDvoMseUHmDjJJmr5r2vCcV9Om8mrijK8/tOv5V+Aa4LkrK8cmzAD+D7iwI4m60xLgZJozxl5sOSZJXWGfGOP81CEktdbEmVH9Vm7sGUJ4WOoQq9HtBd5U3A3MTR1CktTz3EGWmDvIJGn6Wn0O2XyaM7pua+WTVmU2A/ggsD+d+wT0W+B1eVHfvKoH5UX9R+CPwP9UZbYV8DLg5cBLgE3bnjKtO2jOwfhuXtQXpQ4jSfqX78YYz04dQlLbHElzBu+M1EFaZCPg7cB3UwdZkYkRkLukztFCx8UYB/2uf0nS9A365xILMknqA9e0+Pn2zov64lY+YVVmmwOHA69q5fOuxg+Ad+dFfe9UPigv6huBI4AjqjJbC3gOywqznemPFzEWAz+nuXP55Lyo70ucR5L0QNcBn0odQlL7xBivCyGcCRSps7TQzBDC/03skOs2nZpe0Sn9tgNRkqSBZEEmSdN3TQuf60t5UR/fwuejKrMXA3OArVr5vKvxBeALeVFP65vzvKgXA7+euD5bldmWwH/QlGUvpbfOLLuP5tdxKnBMXtQ3Jc4jSVq598YY704dQlLbzaK/CrKnAc8Cfpc6yPJCCBvTnD/WL/5O83W9JEnTtWHqAIklv2HcgkySpu+aFj3PT4HhFj0XVZmtSzM25hN0btdVDeyVF/WJ7XjyiVJpNjB7YnfZzsBTgCcvd21Hd+wyWwJcDPwCOB04Jy/qQZ8tLUm94PAY4y9Sh5DUEXNpvn7NUgdpoZl0WUEG7EEzArJfzIkxxtQhJEl9YYPUARKzIJOkPnA1TRkynVLmCmDPvKhb8o1WVWaPpxlx+IxWPN8k/ZXmvLHLOrHYxO6y8yeuf6nKbEPgSTywNHsysD0Q2hTnXuAy4CKaUuxi4MLVnb0mSeo6/wQ+ljqEpM6IMc4PIfwIeHfqLC30thDCR2OMd6QOspx+G684J3UASVLfcAdZYhZkkjRNeVHPq8rsIpqRJmtiHvDavKjntSJPVWZ7AQfT2TthTwHekRf1XR1cc4Xyor4H+OPE9S9Vma0P7EBTlm0JrEtzGOh6k3x/AVAtd9008fYfwFUThZ0kqXfNA14RY7wzdRBJHTWb/irI1gf2Ar6VOghACGFXYJfUOVroVzHGq1OHkCT1jUHfQXZv6gAWZJLUGmexZgVZBN6eF/UV0w1QldkmwEHA26f7XFM0SnPeWFePGcmL+l7gzxOXJEnLuw94TYzxotRBJHXcr2nOlNo+dZAWmhlC+HaMcVrnAbdIv+0em506gCSpr7iDLLF2jZqSpEFz5hp+3Ehe1KdMd/GqzF4BXEJny7G7gdfnRf25bi/HJElahQjsGWP8Zeogkjpv4iypfhuZ92Tg+alDhBA2BvZMnaOFFgDHpw4hSeorg76DzIJMkvrEr4Cpjtg7Pi/qL05n0arMHlGV2VHAT4FtpvNcU3QF8Ky8qE/s4JqSJLXD+2OMP04dQlJS/VaQQXfs3NoD2Ch1iBY6IcbYkrH4kiRNcAdZYhZkktQCE2dvXTCFDzkJeMearleV2YyqzN4M/IXOj1T8CU05dlmH15UkqdU+F2M8JHUISWlNnCnVb7tI3xxCeGTiDN1Q0rWS4xUlSa2WpQ6QWPIzyCzIJKl1Jjtm8RjgTXlRr9FdElWZbQWcAPwI2GJNnmMavgC8bqIQlCSpl30XGEsdQlLXmJU6QIutC/xnqsVDCLsCu6Ravw2upzl3WpKkVurkNKhudHfqABZkktQ6k/mG6TBgr7yoF031ySd2je1Ns2vs9VP9+Gm6m6YY+7znjUmS+sAJwIdijEtSB5HUNY4H5qcO0WIzQwgzUq2daN12OTLGONWR+pIkrVQIIWBBdnPqABZkktQ65wALV/HzB+ZFve+aFExVmT0G+BlwBLDpGuZbU1cAu+VFfVKH15UkqR1+DrzDFzolLS/GWNOU5/3kCcCLOr1oCGFjYM9Or9tmjleUJLVaDqyTOkRC82OMyW9OsiCTpBbJi3o+8IeV/PQX8qL+2FSfsyqzUJXZB4BLgP+YTr41dALNeWOXJ1hbkqRW+zrw6hhj8ln3krrSrNQB2mC/BGvuAWyUYN12+X2M8YrUISRJfefRqQMkVqUOABZkktRqKzqH7ON5UX9+qk9UldkTgbOB79D5QzsXAv8FvNnzxiRJfWAhsE+M8aMxximPOZY0MH4JXJs6RIu9PoSQd3jNfhuv6O4xSVI7bJs6QGIWZJLUh5Y/hywCM/OiPmAqT1CV2dpVmX0C+DPw/1oZbpKuBp6XF/W386L2bBZJUq+7GXhRjPHw1EEkdbcYYwTmpM7RYmsD7+rUYiGEXYFdOrVeB9wPHJs6hCSpLw36DrLk54+BBZkktdq5wH3AIuCdeVEfOpUPrspsJ+C3wFeB9Vsfb7XmArvkRb2yUZGSJPWSC4Fnxhh/kzqIpJ7RbwUZwL4hhE69/tNvu8dOijHekTqEJKkvDXpB5g4ySeo3eVHfS7OL7M15UR892Y+rymzdqsw+D/wReEab4q3KQuDDwBvzor4zwfqSJLXaccDzY4zXpQ4iqXfEGK8Cfp06R4s9FnhJuxcJIWwM7NnudTrM8YqSpHbZPnWAxLqiIFs7dQBJ6kNvzYt63mQfXJXZM4HDgae0L9IqXQu8JS/q8zq1YFVmM4BNgIdP/NAiYPHE26Xv35MX9cJOZZIk9ZUR4H9jjI4KlrQmZgPPTx2ixfYDTmvzGnsAG7V5jU6qaP/vmSRpcO2aOkBiXTFi0YJMklpssuVYVWYbAl8APkq6Hb0nA+/Ki/r2Vj5pVWYPA/5tuWs74BHAIyfebsbqPwctqcrsFuAG4J/Lvf0n8FfgwqkUkZKkgXATMDPGeHLqIJJ62nHAt4ANUgdpoVeHEB4VY/xnG9fot/GKR8cYF6UOIUnqPyGErYGtU+dI7NrUAcCCTJKSqMrsBcD3gccnirAI+BTw9byop3V3/UTR9/+AFwFPo9kJt820E8IMYIuJ6+kr+PklVZn9HfgTcMHSKy/qrtiiLUnqqCXAQcBnY4x3pQ4jqbfFGO8KIfwYeHvqLC20FrAPMNqOJw8h7Ars0o7nTsjxipKkdnlm6gBd4IrUAcCCTJI6qiqzjYGvAO9LGOM6mjGQv1uTD67KbG1gN6CYuJ4DrNu6eJM2A3jcxPXm5fJdTjMK5efA2RPnwkmS+tefaHaNnZ86iKS+Mpv+KsgA3htC+FKbdkX12+6xC2KMF6UOIUnqW4NekC0Crk4dAizIJKljqjJ7GXAosG3CGKcA/znVkYpVmQWaHWLvAF5Pc35Yt9px4vpvYEFVZr+iKcx+lhf15UmTSZJa6W7gs8BBMcbFqcNI6jtnAtfTmskI3WIb4OXAT1r5pCGEjYE9W/mcXcDdY5Kkdhr0guxvMcaFqUOABZkktV1VZpsBBwL/mTDGQuAzwAF5UcfJflBVZjsBe9EcuN2LLw5sAPzHxHVgVWYXAXOAo/OivilpMknSdBwHfKTNZ+lIGmAxxsUhhCOBT6fO0mIzaXFBRvO9wkYtfs6UFgHHpA4hSepPIYQZwDNS50isK8YrggWZJLVVVWZvpDkTJU8Y4xJgr7yoL5zMg6syWxd4J/BBmjPF+slTga8BX6nK7Bc0ZdmJjmGUpJ5xNfDBGOOpqYNIGgiz6b+C7BUhhMfEGK9t4XP223jFU2OMt6QOIUnqW9sDm6UOkdhfUwdYKqQOIEkddB/wHeCT7V6oKrO8KrPjgONJV44tAfYHnjmZcqwqs02qMvsUcA1wGP1Xji1vLZrxMj8AbqrK7NCqzJ6aOJMkaeVuBoaBp1iOSeqUGOMVwBqd29vFZgDvadWThRB2BXZp1fN1CccrSpLa6SWpA3QBd5BJUgfdBxwCfGVkeOiGdi5UldkMmt1XB5L2bpCrac4aO2d1D6zKbGvgwzR3fj6s3cG60CbAe4H3Tuwq2z8v6jMSZ5IkNS4Gvg78IMbobl9JKcwCnp06RIvtE0IYbdHZH/u24Dm6ye3AT1OHkCT1tdemDtAFLMgkqQPuBf4P+OrI8NCN7V6sKrNdgW8Dz2n3WqtxGPCxvKjvXtWDqjJ7GPBZ4L+A9ToRrAe8FHhpVWYX0Ixi/FFe1IsSZ5KkQXQqTTFWxhiXpA4jaaD9EPgm/fX18lbAq4EfT+dJQggbA3u2JFH3OCbGeF/qEJKk/hRCeBhQpM7RBS5PHWApCzJJ/WgBy4qxm9q9WFVmWwBfBPahGVmSyk3Ae/KiXuUdj1WZrUUzVmUU2KITwXrQzsDRwJeqMvsGcEhe1AsSZ5KkfreAZqzVN2OMXfMNk6TBFmO8M4RwIvDW1FlabCbTLMiAPYCsBVm6ieMVJUnt9DJgndQhErumm876tCCT1E8WAAcD+48MD1XtXqwqs3WA9wNfoBnTl9JxwPvyor5tVQ+qyuzFNOMfd+pIqt73GJodDB+vyuxzwBF5UcfEmSSp39xIc0boITHGVX4ek6REZtN/BdlLQwiPizH+bRrPMbNlabrDX4A/pg4hSeprr0sdoAt01fmuFmSS+sE9wEHA10aGh27uxIITRdM3gSd3Yr1VuBP4APCDvKhXOoKqKrOtaMpDPxGvmUcB3wM+XJXZ0Op26UmSVusm4Oc0oxRPijHenziPJK3K6TRl/lapg7TYe4GhNfnAEMKuwC6tjZPcbMf6SpLaJYSwLvCK1Dm6gAWZJLXIfJYVYx3ZmluV2XbAAcAbOrHeapwOvDsv6utX9aCqzPaguTN/s46k6m9PAU6pyuws4JN5UZ+fOpAk9YjFwLnAzyaui2KM7siV1BNijItCCEcCn0ydpcXeHUIYWcObFPZteZq0InBU6hCSpL62O+knUHUDCzJJmqaapvA5YGR46NZOLFiV2YbAp2i+KV6/E2uuwgLg48B3V7Nr7JE0u8be3KlgA+RFwHlVmc0B9smLenHqQJLUhf5Js0vsZ8AZMca7EueRpOmYTf8VZJsDrwd+OJUPCiFsDOzZlkTpnB5jvCF1CElSX3t36gBd4H7gwtQhlmdBJqmX1MC3gANHhoc6ckZJVWYzaAqmrwHbdmLN1fgd8M68qK9c1YOqMnsNcCiQdyTVYLoYOMByTJL+5RbgIuAXNKXYJY6qktQvYox/CSH8AXhm6iwtNpMpFmTAHkDWhiwpzUodQJLUv0IIWwNvSp2jC1wQY7wvdYjlWZBJ6gV30xRjX+9UMQZQldlTJ9bdvVNrrsJC4PPAV/OiXrSyB1Vltg7N2Wjv61CuQRSB/YGRvKg9M0fSoFkEXAVcDlyx3NsrYoy3pwwmSR0wm/4ryF4UQtghxnjFFD5mZtvSpHEXcFLqEJKkvrYfdjHQZeMVwf8pkrrbPJqy5xsjw0Mde9GtKrPNgFGakil0at1VuATYKy/qVW5BrspsS+B44HkdSTWY/g78Z17Uv04dRJLa5H6aHds18A8eWoRdHWNcmC6eJCV1LHAgsG7qIC22L/CxyTwwhLArsEt743Tcj2KMC1KHkCT1pxDCejQFmSzIJGlS7gK+AXxzZHjojk4tWpXZWsB7gS8Cm3Vq3VVYQjPacSQv6ntX9cCqzJ4NnABs3YlgA+p7wEfyoq5TB5HUlWYBd6YOsQKLaHZi1w+6VvRj82OM7oyVpJWIMd4WQvgJ8MbUWVps7xDCZ2KMq/yeY8K+bU/TebNTB5Ak9bW30pz7KTgrdYAHsyCT1E3uZFkx1tEXGasyewHNOMWndXLdVbiaZqfSOat7YFVm7wEOov/uZO0WFfCevKhPSR1EUlf73xjj31KHkCS13Sz6ryDbjOZclKNW9aAQwsbAnh1J1DlXAeemDiFJ6k8hhBnAf6XO0SXOjzFWqUM8mAWZpG5wB/B14Fsjw0N3dXLhqsy2Bb4KvK2T667GYcDH8qK+e1UPqsosAN8G3t+RVIPpx8DMvKhvTR1EkiRJXeE04GZgi9RBWmw/VlOQAXsAWQeydNKcGOOS1CEkSX3rhcCuqUN0iVNTB1gRCzJJKd1OM8P/2yPDQ/M6uXBVZuvTzNn/H2DDTq69ChWwT17UP13tA8tsXeBomjs91XrzgA/lRT0ndRBJkiR1jxjjwhDCUcBHU2dpseeFEJ4SY7xkFY+Z2bE0nXNk6gCSpP4UQlgLOCB1ji6y2tc7U7Agk5TC7TSfIL6ToBibAbyGZsfaYzu59mocD7xvMjuVqjLbCJgLvKTtqQbTWcDeeVFflzqIJEmSutJs+q8gg6YA+9CKfiKEsCuwS2fjtN1ZMcZrUoeQJPWtdwI7pw7RJW4Bzk8dYkUsyCR10m3A14CDRoaHVjk+sB2qMnsSzRlnL+302qtwJ/AB4Ad5Ua92tEdVZpvRbEl+VruDDaDrgTHgsMn8v5AkSdJgijFeFEK4gP570WuvEMKnYoz3rODn9u14mvabnTqAJKk/TZzb+aXUObrIz2OMMXWIFbEgk9QJf6cppo4YGR6qO714VWabAJ+juRuym/7dOx14d17U10/mwVWZbQ38Avi3tqYaPDcBXwYOyYv6vtRhJEmS1BNm0X8F2SbAW4Ejlv/BiRf59kySqH3mAyekDiFJ6lufArZMHaKLdOX5Y9BdLxRL6j+/oTlj7KSR4aHFnV68KrMA7E1TfnTTIdo1MAQcPMWdSv8OPLI9kQbSrcBXaP4/rOguWUmSJGllfkAzNr7fXlfZjwcVZMAeQJYgSzudEGPs+M2bkqT+F0J4DPDx1Dm6SAROSx1iZfrtCzlJ6S2mOU/r6yPDQ79PFaIqs+cA3wSemSrDShwHfHSyu8aWlxf1UVWZHQ+8G/gEsF2Lsw2KO2hGfX4rL2q/KZYkSdKUxRhvCSGcArwudZYW2y2EsHOM8YLlfmxmsjTt43hFSVLLhRBm0EzRWi91li5SxhjvSB1iZSzIJLXK3cBhwLdGhoeuTRWiKrOdaM6Rem2qDCtxFfDBvKindcdEXtT3AgdXZXYozZ2cQ8CTW5BvEMyj+SLlwLyo70odRpIkST1vNv1XkEFTiO0HEELYFdglbZyWuw44O3UISVJfmkl/fm0wHXNSB1gVCzJJ03UtzU6t748MD81LFaIqs8cDX6ApjWakyrEC99EcyvnViXKrJfKiXgQcWZXZUTSfeD9N9+2W6xbzgW8D++dFfXvqMJIkSeobp9KM7e63MehvDyF8IsZ4N7Bv6jBtMCfGGFOHkCT1lxDCTjQ3ZmuZ+cDc1CFWxYJM0pr6Pc3M/bkjw0OLUoWoymxbYJhm7OBaqXKsxM9pdo39rV0LTJxhNheYW5XZi2mKsn9v13o9Zj5wCPCVvKhvTh1GkiRJ/SXGeH8I4Rjgv1JnabEM2HPi17Zn6jBt0NV3skuSek8IYUPghzha8cGOjzHOTx1iVSzIJE1FBH4MHDgyPPTblEGqMtuCpgx6H933yed64L+BuRMFVkfkRX0GcEZVZs+i+b15Dd21m65TzgUOB37oGWOSJElqs1n0X0EGy84dy5KmaL1zY4xXpg4hSeo73wCelDpEF+r6m1IsyCRNRg18H/jmyPDQ1SmDVGW2KfBx4MPARimzrMAi4EBgLGUxkxf174HXVWX2JOAdwNuA7VPl6ZCK5pPu4XlRX546jCRJkgbGhcBFwFNTB2mxnWlG2Peb2akDSJL6SwjhLcB7U+foQv+gB878tCCTtCrX05wv9r2R4aE7UwapymwjmjszPwlsmjLLSvwKeH9e1JemDrJUXtSXAZ8BPlOV2W4057O9Bdg6abDWuQk4BTgROG3iXDZJkiSpY2KMS0IIs2nGz/ebPHWAFrsP+FHqEJKk/hFCeB7NbnI91FG9cOanBZmkFTmf5hu8E0aGhxamDFKV2Xo0B0N/hu78Bu1mmh1tR3VynOJU5UV9HnBeVWYfA/4f8CqgAJ5Ob41h/DPwE+Bk4Pxu/j3vpNGx8Q1GhocWpM4hSZI0oI4Gvkr3nYmsBzoxxpj0xk9JUv8IITwN+CmwQeosXerI1AEmw4JM0lJLgJNoRgT+emR4KGnxUJXZ2sA7gc8Bj06ZZSWWAN8FPpsX9R2pw0xWXtQR+OXERVVmjwBeRFOWFcAT0qV7iMXAJcBvgd8BZ+VFfV3aSN1ldGx8I+B/gG1p/r5IkiSpw2KMVQjhZzQ3oal7zUodQJLUH0IIjwdOAzZJnaVLnRljvCx1iMmwIJN0D3A4zfliV6UOU5VZAN4MjAJPTBxnZc4H3pcX9fmpg0xXXtS3AcdPXFRltiXwNJozFJZeOwLrtjnKAuBvwJXAH2gKsT+kPMutm42Ojc+gGZf5NWAbHBUjSZKU2iwsyLrZjcDpqUNIknpfCOFRNJ9TunHSVbfomdHTFmTS4LoB+DZwyMjwUPIdUFWZzQBeCfwvTUHTje4EPg0clhf14tRh2iEv6ptozvY6bemPVWW2DrAD8Bhgq4lr6+XebgasQ/M5ZZ3lrrWA+TS/b3dNvF36/k00hdhVE9cNjkucnNGx8Z2AbwEvTBxFkiRJy5wC3AE8PHUQrdBRMca+/B5OktQ5IYRH0Lxmtl3iKN3scuDnqUNMlgWZNHguoGnxjxsZHro/dRiAqsxeBHwReE7qLKswG/hkXtQ3pw7SaXlRL6QZdXhJ6iyDbHRsfFPgC8AH8HwLSZKkrhJjvC+EcAzN12rqPrNTB5Ak9bYQwvbAqTQ3kWvlDowxxtQhJsuCTBocP6E5X+yXqc8XW6oqs91oirEXp86yCpcC78+L+lepg2gwjY6NB2BvYBzYPG0aSZIkrcJsLMi60R9jjJemDiFJ6l0hhOcCJwGPTJ2ly90CHJU6xFRYkEn97S6af5S+PTI8dEXqMEtVZbYTMAa8NnWWVZgPfB745sQOKqnjRsfGd6MZhbpb6iySJElarfOBvwBPTh1ED+DuMUnSGgshvJXmc8l6qbP0gINjjAtSh5gKCzKpP/0aOAw4fmR46J7UYZaqyuzxNCPi9gBmJI6zKicAH8mL+h+pg2gwjY6N5zS7K/dJnUWSJEmTE2NcEkKYBXw1dRb9y0LgB6lDSJJ6TwhhBvBpmtdntHr3AQenDjFVFmRS/7gNmAN8b2R46C+pwyyvKrNtgWHg3XT32Ul/Az6UF/XPUgfRYBodG98B+Cjwn3hnkiRJUi86imY0dkgdRACcEmO8NXUISVJvCSFsChwE7Jk6Sw85IsZ4c+oQU2VBJvW+M2l2i80dGR66L3WY5VVltjnNnRbvp7tf7L8P+DLwlbyo700dRoNldGx8BvA84OPAa+ju3ZWSJElahRjjjSGE04CXp84iwPGKkqQpCiG8FDgceFTqLD1kAc1xOj3HgkzqTRVwBPD9keGhq1KHebCqzLYC/pvmgOoscZzVOQ34YF7UXff7qP42Oja+FvB6mmLsWYnjSJIkqXVmY0HWDW4FnA4iSZqUEEIG7A/slzpLD/pmjPGG1CHWhAWZ1DuWAD+n2S12ysjw0MLEeR6iKrMdaV7s3wtYN3Gc1bka+CRwQl7US1KH0eAYHRvfCNibZpTi9mnTSJIkqQ1OAu4CNkkdZMAdE2O8P3UISVL3CyG8AJgFPDZxlF50B/CV1CHWlAWZ1P2uB74PHD4yPHRd6jArUpXZc2nKptemzjIJtwKjwCF5UfvNkjpmdGw8Bz5IM3J0s8RxJEmS1CYxxntDCMcCM1NnGXCOV5QkrVIIYRvgc8A+eOTFmvpyjPHO1CHWlAWZ1J0WA6fQ7Bb7+cjw0OLEeR6iKrMAvBL4FM35Sd1uPnAAcEBe1PNSh9HgGB0b35Fmt9g76e6z+CRJktQ6s7AgS+li4ILUISRJ3SmE8EhgiOZGZl+rWXPXA99JHWI6LMik7nI18D3giJHhoRtTh1mRqszWA/YEPgE8KXGcyVgEHAqM5UV9U+owGgyjY+MbAq+iKcVemTiOJEmSOu/3wF+BJ6YOMqBmxxgdpS9JeoAQwsbAR2iOiNk4cZx+8PkY44LUIabDgkxKbyEwl2a32Jkjw0MxcZ4VqspsE2Bf4MPA1onjTNaPgM/mRX1l6iDqf6Nj4+sCLwXeRjNuNEubSJIkSanEGJeEEGYBX0qdZQAtBo5OHUKS1D1CCJsD76IpxjZPHKdfXEYfjDO2IJPSuYKmFJszMjx0S+owK1OV2VY0pdh+wMMSx5msM4FP5UV9fuog6m+jY+NrWAHWLAAAIABJREFUAS8A9gDeiGeLSZIkaZkjgS/imSaddlqM0ekhkjTgQggzgBfS3PD/BmDdpIH6z/tjjItSh5guCzKps+4FjqMpxn49MjzUtSMfqjLbkeauir3onU8gF9KciXZ6XtRd+3ur3jY6Nj4D2I2mFHsLsFXaRJIkSepGMcbrQwhnAC9JnWXA9Pzd7JKkNTdxvtjeNMXYE9Km6VuHxxjPTh2iFSzIpM64mKYUO2pkeOiO1GFWpSqz5wKfpBkR1yuuBj4LHJsXdVeOqFTvGx0b34mmFHsb8NjEcSRJktQbZmFB1kl3AienDiFJ6qwQwnbAKyaul9A7N/v3oluAT6QO0SoWZFL7zAeOpSnGzuvy3WIBeCXN7qvnJY4zFbcCo8AheVHfnzqM+s/o2PjjWFaK/VviOJIkSeo9JwJ3AxunDjIgjo0x3ps6hCSpvUII6wDPZ1kp9uS0iQbKR2KMt6cO0SoWZFJrLQROoynGTh4ZHro7cZ5VqspsPWBPmtb/SYnjTMV84ADggLyo56UOo/4xOja+JbA7zYzqFwI7pswjSZKk3hZjvCeE8EPgPamzDAjHK0pSn5k4S+zRwC7AzhNvX4A3n6TwC+CY1CFayYJMmr4IlDSl2NxuH6EIUJXZw2jm8H4E2DpxnKlYBBwKjOVF7aHLmrbRsfGteGAhtkPKPJIkSepLs7Eg64S/Ar9PHUKStGZCCAHYAtgGeDwPLMQ2SxhNjXuB98cYu3ZK2pqwIJPW3Dk0pdgJI8NDVeowk1GV2VbAfwPvAx6WOM5U/RD4bF7UV6UOot41Oja+NcsKsd2xEJMkSVL7/Qb4G/C41EH63Ox+e9FOkqZpgxDC5gnWDcAGy13rP+i/N6ApvLZ50PUo7Cu62edjjH9LHaLV/AMnTc0faEqx40aGh/6ROsxkVWW2I/BxYC9675DKM4FP5UV9fuogKYyOjQfgs8Cvgd+PDA/NTxyppzyoEHsh8MSUeSRJkjR4YoxLQgizac5PVnssAY5MHUKSusweE5c0XWcDX0sdoh0syKTVu5imFPvhyPBQT7XkVZk9B/gk8FpgRuI4U3Uh8Cng9LyoB/kuwBnAFybeXzQ6Nv4nmrLs18BvRoaHbk6WrIuMjo3PoLnTaAeac8OeRlOIPSFhLEmSJGmpOViQtVMZY+yZm1glSeohtwJvjzEuTh2kHSzIpBW7kmWl2KWpw0xFVWbrA2+iGaP43MRx1sTVwGeAH+ZFHVOH6TJrA7tNXB8FGB0b/ytNWXYucClw2cjw0F3JErbZ6Nj4hjS7wHZgWRm29P2NEkaTJEmSVirGeG0I4SzgRamz9KnZqQNIktSn9o4x3pA6RLtYkEnLXEdzztWxwAUjw0M9tWupKrMdgH2BvenNgytvpbmj8pC8qO9PHaaHPHHievfSHxgdG78R+Atw2YOuqhf+XC+3G2z58mvp+49OGE2SJEmajllYkLVDDcxNHUKSpD50YIzxp6lDtJMFmQZdBfyIphT73cjwUE/tWKrKbF3gdcB+9O43WvOBA4AD8qKelzpMn9hq4ioe9ON3jo6NXwXctIKrWvr+yPBQ3Y5Qo2Pja9GUt49cybUV7gaTJElS/zoBOAjIUgfpM8fFGD2rWZKk1voj8OnUIdrNgkyD6HbgeJpS7Fcjw0M9Nz+1KrPtgffS7BraInGcNbUIOAQYy4u6Sh1mQGwKPGN1DxodG58P3AncO4krAOsB6068Xf79pW/XBx5OU4712ll4kiRJUkvEGOeHEI6nmfqh1nG8oiRJrVUDb4sx9v2ULwsyDYq7aUYuHAucMTI8tDBxnimrymxt4FU0u8VeSu8WDYtoDqj+cl7UV6UOoxXaCHdwSZIkSe0wCwuyVroaOCd1CEmS+sy7YowD8bqtBZn62QLgJzSl2M9GhofuTZxnjVRlti3wnolr68RxpmMBcCjNKMV/pAoxOjaeATuPDA/5TZQkSZKkTjsHuAbYLm2MvjEnxthTRyVIktTl/ifGeHzqEJ1iQaZ+dDJNKfaTdp2l1G5Vma0FvAyYCbySZoxdr7oT+A7wrbyob0kVYnRsfFPgQ8CHgdPwLkNJkiRJHRZjjCGE2cDnUmfpE3NSB5AkqY/MAsZTh+gkCzL1lZHhofuB16bOsaaqMtsK2IfmfLFHJ44zXRVwIPB/eVHPSxVidGx8c+AjwAeAh6XKIUmSJEkT5mBB1grnxBj/njqEJEl94pfAzBjjktRBOsmCTEqsKrMAFDRni72G3v97eQ3wVeCIvKiTjbUcHRvfBvg4sC+wQaockiRJkrS8GOPfQwi/Al6QOkuPm506gCRJfeJK4A0xxvtTB+m0Xn8hXupZVZltDryLpsB5XOI4rXApzRbcY/OiXpQqxOjY+PbAp2h+b9dJlUOSJEmSVmE2FmTTsQA4LnUISZL6wO3AK2OMt6cOkoIFmdRBVZnNoPkmaD/gjfRHgfN74MvAT/KiTnY48ujY+JOBTwN7AGulyiFJkiRJk3Ac8G1gw9RBetSPY4zJRvlLktQnFgCvizFemTpIKhZkUgdUZbYZ8E5gJrBj4jitcgbwJeDsvKiTzaYdHRvfGfgM8AZgRqockiRJkjRZMca7QwgnAHulztKjHK8oSdL03Au8OsZ4TuogKVmQSW0ysVvs2TS7xd4CrJ82UcvMBb6cF/UfUoYYHRt/Hk0x9vKUOSRJkiRpDc3GgmxN/BM4M3UISZJ62H3Aa2KMZeogqVmQSS02cbbYW2nOFtspcZxWWQwcDXwlL+q/pAoxOjY+AyhoirEXpsohSZIkSS1wFvAPYNvUQXrMkTHGxalDSJLUo+4HXhtjPD11kG5gQSa1QFVmGwOvA/YEXkL/nIF1L/B94Gt5UV+TKsREMfYq4LPAbqlySJIkSVKrxBhjCGEOzQ2AmjzHK0qStGbuB14fYzwtdZBuYUEmraGqzNajGe+3B/Aa+meEIsA84GDgG3lRV6lCjI6NrwW8Cfgf4KmpckiSJElSm8zGgmwqfh9jvDx1CEmSetBC4I0xxlNTB+kmFmTSFFRlthawO81OsTcCm6ZN1HK3AN8ADs6L+s5UIUbHxtcB3gEMAU9MlUOSJEmS2inGeGUI4Vzguamz9Ah3j0mSNHXzgbdYjj2UBZm0GlWZzQCeQbNT7G3AVmkTtcV1wP7A4XlR35MqxOjY+PrAu4FPAo9JlUOSJEmSOmgWFmSTcT/ww9QhJEnqMTcBr4wx/il1kG5kQSatRFVmO9KUYnsCj08cp10uB8aBY/KiXpgqxOjYeAbMBD4ObJkqhyRJkiQl8CPgW/TX2P52ODnGeHvqEJIk9ZDLgJfHGK9NHaRbWZBpZe4GfgecCwzM1suqzLYB3kpTiu2SOE47/RH4MjA3L+qYKsTo2PimwIeADwObpcohSZIkSanEGO8KIcyluUFTK+d4RUmSJu9s4A0xxjtSB+lmFmRa6u80Zdi5wG+AS0eGhxanjdQZVZltBryJphR7ATAjbaK2OpumGDs9L+olqUKMjo1vAXwE+ACwcaockiRJktQlZmNBtioVcFrqEJIk9YhjgHfHGO9LHaTbWZANpvuB81lWiP12ZHjoprSROqsqs42AV9OUYi8D1kmbqK3mA0cBB+dFfVHKIKNj49vQjFHcF9ggZRZJkiRJ6iJnADcAW6cO0qWOjjEmOxZAkqQe8r/ASIwx2eaIXmJBNhgqml1hSwuxP40MDw1ce1yV2TrAS2lKsdcCG6VN1HaXAwcDc/KivitlkNGx8ScCHwPeRX+XkZIkSZI0ZTHGxSGEOcBQ6ixdyvGKkiSt2u3AXjHGgTkuqRUsyPpPBC5iWRl2LnDNyPDQQDbGVZkF4Hk0pdibgUekTdR2i4GTgIOAsxKPUQzAK4APAv+RKockSZIk9YjZWJCtyIUxxqTTUCRJ6nK/Bd4WY7wudZBeY0HW++6i+QuwtAw7b2R46O60kdKqymwG8DSaUuxtwLZpE3VEBRwKHJoX9fUpg4yOjT+cZqfYB4DtU2aRJEmSpF4RY7w8hPB74Fmps3QZd49JkrRyBwCfdhTxmrEg6z1/5YG7wy4bGR6KaSOlN1GK7UJzrthbgCelTdQx59DsFpubF/X9KYOMjo3vRLNb7B3AhimzSJIkSVKPmo0F2fIWAcekDiFJUhe6E9g7xnhS6iC9zIKsu90LnMeyMux3I8NDt6SN1D2qMtsQKGhKsVcyOIcZzweOBA7Oi/rilEFGx8bXpjnP7UPA7imzSJIkSVIfOBb4BrBu6iBd4tQY482pQ0iS1GV+C7w9xnh16iC9zoKse1wDXAxcstzbK0aGh5LuCuo2VZltDbyKphQrgA3SJuqoy2l2ix2ZF/VdKYOMjo1vDrwXeB+wTcoskiRJktQvYox3hBBOojlDW45XlCRpefcAnwYOijEuTh2mH1iQdd6tNAXY8mXYX0aGh+YlTdWllhuduLQU2zVtoo5bDJwIHAyclRf1kpRhRsfGn0GzW+xteEejJEmSJLXDLCzIAG4Hfpo6hCRJXeIMYF93jbWWBVn73ANcygOLsIuBm0eGh5KWHN2uKrMNWDY68VUMzujE5d0EHAoclhf19SmDjI6Nrwe8iaYYcxa+JEmSJLXXL2i+J9wydZDEfhBjvC91CEmSErsL+ChwRIzRXqHFLMimbzHwVx66K+zqkeGhmDJYL6nKbCuW7RJ7MYM1OnF5v6LZLTY3L+qk4zVHx8YfBcwE9gXylFkkSZIkaVDEGBeFEI4CPp46S2KOV5QkDboTgQ/EGG9IHaRfWZBNzXU8cDfYJcDlI8ND3tE0RROjE3dm2S6xZ6RNlNR8YA7w3byoL04ZZHRsfAbwPJrdYm/AfyMkSZIkKYXZDHZB9hfg/NQhJElK5Argk8BP3DXWXr74vWK388DdYJcAl4wMD92VNFWPmxid+O8sK8UelTZRcpfR7Babkxd10jPoRsfGNwT2AD4IPD1lFkmSJEkadDHGS0IIf2TwzuFearYvCEqSBtCtwOeBQ2OMCxNnGQiDWpDNA65d7rrmQf/tOWEtstzoxFcBL2FwRycutZhma+xBwNl5USf9czY6Nr4d8H5gH2CzlFkkSZIkSQ8wi8EsyCJwVOoQkiR10P3AN4AvxRjdpNNB/VqQ3cqKi69rgWtGhofuTBetv02MTnw6zS6xVzPYoxOXdxNwKHBoXtT/TBlkYoxiQbNb7NVASJlHkiRJkrRCPwAOBNZJHaTDTvesFUnSADkW+HSM8ZrUQQZRLxZkS4AbWEHxNfH2upHhofnJ0g2gqswyYHeW7RTbJm2irvIrmt1ic/OiTrotdnRsfGPgnTTF2I4ps0iSJEmSVi3GeFsI4Sc050MPktmpA0iS1AEnA1+MMZ6XOsgg68aCbBHwD1Y+/vAfI8ND9ydLJ6oy2xB4HvBC4EXAM+nOP0up3AAcDczOi/rS1GFGx8Z3AD4A7A1snDaNJEmSJGkKZjNYBdk8mmMJJEnqR5Fmh/hXYowXpw6j9pcaS4C7gNsnrjtW8v7tLBuLeOPI8NDiNufSFFRltgHwHJYVYs9i8EY8rM584ATgSOCsvKiT/hkeHRtfn2Z84nuAl6bMIkmSJElaYz8DbgE2Tx2kQ34YY1yQOoQkSS12H3AEsH+M8e+pw2iZyRZk9/PAMuvB5dbKiq+7LLt6T1Vm6wHPZlkh9mxgvZSZulQETqcpxU7MizrpaM/RsfEAPB/YC3gzsEnKPJIkSZKk6YkxLgwhHA18OHWWDnG8oiSpn9TAd4GvxxhvTB1GD7U2cChwG6suvRaMDA8tSRVS7VWV2brAbjRl2AuB5wLrp8zU5f5MU4odkxd18n/YRsfGn0hTir0D2C5tGkmSJElSi81iMAqyq4BzU4eQJKkF/gQcBhwTY5yXOoxWbu2R4aGZqUOos6oyWwd4BssKsecBG6bM1AOWnit2ZF7UyefDjo6NPxJ4K/BOmnJTkiRJktSHYox/DiFcCDw9dZY2mxNj9OZsSVKvupvm9ePDYox/Sh1Gk9PuM8jUBaoyWxvYhWWF2POBLGWmHtGN54q9ima32Cvw768kSZIkDYrZ9H9BdmTqAJIkrYHf0ewW+1GMsU4dRlPjC+x9qCqztWi+cF5aiP0/4GEpM/WQCJwBzKE7zhWbQbPDby/gLcCmKfNIkiRJkpI4Btif/n0d56wY4zWpQ0iSNEkXAz8GjosxXpo6jNZcv35hNVCqMgvAU1lWiL0Ai5Sp6rZzxR7PsnPFtk8cR5IkSZKUUIzx5hDCqcBrUmdpk9mpA0iStBp/oJk29uMY45Wpw6g1LMh60MQZYjvRjEp8IbA7sFnKTD2q284VewTNLrF3As9OHEeSJEmS1F1m0Z8F2dLjDSRJ6iYR+A3N56i5McbrEudRG1iQdbmJ3WFPAHYDnjlx7QyslzJXD+u2c8XWozlP7J3AK4F1UuaRJEmSJHWtnwK3AY9IHaTFTvDMFklSF1gCXAicNXGdE2O8K20ktZsFWRepymwGsA3LirDdgGfg+WHTtfRcsSOBuV1yrthzaEYovhV4eMo8kiRJkqTuF2O8P4RwDPCh1FlazPGKkqRULmFZIfbLGOPtifOowyzIEqrK7BE0Bdjyu8O2TBqqv3TbuWKPozlTbC/gcYnjSJIkSZJ6z2z6qyC7Djg7dQhJ0kD4G3DBctf5McZb0kZSahZkHVKV2UbALjxwd9j2SUP1p247V+zhNOeK7QU8L3EcSZIkSVJv+xPN3e5PSR2kRebEGGPqEJKkvnIPcCVNCXbhxNs/Oy5RK2JB1gZVma0D7MSyIuyZwL8BIWWuPjYf+DHNbrEzu+RcsZfRnCv2KmDdlHkkSZIkSf0hxrgkhDAb2D91lhaZkzqAJKnnLAH+Cfx9JdfNMcYl6eKpl1iQTVNVZgF4Ag8ck7gzsF7KXAPgHuBnwFzgxC44V2xj4OXAG4BXABunzCNJkiRJ6ltHA+PAWqmDTNO5McYrU4eQJHXcQuA+4P6Ja+n7C4Bbgdse9PbBP3ZjjPHezsdWP7Igm4KqzGYA2/DAMYnPAB6WMtcAuQ04GTgROD0v6gUpw4yOjT8SeA3weuAlWIpKkgRwM7B56hAJ3JE6gCStxD7A+1KH6LC+ftEsxnhjCGELen9KTV//fwL+wGB+TeSuDXWbqxnMv4vdZAnLirCF7u5SN7EgW4mqzDLgSTSjEZdeOwNbpsw1gK6jKcTmAr/Oi3pRyjCjY+PbAq+j2Sn2Anr/GxJJklpq4hyRW1PnkCQ1YozzUmdQ68UYb0+dQasWY1yIXxNJycUYF+PfRUkrMfAF2QqKsCdPvH1MylwD7lKaQmwucEFe1EnvKhgdG9+BphB7Pc3OQUmSJEmSJEmS1MMGpiBbrghbWoAtvSzCusNvWXaeWNIZ5KNj4zOAXWgKsTfQ/LmRJEmSJEmSJEl9ou8KsqrMNmLFO8K2SxhLD7UQOJOmFDs5L+obU4YZHRvPgH8HXgG8HHh0yjySJEmSJEmSJKl9erYge1ARtvyusO0SxtKqzQdOpSnFTs2L+q5UQSZ2ie3AskLsBcC6qfJIkiRJkiRJkqTO6fqCbKII25EHjkV8MvDYlLk0abcCJwEnAmfkRX1vqiCjY+MbAS9iWSm2XaoskiRJkiRJkiQpna4oyKoy25CmrHjscm93YNmOsBmJomnNXEuzS2wu8Ju8qBenCDGxS+yJNGXYy4HdgfVSZJEkSZIkSZIkSd2jIwVZVWbrAtvSFF/LX9tNvM07kUNtdTHLSrE/50W9JEWIiVLs5SzbJbZ9ihySJEmSJEmSJKl7taQgq8psLWBrVlx+PRZ4FBBasZa6xhLgXJpC7MS8qP+WOM9S6wA/TR1CkiRJkiRJkiR1r0kVZFWZzQC24KHF19Lr0TTFhPrb/UBJU4qdnBd1lTiPJEmSJEmSJEnSlP2rIKvK7OGsuPzabuLasOPp1A3uBk6lKcV+lhf1vMR5JEmSJEmSJEmSpmXtqswuoCnCNkkdRl3jUuAXE9dZeVHflziPJEmSJEmSJElSy6wNPD11CCVXAWfQFGJn5EV9Q+I8kiRJkiRJkiRJbTOpM8jUd+4FfgWcTlOKXZwX9ZK0kSRJkiRJkiRJkjrDgmxwXEhThp0O/Dov6nsT55EkSZIkSZIkSUrCgqx//ZNlO8TKvKhvTpxHkiRJkiRJkiSpK1iQ9Y/5wNk0pdjpwGWOTZQkSZIkSZIkSXooC7LetQQ4n2VjE3+bF/X9rVygKrO1gMcAG+VFfXErn1uSJEmSJEmSJCkVC7Lecg3LxiaemRf17a140qrMNgF2mLh2XO79JwDrAScAb2rFWpIkSZIkSZIkSalZkHW3ecCZLCvF/ramYxMndoNtx0NLsB2BvBVhJUmSJEmSJEmSeoEFWXdZDPyOZeeInZcX9aKpPEFVZg9nWfm1fAn2eGDdlqaVJEmSJEmSJEnqQRZk6V3Jsh1iZ+dFfdeqHlyV2bo0O762BLamKb6W3xG2RVvTSpIkSZIkSZIk9TgLss67HSiZ2CWWF/U1VZnNADYFHlWV2a405ddWE28f/P4jkqSWJEmSJEmSJEnqExZk7XcN8P/bu+8wSarqjeNf3iVHyTkoOQiCLkEBAUFQgkiWHJewi5hBkaAoiqiIiYwIIhlRUEABQTAAKgiCCVGiJOEHkmHP/v64NbIuM7t9q6u6unrez/PMszBbt+rA9HR13XPPuXcB9wGPA9ORKsA2B/Z99NrZhxJfbn9oZmZmZmZmZmZmZmbWA06QVWsS8CLwCiBgdmCp4svMzMzMzMzMzMzMzMz6gBNk1ZoOmKX4MjMzMzMzMzMzMzMzsz6kpgMwMzMzMzMzMzMzMzMz6yUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUcYLMzMzMzMzMzMzMzMzMRhUnyMzMzMzMzMzMzMzMzGxUmb7pAMzMzMzM7PUkrQPM2+Hh/4qI39UZj7WDJAFvBZYBFi6+Fir+XBB4Gfj3ZF9PFn8+CvwyIh5oIOzaSVoRWLrDw1+MiGvqjMfM6iHp7cA8HR7+cET8vs54ek3SG4B3kO4B8072NQl4Anh8sj8fB+6IiCebibY+kt4NzNjh4X+NiL/WGY+ZGYCkxYHVOjx8EnBVREysMSTDCTIzMzMzq4mk+6jn8+Yk4FnSBM+/iz8fAX4F3BgRz9RwzZ6SNDdwDTBrh0P+LWmxiHixxrC6Iul2YP4OD78R+EBETKoxJCSNBz6VMeTiiDikrnjKkjQr8G5gK2BzYIEuzvV34FrgOuC6iHi8kiCbdx6dT0gg6c0R8cca4+mKpLOATTo8/GHgXXW/N0p6B3BhxpB7I2K9uuJpiqS7gbkyh50WEUfXEM6IJJ1Ker/I8aeI2LiOeKogaT7S+9fMHQ55TNLiEfFyjWHVTtJYYHdgfWAV8rpFhaQ/AD8vvn7R9s9Rkt4GXJ0x5BZgrZrCaT1JawCX13DqiaRFOo+RFuk8Vnw9AtwaEXfXcM1KSboHmKXpODqwekQ8VsWJJJ0A7FDFuYbxEq8t4Hqi+LoDuD4i7q3pmr32VWC7jOO3BS6tKZauSToCOKDDw58HNomIf9YXEUhaGPhtzhgnyMzMzMysLosCY2o8//LDfG+ipNtIk/unRcQ9NV6/TnvTeXIM0urwDwDfqSecSixM54mbHYHfAcfXFw4AcwCLZBzfaVVCT0jaBDgEeBedTwhPy9LF1zhgkqRfAp+PiKsqOn/PSVqPjORYYQKdP/A3YV46f+0uApwBbF9fOADMRN7v03N1BdKwRchPkH1K0kURcVcdAU1J0sbAfiWG9nul0b7kvRcuQJro/V494dRH0hjSxOmHgHW6ORWwevH1EdLnqBuAE4Af171QpSYTMo9fU9LYiLi1lmjaL/e9PcfiI/2FpAeAn5KSnddExFM1xdCNRWhHgqzK57G5qe/1APDG4b4p6X7gBuAC4CdtfG+StBiwdeawCfRxgoz0eSfn9XChpHVrXpgyhszXqPcgMzMzM7NBMgZ4G/AJ4C+SLipWErdG0SJvfImhB1cdS8OOlbRu00H0I0lvlfQz0sTR5lSXHJvSdMC6wJWSbpG0ZU3XqVuZ341di1Zlg2I7SR9sOggb0QzAyZKmq/tCkmYCvl33dXqtSBgdWGJo6+6dklYiVT1dQHfJseGMATYiVQzdLWk/SXXdYyonaX5gpxJDW/c6GAUWB/YhVSY/LukGSblVrzY4lgB2A64A7pS0p6QZGo4p1wHkFyttKGmVOoJpyFjgK00HMSUnyMzMzMxsUInUwuJWST8sWi+1weaMsHpyGlYvWpwNiumB84vJLgMkLSPpAuBWoNdtzsYCP5J0m6QNenzt0iQtCry/xNDZSJWcg+R4SWs2HYSNaF1685r7FLBsD67Ta+8jTaDmWrMtvxeSppP0YVKF9Ro9uOQKwKnAfZIO7kUCtwL7kSqecu0gqXR7YqvdGFIL0SuKBTtbNB2QNWplUtcpAHNAAAAgAElEQVSMe9rymbRYnDKu5PDcqth+N0FSXW06S3GCzMzMzMxGg62A24tWa/2um4egQXuAWhQ4t6iqG9UkHQTcTWoH1uQk5VuAayUdU1Rs9Lsyq3WHHDRgr70ZSa1t5m46EBvRcXUu5pC0HHBoXedv2Gi4d36dtH9Nryu6FiiufZ2kpXp87Y4V96SyrXFnolzbUeu9scDlkm6VtGnTwVijlgCukXRUCz6v7UDnezFPadC6GgCcLqlvFuv0+4vHzMzMzKwqiwI/l9S3bXQkLQ9s0sUpti02Jh4kmwCfbjqIpkiaXtK3gW+R2rD1A5F+Jj8v9lPoS5JmpPxqXUh7sb2nonD6xZLA2S2pBBmN5gW+XOP5T6ZcdU1fk7QysGEXp+j76iFJx9J8Im8DUmuzbt5X67Q1U9nTqgMHSCq7oMJ6723AVZK+4p/bqDYGOBq4WlLO/s291s3z52zAXlUF0ifmAC7ulxa+TpCZmZmZ2WgyBjhR0o5NBzKC8XRXHTQDsH9FsfSToyS9q+kgek3SPKR9xsrsq9ML6wF/kNTrdo+d2oFU+dCNpiek67AFaZ9G60971NEyStJudJdE6mfd/p72dfWQpP2BTzYdR2F24BRJ/fge0u3rYDFSks3a5SOkyvaFmg7EGrUxfdp1omjjO7bL0xw0gIubVgW+2XQQ4ASZmZmZmY0+0wHf7bf9uiTNAexZwan2b+Gm1dMi4PsDWB03IklLA7fQ/xPaAh5oOogRVFEtumk/tYCp0Oda0nJ2tDqpqICsRNFWs87KtMZImgvYrYJT9WX1kKQFgeOajmMKDwGnNR3E5CStQqpw61bfdhmwqVof+L2kdZsOxBq1NakNbb+p4n1lGQavqwHAPpL2aDoIJ8jMzMzMbDSaCbisz/bi2Z3UbqJbCwHbV3CefrMAcH5L9r3qiqQ5gctJLf762URgp4j4S9OBTEnSWGDNCk41Hamyc9BMT/p9KrsfhtVrBaqt8juO7qsp+9VepPZT3erX6qHjgLmaDmIKe0fEU00HMYWqqn3Xl/Tmis5lvbUwaZ+8fq1qt944RNLOTQcxpGjfu0NFpxvErgYA3y5aJTfGCTIzMzMzG63mAz7VdBAARcuMKh96BvUBan3gc00HUaeiNcy5wIpNx9KBj0XE1U0HMYIqqwD2kjR7hefrF4vQp+2IDIDDi0rSrkh6O7BvBfH0neLeWWUCu6+qh4p9SXdvOo4pnBQRP206iMlJegOwa4Wn7KvXgWWZgbSvURs+Q1l9jpXUL/ttjgOqqgjfbEC7GsxK+r2tYrFLKf4gbGZmZmaj2QRJ3WzoXpWNSRUDVVlH0lsrPF8/OVTSe5sOokbHkPaIqsKrwG2karSTgM8DJwOXAjcBfwcmlTz3GRHxtSqCrFrFq3UB5qT/JqmrsglwRNNB2LBmBr7dzQmKloEn093elv3sPaS2U1VZX9KqFZ6vWztQ7mc3EbgY+HhxjrWBdwI7F987lXKtce8BPlZiXN32ppoqwiG79FmHAcszF/Dj4rOAjU5L0gfV/8U9+IAKTzmoXQ0gPQef0tTF+66/spmZmZmNWocAv+nguIWBN032tRFpIrGMmUmTw+NKjq9KHRVfE0itpwbNdMA5klaPiPubDqZKkran+6rGScDPgfOBSyPi39O45iLA5sCWwLtIqzin5SbgoC7jrNN+pDaqVRpPl8mKPnakpF9GxDVNB2Kv825JO0XE+SXHfwQY5HZxdd07m/5MMGS7EmPOBw6PiHundaCkt5De+/ckfZ6amonA7hHxfImYalNUwFZ9P5qVlHT7SsXnHU02AF6YxjEC5gUWLL5WAt5NNe1g30hqpb5RRLxYwfmqsglwcwPXfbaBaw65Gjiyg+Nm53+f79YmJbrKOlzSyQ2/Z70fWLTic+4p6fCIeK7i8/aDXSTdGBE9T5Q5QWZmZmZm/eKvEXFL7qBigv9wUgupMi0stpV0YERMLDG2a5KWorqKocntJOnjEfFEDedu2jzAhZLWi4hXmg6mCpLmIlV6dON2YEJE/LLTARHxMHAacJqkeUgJugmMnGC6D9gmIl7uMtZa1LBad8hKkt4VEdfWcO6midRqcfXi9WD95QRJV0bE0zmDJC0JHFVTTI2TtAywWQ2n3kXSoU3vsSVpCSC3mu1SYJeIiE4OjojbgdslHQvsBBwGrDLC4V+KiF9nxtML76Ge/ToPknRCp/8v7XV+FxHZSZmibeoapOTweLrbm3cd4AvAh7s4R9Wej4j/NB1Ej/074/nuuqF/KD7P7Q18GijT7WMe0sKvy0uMrUod7VrnInU1OKmGc/eDEyXdEhG39fKibrFoZmZmZq0WEQ9HxHhgOeCuEqeYh/QQ3ZSDqOdz+cykSppBtRZwfNNBVOjjpNdiGa8CHwLempMcm1JEPBkRHyP9Lp0zzCHPAltFxONlr9EDWwOL1XTuQd3bD9KK/fMljWk6EHudhUiTvLm+SWcVoW01nnpaRw5VDzUtN+kzEdirTEInIiZGxLmkhNz7gX9Occjt9G+yta735TcBg9zOuS9FxKSI+F1EfJL0M/gy065Em5rxVezlaL0XEa9GxKnAssCJJU9TxwLEjhTteter6fSD2mYR0gK9i4qFgz3jBJmZmZmZDYSIuA/YHijTcmLzisPpiKRZgH0yhjyUeYkDBnzC+xBJ2zQdRLckLUhKcJXxPLB1RJxY1Ur3iLg/InYn7V3zTPHtScBuEXFHFdeoUc5q3eeA/8s4fsuiKmdQrUfap876z/6S1uz04OJ9sbGJwbpJmo28FsK5987xReu+Ji2SefxtEfHMtA8bWZGcuAxYGfgSafHFS6TWin1XrS1pOWDTjCG5r4M6qj+sQxHxRER8nNRq758lTzMDcGxlQVnPRcRLwEeB60sMbzLJnfv+kVPBv7KkjTLP3yZLA2f28oJN3/DNzMzMzCoTEX+i3F4U76w6lg7tQl7V0NF0tk/bkCWA9+UE1EJnDsDq4COA2UqMexbYOCJ+XHE8AETERcBbSdUDRxQTp32rWK27fsaQ84CzM44fQ3/vvVaFT0hqZMGATZWAUzpZ8CBpDsqvtm+L3Ultpjp1OPC7jOPfSEMLZyaTmyDLSfZPVUQ8HxGHkt7/94mIO6s6d8Vyqwh3Aaa6L+cUNpG0fF5IVrViYc5YyiVIAHbIWWBg/adog78z8Fjm0MWaeEaQNDfp/aZTvyA/kTvoCfxtJJVdPJjNCTIzMzMzGygRcTbwQOaw3ImoquS0BnqaNKGfu0/VILeFgzRJepGkmZsOpIxiD7pxJYePq3tPmIi4B1g7ItpQWZT7Wj+J/N+nfdr6WuvQdMDZA14p11ZvAQ7p4LjPUl+b0X6R017qKeAC2nfvzF00sWbVVW8RcUfRerHvSJod2DNjyO0RcQNwVsaY6RjsVmatUeyn+16g7L5Eg9SSe1SKiH8BZ5QY2sQz3j7ALBnHn0RqbZ7TBWXLYq/KQfYlSWv34kJOkJmZmZnZILo98/gFa4liKiStB6yWMeSciHiONNH3ZMa4DSWtkhVc+6xOeysmdiO1AMp1SkScV3Uwwyna2/S1Eqt1b4mI3xdVpzdkjJuXtIp5kM0DXChpxqYDsdf5jKTFR/pLSasz4KvKi7ZSK2cMOSsiXgS+T1po0qmmq4eeyDx+Tpqrhm/C7qT/5k6dVPx5MqllcKf2LKoyrWER8QJpj7zc3w2A9SWtVHFI1nu5z3fQ42e8YqFCTreBx4BLixa5388YNxq6GsxA+jw6b90XcoLMzMzMzAZR7gPUzJJyJlqqkLs6/WSAYqLvuzVfq43GScpJkPSLMvsEPUj5PcsG1d7ArBnHnzzCP3diNPw+rYlX3Pej2YGvD/cXxaTcKaRJs0FW9t75PGmFfqearh56tMSYy4rFN6NBzs/mvxPPRVX0tRlj5yAl46wPFPsN5+w/OLlBbzk+GpSpIOz1IsjNSW16O3VmRLxc/HPu59F9B7yrAcDipM4GOe10szlBZmZmZmaD6A8lxsxXeRQjkLQosE3GkBsj4q7J/j13BfSukt6QcXxbnSJpxaaD6JSkhUj7auT6YpEoNf6bGMhtuXb+ZP9+KXn7Wqwu6R0Zx7fVByVt23QQo8CrmcdvLWmrYb5/IPnvJzn7MTWuaCc13H/7SK6LiL9O9u8njXjk8JqsHiqTIJsTuFrSpyX1vDK+VyS9C8ipBvpeRDw72b/nvg4m1D05a52LiCuAX5UYmvPeYf3pHvLaEEIPn+8KOVXcQVrYkv4l4vfALRnj5wU+kHF8W70XOKzOCzhBZmZmZmaDaKYSY/5TeRQjOwCYPuP4/1lRWEz4/Txj/GyUX3HblH+VGDMbaT+ynEqiJm1OqlLI8RBweg2xtFnuat2zi1ZNABQrd8/MvGbb2tiV+X0COFPSMpVGYlM6rsSYb0j67x5VkhYGcvcJfAz4XIlrN+kg8irkprx33g3cmDF+DmCPjOOr9CfS5GmuWYBjgPslnStpnWrD6gu5779TVmX8CHg4Y/wKwMaZ17R6HVVizJqDnDgeJaYn7/kJevh8Jyn3veLqiPjnFN/LrSJr2+fRnPfeyR0jqbY2wk6QmZmZmdkgyt3Q96WIeLyWSKZQ7OuzX8aQx4GLh/l+7grog1q2AvpAyu0zsTL5/2+asmWJMae3YU+wHivVcm0Kp5A3Gb1NkZRoi+OAW0uMm5OUdB70Fj5N+iZwU+aYJYCjJ/v3E4C5Ms9xMC2qICteg/tmDHkEuGyY7+feH8Y3ce8sPpP8uotTzEjaL/FXkh6WdJaknSTNU02EzZC0JHmtiX8ZEXdO/o2IeJX8hSajobVua0TENcCd0zzwf4lyn7usf7yF/EWQD9YRyAjGk7fwbbj70fmkTgedWl3S2zOOb9qFwEUlxo0BzqsryZ2bdTUzMzMza4PcBFnZ1Wxl7EBeP/zJe9NP7jJSVUink/TLAO8BfpJx7SY9COxKijd3Yd/ukm6MiH6vtCqzErItP7+ekLQ8sEnGkOsj4s9TfjMi/inpKlIbl07MQKoELbOKvQkvk957fg/MnTn2LaR9r8ZVHZQBqV3u3qTWwLNkjPuQpHNI94AdM695aURcKGm3zHFN+gCpnVSnTo+IV4b5/iWkhSfzd3ieoYqAn2Vcuyo/BKpo57owqRJuDyAk3Uq6l/xgyuRRC3RVRTiZ04DDM861haSlhqn2sOZcCbw5c8x6NFuFf6ikMu1Tc/04In7Yg+v0Wu7zHfQoQVa0482pOL4f+PGU34yIFyR9l7y9hg+mXNvRpuxL+my5bOa4hYHvS9okIspUWI/ICTIzMzMzGyiSVgNWzxzWy9WFOauQJzFZb/rJRcSrks4APp1xvoNpUYIlIq6W9HngiBLDvyHp1ogosx9d7Yo2kLn7wj0B/LaLay5I3gRzrqcj4qEazz+cKlbrDjmZzhNkAOMkfW6ESfi+UyQB9yBNuudWxOwn6RcR8b0aQhv1IuJvko4CvpQxbHrgVPL3V3mSvD37+kXOvXMi6f/N60TEy5LOBA7NvHYTCbLzSJWCVbYNFrBW8fUZSX8mValfFBF3VHidyhVVhPtkDHmCESoVIuJBSVcA7+v08qTk3Ccyrm/1upr8n0fTld+92gftMdK9fmBImh4os6ijV59L9yC15e3UaVNJ8pxMXoJsW0kLR0TZdto9FRHPSNoe+A2Q26FgI9J98cgqY3KLRTMzMzMbGJJmAb5P/kKwniRRJI0lTUp16uqI+MdU/v5U0kRgpzaVlLtar2lHA9eVGDczqTVczsNqL5WZpLmhyxWTnwLuqvHr+C5iy1b8bPfMGPIo8IOp/P2PSSt6O7UQsH3G8Y2LiMuBL5ccfrKkFauMx/7HV4FbMsesBSydOebDEfFI5phGFe2j1sgY8pOIeGAqf38KaQFKp7aQlLPPYSUi4kHSfmJ1WoG00OYPkv4i6XPFQqN+tDN5izzOmkZL4tx2m/sUnzOtP9wE5C5QaTpBZuUdAYzNHPNverAIsmjDm7OIY6ptXiPiL+TtNT0DsH/G8Y0rFjCW3T/tcEnvrjIeJ8jMzMzMbJB8GVipxLhLqg5kBN1uLP8/ignAnIqw6WhZ5UCRENqZ1E4y17LAGdVGVJkykzS9rHRsg9zVumdMrdqreK2dlhlD2zZHh5Qozd3zCmA24GJJs1UcjwERMZHUanG4lrpV+UlEnF3j+etS9b3zH6Tqk04NVQ814SukBQi9sByp7eDtkn4rKWevr16opAJ/Mj8F7s045zzALhnHW42K9uOPZQ5zgqyFJL2D9N6U67Li3lq3TYDlM46/rIOFKlO9jw1jf0kzZI5pVNEKv8xnEgHfk7RoVbE4QWZmZmZmrSdpZUnXUm4C61HgFxWH9DqS5iftAdSpB4ArOjgu9wFqz7ZNcEfEo6T9Z8o85G4vqR+TGGUmaXqxb0UrFKt1c5K9wQgt16ZwOnkr0teW9NaM4xsXEa8CO5H2Ycq1EvnvOdahiLiL+iqGnqFlK8wBJC0MbJsx5J/AVR0cl/s63ruJ6qEiqf9e8hI5VXgrcLmkmyWt2+Nrv04xQZ7TPvuaiLhnagdERCdJtCnlJOmsfrkJsnklzVhLJFY5SbNJ+gJwLXl7Dw4ZtsVqDXLfFzq5//wAyKn2XgjYLjOOfnAg5RaBzA9cULTe7JoTZGZmZmbWSpLml7S+pK8Dt5N6kpfxg6o3+h3BOGCmjONP73DV41WkCcFOzQXsnnF8X4iIGyi3FxnAl4v2lv2kTIKsVW3RarYxqTVYp66MiPumdVCxojd3345+TMBOVbFX3C6kxGGuXSXtV3FI9povku5pVftY0bKvbfYntY/q1Kkd3tOvIC1E6VRj1UMRcT/wTuBvDVx+TeCGovViJRORJeW+z3baPvFM8qo2V5O0XmYsVp8yC4cWqjwKq4ykmSWtJml/4C/AYeQ9Pw15kpRYq1XRfnfzjCF/pYPW8cXiiDMzw2nj59HnSYm950oMfwfwhSriaPLmZmZmZmY2uSMlHdDBcfORJsZz9qEYyavAtyo4z1QVk0qd/LcNmWpv+slFREg6FTg24/wTyN97ox98kfQwlPMgCjAjcKGkNSLiqerDKqXMw769po7VukNOIm8V7o6SPhYRT2TG1KiI+JmkY4CjSgz/uqRbij0krEIR8aqkvYBbqW7O5pqIyG0f2riiXdS4jCEv02Fb3YiYKOl04DMZ559Ah/fmqkXEg8VCj+OBfUktk3tFpPZmG0p6b0Q83cNrD1URbpMx5CHg8k4OjIgnJF1MauXcqQnAjRnHW33KTKq7gqy31pd0WQfHzUxq87ok1RT0nFRUzNftIPLiPaWoXu3EqaQEYafnX6d41vl9RjyNi4g/SxoHnFti+Ecl3RgRP+omBleQmZmZmVm/WAd4Xwdf76Ca5BjA1yLijxWda2q2BhbLOP6HEfFwxvFnkLcCeiVJZSvuGlM8UO4O3F9i+FLAd4vWfP2gzKrnBSqPooUkLQXk7I1zHxl79UXEdaRVy52aGWhrRdVngWtKjJsZuEjSnBXHY0BE3A4cV9HpnqO9r8/tyKu2vTQiclqunU5akNKpRquHIuLpiBhHqpi/o4EQ3g5c0UCryQPIqyI8PXNiPHfB0DaSFskcY/WYv8SYMnvaWnmL0dnz3abAG6kmV/EP4PMVnGeqivfCfTKGvAic1enBReeDnL2moYVVZAAR8X3yW95CWixyVvFsUJoTZGZmZmY2Wt0PHN2ja9VZ7UIxIfiDzGu09QHqSdJebjn7RA3ZEvhYtRGV5gRZebmrdU8r0UY19yH9AEll9sdoVPH/ZRcgJyE/ZFk6rNaxUj4L3F3BeT4ZEf+s4DxNqPve+TCQu+q88T2oIuL6iFiNNKH80x5ffl3ggl5drEQV4UQgq1oyIm4CchZL5XYFsPrktqt+JiLKVJ1Zu0yIiBd6cJ1dgLkzjr+weI7Jkbtf5k6S5ssc0y8OAcpUv81N6hRSujrUCTIzMzMzG41eBQ7oxUOypDeT9g7p1N8o1zM/dwX0lpKWKHGdxkXEzcDHSw4/VtK6VcZTUpn9xBasPIqWKbFa9xXKtUQ7C8iZXFmCtAK6dYoE+07kVdIM2U7SBysOyYCIeBnYizThX9ZNwDeriai3JK1Bqljq1N3FXpW5ylQPLVriOpWLiJ9GxKaktmSfIP28u3m9dGpLSdv24DoA25O3Z9TlxR6LuXInocd1MxlrlclNkJVZDGLtck5E5FZdlVXX3oiTu5K8vaZnJrXhbZ2IeIn0nl+mje9Y4Ktlr+09yMzMzMxstJkI7BoRV/boerkPT38BdpdKrWV7Bui05dkYUiXOYWUu1LSIOLFodZU7STc9cL6k1WsIK0eZCrK1K4+ifXYB5sk4/h5gs5K/T38B3pJx/MHApWUu1LSIuFHSp0n7/OU6XtJvqo7JICJukfQ14KMlhr8A7J2x10m/yb13/k3SHiWuMx2pDeVsHR4/VD10RIlr1SIi/kbam+z4onJgc2Ar4N3A7DVd9suSfhwRL9Z0/iG5r4NHSr4Ocm8SC5Kq2b9X4lpWgWIBWu7ru0zy1NrjEmDvXlxI0vrAqhlDngSWl7R8icv9mdQqvlMHSjo+InqxYKJSEXFvsQ9rmc/T4yX9AvhV7kAnyMzMzMxsNJkI7BYRPWkPJGlu0oR+ji3I21+pG/tKOroHE1x12RtYDVgmc9yipI2gr686oAyPA0HepNzSkpaOiL/XFFMb5LY3W5GM/R66tIGkVXq0r2EdvkTa43HLzHEzAhdSLolj03YEKdmxbOa4I4vESesUSZ6dMocN7WPTC/tJOqao8usrEfEE8F3SnpszkfYr25KUNKuyanwp4P3AeRWe839Ieiv5C0MOoHftDyfgBFmTNi0xpukE2VGkThF1a+vnkG78ANgpc//BbuR+Hp2H3n0eXYL0uSG3/X5fiIgfSDoB+HCJ4adT4rOAE2RmZmZmNlo8AoyLiMt7eM29gVl7eL1c8wIfAL7TdCBlRMQzkrYHfk1qKZJjE2CF6qPqTERMlHQPqTVWjndTrkULpL12ctoLLQ6ML3mtyhUVg6s1Hcc0TKCle9NExKSi8uI2YMnM4UsCJ1QflUXEC5L2Bn5BqnbqxM20++exL/nv6b3Uiuqhol3VlcXXUMXN0CKctel+25UtqTFBRv/vlbqWpLERcWvTgYxSm5UY84vKo8hzTURkV7fYVAXwdeATvUqOFW1239+La3XhYFqaICscSrpPrZM5bg7SIpEsTpCZmZmZ2WhwFvCRiHiqVxdU6ul2UK+u14WDaWmCDCAibpd0CHBKieGLVx1PpivJT5DtTMkEWURcS8b+dpLWpo8SZOSv1m3CrpIOi4j/azqQMiLiKUk7ADeSKsNyNP37NLAi4iZJ36Kz34GXSa0VW9daCUDSGODApuPoQOuqhyLiTuBO4AuSFiD9N0wA5i55ys0kTV/HpHRRRbhj1eetwQSgTEtH64Kkpcnb3xdSIqWXi+SsfncD+0REr9s8H0D/51Q2lLRyRNzVdCBlRMQrknYkLdqaN3N49ufRbleLmJmZmZn1s+uBd0fEXr1MjhXeC7ypx9csY3VJb286iG5ExKm0bKKyUGYT8XUlbVBxHH2vWK27TdNxdGA2YK+mg+hGRNwCfKzpOOx1DgP+2cFxx0TE3TXHUqetqLYVYF3WkjS26SDKiojHIuJI0v/rjwJPlzjN3NSXGN+P/q4iHLKjpPmbDmIUOor8BMUtEfFYHcFYzz0AfBJYvdfJsaJ17bheXrMLbVhYNqKIeADYFah9L1UnyMzMzMxs0DwFfA1YMSI2jIifNRRHv7cGmlybYh3JAaSVpG1yA/BciXFHVR1IC7Rhte6Q8ZI6bYXXlyLiG8BFTcdhr4mI50itB6fmduCLPQinTm26H7Up1mFFxLMR8VXgPcCzJU6xQMUhtamKEKBNk+UDQdKK5O/vC6nNtLVXAD8mLaJ4Y0R8saF9IHeghve9muwmaa6mg+hGRFwFHFv3dZwgMzMzM7M2mwj8A/g+8EFgLLBgRHw4Iv7cVFCSliPtcdUW20pauOkgulFMHm9PuYRTI4r9Ya4rMXQDSdtVHU+/kjQjqZqgLZYmTTa33b7A35oOwl5TtEk9fYS/fhXYq1d7sNRB0srAhk3HkWGHQakeiohfA7uXGLpg1bEA76NdLVsPkNSWBRytJmlW4FzKzWc7QdYuTwI/Az5L6soxX0RsERGXN9xCuE1VWa3valA4Cvh5nRfwG7iZmZmZ9YtPAtPa6DxIbYCeIj04PRMRtbddKGEC0KYKkhmA/YGjG46jKxFxt6T9aVe7xcuBLUuMO1PSHRHx16oD6kM7UM8kbJ0OplwLzb4REc8UidibaUers9Hio8BmwGJTfP+4iLi9gXiq1KaJR3iteujzdV9I0gzACcBXI+Lemi7zU9LCozEZY8ruXzY1bavMWwzYGri46UBGgTOA1UuMu6mtezENgGuBL0zjmEnAC6RnuyeBp/pxsYekNYE1m44j03hJJ/bp83JHImKipJ1J+5EtVMc1nCAzMzMzs35xe7E6vtUkzU47N2zfX9LnI+KVpgPpRkScK+mdtKfi6BxSYnKRzHFzAJdIentE/KfyqPpL2ybNATaVtGxEtLoCKyLukHQwcFrTsVhSJC73J7WaGnIXaZV9axVtoHZrOo4SDpB0XA8mc79Fuq/tJmlcRFxQ9QUi4jlJ9wLLZgyrdH9XSasAG1R5zh6ZgBNktSnabn4Z2KnkKT5RYTiW59FBeL4rtPHz6DKkRTVXNh1INyLiEUkfAK4hbxFHR9xi0czMzMysWnsAczYdRAkLAYPStu+DpFWGfS8iXgQ+V3L4KsCNkhatMKS+ImkssFbTcZQwHTC+6SCqEBGnA2c3HYe9JiJ+QkquQ6r42buhvViqtBepHVTbDFUP1UbSIby26GNO4HxJp0mapeLrzAIsmTnswSpjoJ0T0ADvlPTmpoMYRJLmIU3ufxpfhyMAAAy5SURBVKjkKS4tWoialSZpAWDHpuMoqW1VucOKiOupaR9mJ8jMzMzMzKrV1skdGJwHqBdJ+5E903QsHTodKNsyazXgZkllWg6NSNJ0wPpVnrOkNr8m9ywqSgfBgaQqJesfhwCPACdExC1NB9ON4v2mzQnl2t6nJG0GfGWYv9oX+JOkPSRVNbf3dmDGzDEPVXRtJL0B2LWq8zWgzfervqNkF+B3lN/X91VSC3ezbo0j//2xX2wmaZmmg6jIsdRQDecWi2ZmZmZmFZG0MbBCxpDngS/VFA7AcsDOGcevI2mNiPh9XQH1SkT8XdLetKDlUUS8IuloylfpLArcIukU4DMR8Xg38RRVW9+g4cotSfOT9h/L8TXg/2oIB1J1y8czjh9qGXdSPeH0TkQ8X+xH9lvaWeUzcCLiKUlbAX9sOpYKbEZqA9Wp/zB80qgqK5JXKbC+pDdHxJ1VBiFpReB8Rm4ntSRwFvAxSZ+KiMu7uNYCpDaOOZ4BHit7zWHkVhH+A/huhdef0nrAuzKO30XSoRFRadvJ0UbSnKS9WQ8n/S5249RRsler1UjS9MABmcPOAf5eQzhDDqPz/WGHFqF8uL5weiMiJknajdQpZPGqzusEmZmZmZlZdXJXD58XEZ+pJRL+ux/alqT9qjp1MGmSqvUi4hJJJ5IqLfrduaQH17KVYNOTHn53k/RN4JKcRGex/89OwJ7A2iVjqNo4YKaM4++IiFof/ov97XI2aJ/AACTIACLiz5LGkV6r1gci4tamY6hI7r3z3JrvnXMCW5CXrDmY9J5VVQzzApeTEu3TsgrwI0l3kBaFXBIRd2dca03SPoPLZ4Z5RURMyhwzUgxlqghPjIgTq7j+cIr90HKSnrMCe1Nv8rYt3iBphmkcI2A+YIHiawVgU2Adqpmv/h15i1rMRvJ+0mK0Tj0F7B8RL9QUD5KWJm/fzr0kfToinqsrpl6JiH9L2gH4BTCt95mOOEFmZmZmZlYBSUuRJtRynFxDKP8VEc9KOpe8VY87Sfp4RDxRV1w99nFSwqev97GKiJC0LXArMG8Xp5oT+BTwKUkPAD8B7gH+VXy9BLwReFPxtXTx58KkFaZ9oeRq3VPqiGUKJ5OXIFtJ0kYRcV1dAfVSRHxf0vrA/k3HYoOhaPu0WeawWpPOEfGMpPOBfTKGVVY9VCQWLia9P+dYtfj6rKQ/A1eQKhgeJrVCfIh0D1iMNNm7DGnf1LeVDPWSkuOG8x7y/ntfoN7qMSLij5J+CbwjY9hBkk6IiKgrrpZ4oOHrPwRsFRHPNxzHlC6X9EoD1z0+Ipy4LS+3ff7ZdSbHCieTlyAb6mpQ67Nnr0TEbyQdCny1ivM5QWZmZmZmVo2DyNvj93cR8du6gpnMSeQlGmYm7W3yxXrC6a2ifeEOpFYc8zQdz9RExD8kbQ/8lGqe1RanvYmMrUmTuJ16ltTOpm7nkx7G35Ax5mBgIBJkhUOAscAaTQdiA2E8ecn530TEHXUFM5mTyUuQVVk99E1ggy7PsQJ5LZ9zPQdcVeH5cqsIL4iIutrpTu5k8hJkbwLeS0pOWjOeA7aMiIebDmQYTX0OHZT9UHtO0qrk78lbexIqIn5VVA2vmjFsAgOSIAOIiBMkrUeq8OtKVRt5mpmZmZmNWpJmIW8iDXr0gFJMJP4mc9iBkkba86R1IuJ+0qrJSlpB1Skifg58qOk4+kCZdqX/qSWSyRQrgnP3ittS0pJ1xNOEiHgJ2B54uulYrN0kzUZ+S99e3Tt/S2rRluMgSV3Ns0k6iApbNdboy1VV50haltRaL0evJnkvAv6dOSb3/mXVCWCXiLit6UBsYOT+Pt8QEX+uJZLXy+2csLKkjWqJpDl7UcFeb06QmZmZmZl1b2fyVoU+DZxXUyzDyZ1IWgLYqo5AmhIRPwGOazqOTkTEt2jfCs9HSXvYdE3Sm+nD1bpdXGsMcGAdgTQlIu5lQPYqtEbtRmd7bA15CrigpliGk/u7PlQ91I2rSK12+9m9VFtlnltFeFtE3Fzh9UdULAg4K3PYJpKWqyEcm7qnSJVjP2w6EBsMkuYmPePl6OXn0XNIHRRy5LaL7GsR8TRp0dZL3ZzHCTIzMzMzs+7lPmx8r8ebJF9AmjjIMYgroD8N3NB0EB06CDiKFlS9AVcCqxbVb1XIfe3dGhG/r+ja0xQRfyJtDJ5jX0kz1xFPUyLiB8AJTcdhrZZ77/xuRLxYSyTDO4/8Ssmu7p1F8vkdpFau/fr+f3BVPwdJswN7Zg7rxX6TU14v52cxHQM2Cd0CfwDeViyGMqvKPqT2uZ16DLi0plhep+ickLvgcitJS9QRT1OKitFDujmHE2RmZmZmZl2QtC7wlsxhJ9URy0iKiazczew3lLRyHfE0JSImAh8gVTv1tYiYFBGfJe3FVXvrwJJeBj4CbB4Rj1VxwmK17i6Zw5qotsu95ryk196gORT4ddNBWPtI2hDIvcf09He9WMjyvcxhXVcPRcQrEfFRYAvgiW7OVYOPVpyEyK0i/A9wboXXn6aI+Bv5+0juUST/rH7fA9YpkstmlSja5R6UOew7EfFyHfFMxajvagAQEafQxb3BCTIzMzMzs+7krha/KSLuqiWSqSszsThwK6Aj4l+kdinRdCydiIgfAWsBf2s6lin8Flg7Ik6IiCqrHPYmb7Xu/wHnV3j9Tl0CPJ45ZuCqMiPiFWBH8vfoMcv9fbg+Iv5SSyRTl3vvrKx6qEhErQZcW8X5KnBYRHy14nPm/r86NyJyW4pVIfd1MCewRx2B2H/dB+wZEbsV+4OaVWlz4I0Zx0+i99WtFB0UctvyDlxXg8L+wJ/KDHSCzMzMzMysJEmLANtkDmtkb6liYvH6zGG7ScpZ2d0KEXEdcHTTcXSqaOk3ltRyq5ftxYbzB+B9ETG2aGlSmZKrdc+JiOerjKMTxQrh72QOW13S2+uIp0kR8QCwK/3bDs76TNHeKXefy6bunX8Efpk5rLLqoYh4OCI2BjaiuUTZc8BBEVHpPp6SNgJWyhzW0wr8yVwG/CtzzPg6AjHuJ02ELxsRud0RzDqVm7z/aUT8o5ZIpi33/jgfsFMdgTSpqPreHsh+LnCCzMzMzMysvAOA6TOOfwK4uKZYOpH7ADUbsFcdgfSBzwFXNx1EpyLi6aLl1tLAt0ntDXvpLmA7YPWiqq0O7wXelDmmkUnzQu6+NDCAVWQAEXEV8IWm47DWOJDU5qlTPd3XZRiNVw9FxM+LRNnawI/oXUL6GuDNEVFHYir3/fA3EXFHDXFMU0S8CpyZOWxFSRvXEc8odR/pvWPZiDi1qGA2q5yk5YFNMoc1+Xn0fFJHhRyD+nn0Lkq0kHSCzMzMzMysBEkzAuMyh50VES/VEU+HLiV//63xkqarI5gmFW0BdwUebDqWHEU1wXhgOeAMoM62Qs8AF5FWY64aEZdU3E5xSrkP6zdGxN21RNKBYr+Tn2UO21bSwnXE0weOJL9K1UaZoq3TvpnDzmx4Mvwi8tuI1tKiOCJujoj3kVovngk8Usd1gBuAHSJikzqqIiQtCWyZOazJCWiAU8lvzzyQk9A98jKpavITpM8gS0XEyQ3s8WSjzwRSu9xOPQRcXlMs01R0Ujgnc9gag9jVACAizgZOzxnjBJmZmZmZWTnbAwtmHN9Ib/rJFROMuW3hlgE2qyGcxkXEE6T9k15tOpZcEXFfROwLzEP6+ZwIVLE/z73FuTYG5ouIHSLi4oiodc82ScvRrtW6Q3JjmIHUGmrgRMRE4APUN2Fvg2EnUnunTgUpMdGYYmHLWZnDVqizeigi7oyIfSJiYWBV4KOkquiyiyYmkfZuOQFYMSI2iIiLqol2WLlVhE8BF9QUS0ci4n7gysxhW0haqoZwBsVzpM8dvwF+SPpdPwbYApgnIjaOiOMj4s4GY7RRRNIc5FcAn158BmqS95r+XweT2sJ3ZLpHr53dfcJtWi5Z8F3Pbtd0EJ347DFfnBFoclW2tcN5Rx5x2M5NB9GJzx7zxTG0cNLOeu7CI484bMemgzCbkqRZyVt992IfPFx0rKggmyFjyKQm9kqakqQxQO7GzC93u3q/xOvhhbqTMkOKioZOJupebbgCcJokvZGUaFqSlMCd/GsB0h5m/xrm6xHgtmK/s56TND0wU+aw52uuaJumorpy1sxhXb+OJM1EXnvXl4oWYbXLeG+MiKizArIRue91xZ4ZjShxP+j6Z+Z7Z72K94a1SPeABXjtvX/oz0mkZNPQ14PAzcDNEfF0D+Ps9L47ZGJENL0HJ5JmAGbMHNaqz7dTKvYHnaWGU/fFz7QbJT7bNqWy96IS7+F9/9l5ciVf733xO17i9djEPf2VXlWB5jxb/D+qYR6vdmQ/xwAAAABJRU5ErkJggg==", "companyName": "PT Pangan Masa Depan", "defaultCurrency": "IDR", "fiscalYearStartMonth": 1}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 15:02:43.855
01623e86-8d2b-451c-8d24-eee7675e25b6	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	UPDATE	unknown	2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7	\N	{"id": "2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7", "slug": "default", "email": null, "phone": null, "taxId": null, "address": "Cirebon, Jawa Barat", "logoUrl": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABkQAAAGVCAYAAACvs53PAAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kb9LQlEUxz9qYZRhUERDg4Q1aVhB1NKglAXVoAZZLfryR6D2eE8JaQ1ahYKopV9D/QW1Bs1BUBRBNNda1FLyOk8DI/Jczj2f+733HO49F6yRjJLVG3yQzeW1UNDvmo8uuOwv2OnGRjOdMUVXZ8ITEeraxx0WM954zVr1z/1rLcsJXQFLk/CYomp54Unh6bW8avK2cIeSji0Lnwp7NLmg8K2px6v8bHKqyl8ma5FQAKxtwq7UL47/YiWtZYXl5bizmYLycx/zJY5Ebi4ssUe8G50QQfy4mGKcAMMMMCrzMF4G6ZcVdfJ9lfxZViVXkVmliMYKKdLk8YhakOoJiUnREzIyFM3+/+2rnhwarFZ3+KHxyTDeesG+BeWSYXweGkb5CGyPcJGr5a8ewMi76KWa5t4H5wacXda0+A6cb0LXgxrTYhXJJm5NJuH1BFqj0H4NzYvVnv3sc3wPkXX5qivY3YM+Oe9c+gY08mfP56nFPwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAIABJREFUeJzs3XeYHXXZ//H3ppFQAgiE3puIFJEuHaRLV0SKoEgRxAK2x/aAChbgp4+o+NhCBwUFAUWKCCogvUnvSIdQQwpJ9vfHffZhTbacMjPfMzPv13XNtZvsnu98dgO758w93/sGSZKU0tzAecAiqYNIkiRJkiRJkiTlYQLwT6AX+ELiLJIkSZIkSZIkSZlbBXiYKIb0Nt4fkTSRJEmSJEmSJElSht4HvMTbxZC+Y/uUoSRJkiRJkiRJkrKyJzCVOYshvcCFCXNJkiRJkiRJkiRl4uPALAYuhvQCM4Glk6WTJEmSJEmSJEnq0G5EwWOwYkjf8Y1UASVJkiRJkiRJkjqxGYO3yZr9uDVRRkmSJEmSJEmSpLatCbxCc8WQvmPJJEklSZIkSZIkSZLasDzwDK0VQ3qBT6QIK0mSJEmSJEmS1KoJwAO0XgzpBS5MkFeSJEmSJEmSJKklo4HraK8Y0gtMBsYWnlqSJEmSJEmSJKkF36L9YkjfsV3hqSVJkiRJkiRJkpq0OTCLzgsiJxUdXJIkSZIkSZIkqRnvAJ6k82JIL/CXgrNLkiRJkiRJkiQNqwe4gGyKIb3AS401JUmSJEmSJEmSusbBZFcM6TuWLvQrkCRJkiRJkiRJGsKqwGSyL4jsXOQXIUmSJEmSVGUjUgeQJKkCfgjMncO6a+ewpiRJkiRJkiRJUsu2I/udIX3H+QV+HZIkSZIkSZIkSQMaCdxJfgWRe4v7UiRJkiRJkiRJkgb2cfIrhvQCk4r7UiRJkiRJkiRJkuY0L/A0+RZEeoFRRX1BkiRJkiRJVeZQdUmS2nMMsHgB51mogHNIkiRJkiRJkiTNYQlgMvnvDukFVi/oa5IkSZIkSao0d4hIktS6I4G5CzrXIgWdR5IkSZIkqdIsiEiS1Jq5gIMLPN/CBZ5LkiRJkiSpsiyISJLUmj0pdteGBRFJkiRJkqQMWBCRJKk1hxd8vt6CzydJkiRJklRJFkQkSWremsAmBZ9zasHnkyRJkiRJqiQLIpIkNa/o3SFgQUSSJEmSJCkTFkQkSWrOeGC/BOe1ICJJkiRJkpQBCyKSJDVnb2DeBOedkuCckiRJkiRJlWNBRJKk5uyU6LzuEJEkSZIkScqABRFJkoY3Btg60bktiEiSJEmSJGXAgogkScPbiDTtssCWWZIkSZIkSZmwICJJ0vC2T3ju1xKeW5IkSZIkSZIk1chtQG+CYwrevCBJkiRJkiRJUu2tV8A5FiNNMaQXuL2Ar0+SJEmSJKkWvOtUklRGPcDXgb8Bi+Z8rm1zXn8o9yc8tyRJkiRJUqVYEJEklU0PcBJwLDAXcETO59sq5/WHcl/Cc0uSJEmSJEmSpERGAr/kP9tKvQjMneM5byRNu6xe4CM5fl2SJEmSJEmSJKkLjQF+w8CFg8NyOmcP8Nog5yziWCenr0uSJEmSJEmSJHWhuYE/MXjh4AHyaQO5+BDnLOKYN4evSZIkSZIkSZIkdaGRwMUMXzzYNYdzb9nEefM6Hs/h65EkSZIkSaoth6pLkrrd94Gdm/i8g3I49ztzWLNZf0l4bkmSJEmSJEmSVKBDaX5HxVRgfMbn/0EL58/62Dvjr0WSJEmSJEmSJHWh9wMzaK2IsG/GGS5r8fxZHTOBhTL+WiRJkiRJkiRJUpdZDXiF1gsJF2ac45E2MmRx3JDx1yFJkiRJkiRJkrrMwsDDtFdIyLpt1ktt5uj0+O8MvwZJkiRJkiRJktRleoA/01kxIcu2WW92mKXdY8MMvwZJkiRJkiRJktRlDqbzYsLvM8rSA8zKIE+rxyRgZEZfgyRJkiRJkiRJ6jLLAK/ReUHhRaKY0akxGWRp5zg7g+ySJEmSJEmSJKkL9QCXk11RYZUMMs2fYZ5Wji0zyC5JkiRJkiRJkrrQJ8i2qHBABpkWzThTM8e9ZLO7RZIkSZIkSbMZkTqAJKn2lgFOynjNjTJYY2wGa7Tqp0RhRJIkSZIkSRkblTqAJKnWeoCfA/NlvG4ZCyJvAqcXfM7BjANWAN4BLDjIMTcwGXgdeKPxtv/7LwH3AU9jkUeSJEmSJHUBCyKSpJR2BLbNYd01iCLL6x2sUXTrqrOAVwo+Zw+wGLAWsHbj7VrAqmS3i/Q14J7G8a9+7z+JhRJJkiRJkiRJUg30ALfQvcPJF84x20DHezrM26yVgWOIIfbP5/w1DXW8CJwN7A9MyPUrliRJkiRJkiQpod3J94L7wR3mGwnMyjlj33F9h1mHMgLYADie2JmRqgAy1DELuAk4jmh3NjKX74QkSZIkSZIkSQUbAdxFvhfZj80g5ws5Z+w7dssga38jgO2AU3l7hkeZjhvIrmWXJEmSJEmSJEnJ7E3+F9V/nUHOewvIeQ3ZzSuZB/gk8GABufM6ZgAbZvT9kCRJkiRJkiQpmZEUU2i4KoOs1xaQc90Mci5BtMSaVEDevI8sdvZIkiRJkiRJkpTcfhRzYf2BDLL+LueMZ3aYb23gdGB6zjmLOm4ERnf4PZEkSZIkSZIkqSvcTjEX16fQeSuqn+aYbyqwTJu5VgIuyTFbiuNNYNU2vx+SJEmSJEmSJHWVtSj2IvuEDvMemWO2E9rIMzfwTWBajrlSHYe38f2QJEmSJEmSJKkrnUyxF9lX6jDvJjnlegGYv4UcPcCuwGM55Ul9nEZ2g+UlSZIkSZIkSUpqNPA8xV5oX7nDzONzyrV/CxlWAi7NKUc3HFcDY1r4fkiSJEmSJLVlVOoAkqTa2B5YJHWIFr0GPAKskOGaZ9PcMPVRwFeBL1PdgsH9wB7EUHjBKkQRTsWYDkwG3mi8fROYlTSRpOEsCiydOkSX+DfwbOoQSm5tvK4DMIl4zi7lZTTR/ln56iWem7/eOCbj83PlwF+ckqSifDTBObNow3Q72RVEHgM+STzRG8oSwLnAphmdtxu9AOwIvJw6SBf5MbBN6hA19ybxIqyvSDL720nAQ8ADwIPA48CMJEmletob+GHqEF3iEuADqUMoqdWA21KH6BJnAfulDqFKWwi4KXWIGuolnoO/3uIxCXgUeAJvvtMARgF7pg6hZC4jfrB0qx2IAcKqn2uJi6WqjoWAXVKHaNMdxC6GTs0EPgK8OsznbUkUQzodCN/NphEzUbyTT91m7sbR7P9/bxH/HfcVSPrePgg8hXe0ScrPjsAyxMUe1dMhqQNIUs56gHkbx+JtPH4WsaPyUeI5+yP93r8Pb86rrVHA+alDKJkViB8E3epU4km+6mdL4K+pQyhTexPbjIuWxQ6RrO68Oxa4foiPjwC+BHyz8X5VvQXsw9DfC6ksRgOrNo7ZTSHawl0DXNF4+0Zx0SRV3AjgYODrqYMoiXGk2X0tSWUygriuuAyw+QAff5x4vd//eIrhOzqo5GyZJUkqwraJzptFQeQa4iJ+JwWdvwHHD/HxdwBnEHd7VtlUYrfNn1IHkQowjujtvjbwaaK11vVEceRKou2C7bYkdeJg4kaKt1IHUeH2BBZMHUKSSm7ZxrFbv797kWibfTNxo+4/8KamyqnyHaiSpO4wgnLPwniNaOPWrpeJnsYzB/n4ssA/qX4x5HVgOyyGqL5GET8LjwOuA14CLgSOIHaYZFHAlVQvi+Mckbo6NHUASaqohYm5jl8iRg28TDx3/3bj723tXwEWRCRJeVud2AGRQlb9+y9t83FTgJ2J/t4D/c5dFfg7sFKb65fFJGBrOissSVUznpilcwrRw/gx4k7vpRNmklQ+h6UOoMKtDmySOoQk1cQoYCPgv4id3i8Tr2u/DqyBNzWVkgURSVLeNkt47mcyWueSNh4zE/gQcTfJ/MTcpv7WIp5ILdVZtK73LNGv9abUQaQutwzwVaIw8nvg/fhcXdLw3g+smDqECuUwdUlKZwyx6/tY4E7gAeC7wAb43L00/IeSJOUtVUHkZaJNUxYebBytOJgopMxLtMx6qN/HNiT6kU7IIlwXu5u4g/Hu1EGkEhlB9DG+nNg58lnsEy9paF4gr49xwAGpQ0iS/s9KwBeAG4gh7f8DbAGMTJhJw7AgIknKUw/pCiKPZ7xeK7tEvghMJF60/hg4u9/HtiIGKi+QWbLudDpxl8zDqYNIJbYycDLwFPBL4L1p40jqUh8D5kodQoX4INV/DilJZbUU8CngaqJt9jeB5VIG0sAsiEiSNie/nQorA4vltPZwnsh4vYua/Lz/B3yfuDBxAVEYeLnxsfWJwso8GWfrJtOIO1UPBN5MG0WqjHHEBc+bgX8C26aNI6nLLAzskTqECuEwdUkqhyWIdriPAH8G9iLabakLWBCRpHrbmfjlfERO62+a07rNyHqHyLVEf9ChnA4cQwxe+w1wP3BV42PLAxcTFzar6hFi4NzPgd7EWaSqWp/4uX0Rzg2Q9DaHq1ffu4GNU4eQJLWkh7iZ6bfAk8D3iBtHlZAFEUmqr32Iwb1zAZ8knwv1q+awZrOy3iHSC5w6xMe/DxxE/G49i7hQ+eXGxxYALqXaM0MuJNr53JY6iFQTuwD3AMcTs4ok1dtmwGqpQyhXzoqRpHKbAHyeuNHy98B6aePUlwURSaqnQ4mL9qMaf16YfAY0LpvDms3KeocIwGnA1Nn+bhZwJDFIDeBXxEDkfRufO4ZonVXVixRPEG069gBeSZxFqpsxROH1fuJnTk/aOJISs51Sdc2Nw9QlqUp2A24k5otuhc/jC2VBRJLq5wvETofZf+F+jux/LyyT8XqtyHqHCMAk4Lx+f54C7E4MTh8B/AzYn+gVegfxPT6VeIJTNW8Rd6a/i7i7xRZZUjpLAGcCf8fB61KdfZS4cK7q+RAwf+oQkqTMbU202b4B2BWv1RfCb7Ik1UcP8G3gu4N8fBVipkiWUu0QmQHcldPaP228fQHYAvgD8b39IXAw8DfgpMbnfI5oo1U1lxN9rL8CTE6cRdLbNgZuIub4eOFMqp8FiAvnqh53/0hSta1PtKG+kyiMuGMkRxZEJKk+Pgv81zCf87kMzzcXsHiG67XiJuDNnNa+ETgX2LDxfg8xGO1I4HWincFM4D3ACTllSOVJYE9ge4YfMC8pjR6iOHsjsYNLUr04XL161iSed0qSqm91ojDyF2CdxFkqy4KIJNXDLsCJTXze5mS3q2OpjNZpx7U5rt0LfAR4pPHnY4FjGu8fCTwGjCXa14zOMUeRniSGv60G/A7bY0llsArwT6KIKak+NgDWTh1CmXKYuiTVzxbAzcQc05TXVirJgogkVd/awNk0v+Vyr4zOm3Kgep4FEXi7IPBl4GuN988Hzmi8fwLVuDP7ZmAfYEWioGZ7LKlc5iV+Nn0HGJk4i6Ti2F6pOuYh5tNJkuqnh+hA8QDwTWC+tHGqw4KIJFXbEsAlxIupZmXVezpVQWQW8I8CzvNZYqg4wDNEi4peYijaZwo4f156iS26mxJ9TM8lBqhLKq8vApcBC6UOIqkQ++FFk6rYGxifOoQkKalxwFeJwoi7vzNgQUSSqmtu4CJgyRYftz7ZFDMWyGCNdtwOvJrzOQ4HTu7354OAl4AFgYk5nzsvzwGnEG12dgf+jq2xpCrZBrgFexFLdTAv0d5T5We7LElSn8WI3d/nN95XmyyISFI1jSDaN63b5uOzapuVQt7tsg4CftLvz6cAf268P67x52uAGTnnyML9wHeBjYndRJ8CHkqaSFKeliV20Nl+Raq+w2m+Xaq601rETBhJkvrbE7gHOBB/17fFgogkVdOngD06eHwWbbNS7S7IsyDyEeCX/f58H9GKps/TRIFhC6I1zZ7AL4CncszUil7gOiLzasA7gS8B1xOtxiRV31jgdOIFlKTqWovY9avychaMJGkwCwK/Bv5E2vmtpTQqdQBJUuZWJoZ6d2J9YCng3x2skaIgMhm4Iqe19yQuIvbdgTED2Bd4c5DPfw34XePoAVYHtgLeTQxcX51824rNBO4F7mgctwO3AS/meE5J5fFLor3g71MHkZSbQ4F/pg6htsxLzIKRJGko2wH/Aj4N/ArbXjfFgogkVcsI4pfguAzWeh9wXgbrFOl84I0c1t0ZOAcY2e/vvgHc2uTje4G7G0efHmBRojDyrsaxIjEEdT7ihXDf2zGzrTcNeHmA4wXgLqL4cU/j8yRpICOAc4EdgasSZ5GUjw8DRxPPEVQuexPPAyVJGs48RGeKzYmWmZPTxul+FkQkqVo+BWyS0Vob0VlBJMWdCaflsOb7gQuA0f3+7jrgex2u2ws82ziGuxg5hiiMzAW8Akzp8NySBPGz5SJga7yLXKqiccTMoP9JHUQts12WJKlV+xNzZD9I7BrRIJwhIknVkUWrrP427PDxRRdEHieGmWdpc+JiYf8dGm8QTzSKHJo+HZgEPIPFEEnZmofoPfzu1EEk5eIwHLhaNu8B1ksdQpJUSqsBN+G8wCFZEJGkasiyVVafdYjhu2VxOtkOBt8IuIQ5v6efBh7J8DySlNqCwOXACqmDSMrcasCmqUOoJe4OkSR1YhwxcP3XwNyJs3QlCyKSVA1Hkl2rrD6jiaJIu2ZmFaRJp2e41nuBy4g2Vf1dSDypkKSqWRy4svFWUrV4gb085gX2TR1CklQJBxJdNBZNnKPrWBCRpPIbTwz4zsNGHTz22cxSDO/vwEMZrbUmcaf0+Nn+/jngENLMRpGkIixPFJdtryNVy17AIqlDqCn7MOcNOZIktWtd4AbgnamDdBMLIpJUfp8B3pHT2ut38NgnM0sxvF9ltM5qxB3SA30/Pw68kNF5JKlbbUPMHJBUHWOwl3hZuJtHkpS15YDrgM0S5+gaFkQkqdzeARyd4/rLd/DYJzJLMbRHgTMzWGcl4CoGvoPy+8ClGZxDksrg+8CKqUNIytSh+Pq/2723cUiSlLUFgSuAD6cO0g18QiRJ5XY0c7Z2ytIyHTz2BWB6VkGGcBzwVodrLEsUQwbqnX8V8F8dri9JZTIPMS/J1wpSdawIbJ06hIZ0SOoAkqRKGwOcA3yJmrfI9UWOJJXXIsCncz7HosBcbT52FvDvDLMM5AE63x2yHHA1Axd/HifuoJjR4TkkqWw2Jf/fMZKKZTum7jUf8JHUISRJtXAC8N+pQ6RkQUSSyusLxF28eVuqg8fm3TbrWDorVqxKDGQfqDXYVGB34MUO1pekMjue+DkpqRp2A5ZIHUID+ggOU5ckFefrwDdSh0jFgogkldNiwBEFnWvpDh6b52D1e4DzOnj8msC1wJKDfPwQ4LYO1pekshsLnAaMSh1EUiZGAh9LHUJz6MHdO5Kk4v03URipHQsiklROBwPjCjpXJ3NE7sosxZy+Acxs87HrA38FJgzy8R8BZ7S5tiRVyQbAMalDSMrMIURhRN3jvcB7UoeQJNXSscDXUocomgURSSqfHuCjBZ6vkx0i12eW4j/dDvyuzcduTgxKX3CQj/+NGFafSg8xt2V+omCzNLASsDrxYnkFoqVCrYegSSrUV4B3pA4hKRNLAzukDqH/4O4QSVJKxxHP92vD7e+SVD4bExfIi9LJnJJbiBkfWf6+mQl8ghja3qodiELK2EE+/hTwQeCt9qI1pQdYBFi537FK4+2KNN8/egrwPPBc423f+3cDNwMP0d73SJJmNy9wFDUfvihVyKHAJalDCIDxwD6pQ0iSau9bwKvAKamDFMGCiCSVT5G7Q6CznQhTiDkc62WUBeB7xAX/Vu0JnAOMHuTj0xuf81ybuQYzF7AR8H5gS+BdxO6PTo0Dlm0cA3mVKEjd3DhuAh4HejM4t6T6OQo4CXg9dRBJHduJeP7weOogYl86u/lIkqSs/BB4FLg0dZC8WRCRpHIZB+ydOkSLbiC7gsi/iB6XrdofmMjQrSKPAP7Zxtqz6wHeTRRAtiFadM2dwbqtmh/YqnH0eYG4I/R8om3YtAS5JJXTgsDhRFFaUrn1EPPoatczvMs4TF2S1E1GAOcCmxJtyivLGSKSVC67EVvri9TprIqs5ojMBA6k9Yv4hwGnM/TvvP8FftFeLCC+RxsBvwSeBu4k7qTegTTFkMEsAhxE3PHxPDE4fjei0CZJw/kc/ryQquJgBt81q2KsB6yVOoQkSf3MS9xEuWTqIHmyICJJ5VJ0uyzonoLId2m9VdYxwE+H+ZwbiFYw7ZgfOBK4A7gO+BiwWJtrFW08sB/we2LnyHnAokkTSep2ixI/5ySV32LALqlD1Jy7QyRJ3WhJ4GKan29aOhZEJKk8FiPaMJXN48D9Ha7xL+C4Fj6/hxj++/1hPu85YC9a23XSA2wA/Ap4BvgRsEYLj+9G8xAD2J9PHURS1/sC3lUuVYUX5NOZH/hw6hCSJA3iPcQM1pGpg+TBgogklccWpPm53ekOkV7gtx08fhqxM6bZokUPcCLwjWE+bwZRDHmqyXVHELNIbiN2lRxEdVrHPAAcggPXJQ1vGWJ3maTyez+wUuoQNbUv3dVWVZKk2e0MfCl1iDxYEJGk8tgsdYAOdFIQ+ShwS5OfO4JokfW5Jj73s8Dfm1x3m0aG06ler+epwAeB11MHkVQaX6TzYrmk7nBI6gA15DB1SVJZHEcMWa+UUakDSJKalqogMiODNe4idiGs0uLjvk7MtmjGKODXNHfn8unAj5v4vDWA7wHbN5mhjD5FDIGX8vYScHyic/cA8wELDHIsBsyVKFsZrQqsTeyYk1RuHwO+RmvtQ9WZDYA1U4eQJKkJI4Czief+LyXOkhkLIpKUjX2J4eGP5LT+wsDqOa09nH9nsEYv8Bvgqy085izgW01+7lxEf8vdm/jcW4HDGLo91JLEnRAHUu3dlGcAv0wdQrXxMnBy6hCDGE1cnNqQuFC1IbBy0kTdbw8siEhVsBCwJ3GxQ8Vwd4gkqUyWAiYCu1CRNttVvsgjSUUYQdzxfCbR2ikvKbcoPp7ROq20zboOOJjmftnODVxEc8WQF4mLeFMG+fhcwLHAg8Qdk1X+PXkjcDgVeUIjdegtoi3ej4EDiN1sCxN9c38DzEwXrWvtkTqApMwcljpAjSwA7J06hCRJLdoZ+HTqEFlxh4gktW8+4g77XRt//ihxMX1WDudKOT/kiYzWuQu4D3jnMJ/3GFHcmNrEmuOBS2iuYDSLeAE6WIFndWJXStVmhAzkHmBHYHLqIFIXewm4tHEsRRQQDyXupha8i/h5fl/qIJI6tinx//Q9qYPUwH7AuNQhJGkQz1Ps6+ERwFji52L/o+/vxgNLAEsTz8f73o4vMKPe9j1iDuvNqYNkodejtsfydLfHSf898khzbEH3W46YuzB79q1yOt8tA5yrqCPLJxtHDnOul2i+Ndg7iF0OzX4dRw+yTg8xR2NKC2uV+XiUaAmm7nMF6f/7yPN4MLtvVTLjiN1jD5D++9kNx5c7+3ZKLTuK9P/dV/X4YQv/DmpPD3GDUOp/6yoeZ7bw7yC1YzHS/3dexPF0Vt+wnI0nrhvsRXTs+DPRDSL1968Ox13AmOH/ibpf6m+kR7rDgohHtx5b0N02BV5g4Oxn5HC+eYl2LSn+LV7J+GuZB5g0yLmeBt7d5DqLMnBBarDjHOJF6OwWA/7UwjplP54FVmrye6ziWRApj3mAX5H+e5r6uKnTb6TUIgsi+R2vEG1IlZ+NSf/vXNXDgojyZkGk+/UQO0h2A74JXAPMIP33tIrHV5r8N+laVe6NLkl5+BBwFdFbfiB7kv32zeVJ9/M6q/khfSYDpw7w948Shaa7m1hjaeBvwBpNnvMuBp5HskvjY9s3uU7ZvQJsCzyUOohUAZOJnSIHUO/Wc+sCy6QOISkT8+Nsi7wdkjqAJFVYL/AkcCHwNWBzYBFgH6I19qR00Srna8TMxdKyICJJzduV+EU6eojPGUcUTbK0bMbrtSKr+SH9/YgYYNznXqIY8nATj12JKIas3OS5XiHmkfS/YNkDfIkYxD5YYatqXiFmhtyZOohUMWcA76Xe/2/tnjqApMw4XD0/C2LBSZKK9jJwLjG/aQKwCfBdonOC2jcX8DMG7sJRChZEJKk52wG/AUY18bk7Z3zulHffZr1DBOAZorAEMRtlM+CpJh73LuBami8QzSCKU/0LLaOAnwAnNLlGFTxOtGi4PnUQqaLuJ/4fuz11kET2TB1AUmbWB96TOkRF7U8MCZYkpTET+Adxc+QyxPyRK5MmKrctgINSh2iXBRFJGt4WxLbLZgdHbUlzhZNmpdwhcmNO655E9PTcihh+Npx1iGLI4i2c40BiJkOfeYl/xzrd/XgLsCGxC0dSfiYTuwifSx0kgY2oyGBFSQAcmjpABfXg91WSuslbwAXA+4nWTydhS612nEjMdy0dCyKSNLSNgEto7Y6u8UQLlayk3CFyTU7r3k08+Xitic/dGLgaWKiF9Y/h7V0oEEPw/grs1MIaZXcpUcxzO7BUjCeI9lHTUwcp2CjgnalDSMrMvsB8qUNUzMbETmdJUvd5kLh+sBTweaLNlpqzINGCrHQsiEjS4NYB/gTM08Zjt8kwR6odIk+QT8usPm8N/ylsTezyaGVQ/cnEHR59VgZuINsiVbc7FdgNeCN1EKlmrgc+kTpEAmulDiApM/MSRRFlx90hktT9phA7HlYAvtP4s4Z3ALBG6hCtsiAiSQNbCrgMmL/Nx2dZEEm1Q+TaROft82Hgj8DcLTzmbOKujj5LEQWVlG3HijQVOAL4JDFDRVLxTm8cdbJm6gCSMnUYJR6U2mXeQcy0kySVwyvAl4GVgP8lZo9ocD2UcEarBRFJmtNo4DxgkQ7W2JjWLuQPlWWJDNZpR6qCSA8x6OwcWutLfyUx1GtW488LA5dTn2LIbcSupp8AvYmzSHV3HPV68WRBRKqWtYgB6+rcAcBcqUNIklr2NLHDb23g9sRZut1OwOapQ7TCgogkzek7REGjE2OA92WQZW7S3aGXoiAyimj31OodBrcCe/B27/75iHZnq2UXrWv1At/D4elSN3kYOCN1iAJZEJGq57DUASqgBzgkdQhJUkfuBjYAvs3bN19Ul1GhAAAgAElEQVRqTt+lRLtLLYhI0n/aHfhcRmuV+QLRc8ADBZ9zPuBiWn/h+AiwI/B6489jgYuAdbOL1rX+DWwFfJH6DXKWut23qc8ukcWACalDSMrUh4lhqWrfJtTj5hxJqrrpwFeJm14fSpylW21AXE8rBQsikvS2FYBfZ7jeOzNYI1Xro2sLPvcSjXNu3+Ljnge2Iwo4ACOJVltbZhetK80CfkEU3f6aNoqkQTwEnJk6RIHKfBOApDmNJdo9qX0OU5ekarmBaKF1auogXeoEou1717MgIklhLHA+7Q9RH0gWBZFUflPgudYA/kk8sWjFZGJnSP87NL4B7JZRrm71J6K39yeAlxNnkTS0H6UOUCALIlL1OFy9fQsBe6UOIUnK3GTgcOCT2EJrdqtQkt99FkQkKZwIvCfjNbPYIp9ih8jLROuqImwD/B1YqsXHzSBmhtzS7++2JbaxVtVtxPdrR6KPqaTudxv1KVyulTqApMy9E9g0dYiS+igOU5ekKvspsAtRINHbjqEEN1NYEJEkWJ+o7mdtIWDhHNbN2znAtALOcyCx22F8m4+9vN+flwTOogS/eNvwBLA/MRPlqsRZJLVmFnB16hAFabWwLakcHK7eOoepS1I9XApsDjybOkgXWYf4nnQ1CyKS6m4E8GPyu5DeadusFDtETst5/R7gWGJey6g2Hn8MUfzoMwo4l3IWn4byJPAFYFViDoHbcaVy+kvqAAXJsuWkpO6xFzAhdYiS2Yx4/iZJqr5bgA2Be1IH6SJHpw4wHAsikuruY8Sd93kpW0HkPuCmHNcfA0wEvt7m408GTprt774FbNJBpm4yC7gE+ACwPPB9YGrSRJI6ZUFEUpmNJnbmqnkOU5ekenkc2AJ4IHGObrEz2bSQz40FEUl19g7gOzmfo9M76mZkkqJ5E8mvCLMA0SLrgDYffzbw+dn+bl5gRWBKB7m6wVPAccByRDHkEmBmykCSMnMf9dhGb0FEqq5D8dpBsxYG9kwdQpJUuBeA7YCnUwfpEp9NHWAoPqmRVGfHEXM+8jRfh4+fBkzKIkgTZhGtmfKwLDE8fas2H38lcBBzto16A/ggsEjj7bmNvyuDycAfgF2JQsg3iDZZkqqlF/hX6hAFsCAiVdcKwNapQ5TER4kd0ZKk+nmMKIq8nDhHNziALm65aUFEUl2tDRxewHnaGRg+uycyWKMZfyR2KmRtHeAGYPU2H38rsAcwfYjPmQycD+xDFEd2Bc4AXmnznHmYBfyTaPG1BbFDaVeiKFL0TiBJxXopdYACjAHGpg4hKTcOVx+ew9QlSXcTLaPK3sWiU3MB+6cOMZh2htlKUhX8gGKKwp3uEIHYNbB2BusM59gc1twJOA+Yp83HPwLsCLzewmOmEkWGPxD/xqsQc2LWBdYD3gOMazNPK2YCDwFXA1c03nqniFRPL6YOUJD5ce6RVFW7AktgK5ChbEE875Qk1dt1RAeLi4lieV0dwJwzYLuCBRFJdbQRsHlB58qiIFLEDpGLgJszXvNw4BTaLzz19eB8roMMs4j+/ffxdjuwUcSAr/WANYFFia2cExrvL0zzT1p6iQFqDzaOB/q9/xjwVgfZJVVHHXaIQOyK7ORntqTuNRL4OPDN1EG6mMPUJUl9LgWOB76SOkhCawJrAXekDjI7CyKS6qjI4U5ZtMwqYq7E1zNcawQxrH72AeitmEzsDHkok0T/aQZwV+MYyEhitswEYEGiqDGNuOt52mzHFGx3JWl4dSmIOEdEqrZPEBd3ZqYO0oUWIVq8SpLU51hiBteGqYMk9FHgc6lDzM6CiKS6WQ7Ys8DzlWGHyG+BOzNaayxwGvChDtaYQbygzHrHSrNmAs83DknKQp1aZkmqrqWBHYBLUgfpQgcCo1OHkCR1lbeAjwC3k83NsmW0L/AFuuxGUoeqS6qboyj2Z9/IDNbIsyAyC/hGRmstBFxJZ8UQgIOAyzuPI0ld49XUAQrS7rwoSeXhcPU5jcBh6pKkgT1KvVsqTgC2TR1idhZEJNXJ/MDBBZ8zi4tgdxGzKvJwNnBvBuusCFwPvK/DdY7m7VkfklQVWewWLIM3UweQlLsdgWVTh+gyWwIrpQ4hSepa5wITU4dI6IDUAWZnQURSnXyc4i9KvZLBGq8Bd2ewzuzeAo7LYJ0NgRuAlTtc5/PAyZ3HkaSus3DqAAWpy04Yqc56iFkiepu7QyRJwzmGbK4PldEuwLjUIfqzICKpLkYBn05w3qwuDl2f0Tr9/TfwYIdr7AFcTecX+z4LnNjhGpLUrRZKHaAgdX2RJ9XNx3FeRp8JwO6pQ0iSut5LwDdTh0hkHLBF6hD9WRCRVBdbAcskOG9WF4eyLojcAnyvg8f3EEWM84lB6p04EvhBh2tIUjerS0HEHSJSPSxG3O2pmH1ncUiS1IxTgIdSh0hkx9QB+rMgIqkudk103qwuDt2Q0ToA04EDgRltPn4k8EOivVVPh1kOB37c4RqS1O1smSWpahyu7jB1SVJrpgNfSB0ikZ3o/PpRZiyISKqDEaQriGS1Q+QB4OWM1jqW9meSLAhcDHyqwwy9RP/pUztcR5LKoA47RKYC01KHkFSYbeh8flzZbQWskDqEJKlULgSuSR0igeWBVVOH6GNBRFIdvBdYMtG5syqIzCKbtlmdtMpaA7gJ2KHDDL3Ax4BfdLiOJJXFKqkDFMD5IVL91H13xKGpA0iSSqcX+GLqEInslDpAHwsikuog1e4QyPYC0aUdPr6TVll7E227VuwwwyzgAGBih+tIUlksDyybOkQBbJcl1c9BdD5LrqwWA3ZLHUKSVEr/JNu26GXRNXNELIhIqoOUL1buz3Ct3xF3E7Tri7TeKmsU8H3gXGDuDs4NMBPYDzizw3UkqUy2Sh2gIO4QkepnIWCP1CESOYh4nixJUjt+lDpAApsB86YOARZEJFXfSsDqic49FXgww/WeBa5t87E/Jwaht2Jh4DLgmDbP2d9MYB/gnAzWkqQyqUtB5MXUASQlUcfh6iOIWXiSJLXrfOIaT52MAtZNHQIsiEiqvpTtsu6mvfZUQ/ltG4+5CjiC1naXrEPMG9m6jfPNbgbwIdrLLkll1kN9CiJ3pQ4gKYlNSXfzUSrbEO0QJUlq13Tg1NQhEtgwdQBwi6ek6tsk4bnvyGHNC4itlT1Nfv79wAeBt1o4xwHAz8imJ/RbjfNflMFazegB5gcWASY03i5CFIOmNo4pA7x9CnitoIyS6mM1os98HeTxO09SORwKHJU6RIEcpi5JysLPgK8Ao1MHKZAFEUkqwFoJz53HxaG+tlmbN/G5k4CdgZebXHs0cDJwZHvR5jAd2BO4JKP1+lscWI/YbrkOsCRvF0DafTLxLPDAAMcjwLQO80qqpzq1krEgItXXAcCXgDdTBynA4qTdgS5Jqo5ngQuJm0jrYkPiRtZO5uN2zIKIpCobT9rt7HldHDqX4QsibwG7Aw81ueZiwG+ItgdZmEYMs78sg7UW4u3iR9/bJTJYd3aLNY7NZvv7mcDNwJXAFcD1RLFHkoayBHBI6hAFyXpmlqRymR/YG/h16iAFOAgYmTqEJKkyfk+9CiKLAssCj6UMYUFEUpWtmfj8d+a07pnACcACg3x8FvFirdkB7BsSrbiyKjJMBXYhigftmgDsQcwe2Zy0M69GAhs0jq8Qdz9eQ3x9VxKzYpLe3SCpK30RmCt1iILkMTNLUrkcRvULIg5TlyRl7Y/EDa11a5v1WMoADlWXVGUpCyKPA6/ktPYbDD586y2iiHBWk2sdQhROsiqGvAnsRHvFkAnEi+m/AM8APwW2pPt+V80N7EC0F7sT+DdwPLBCylCSusri1Gd3CNguSxKsT7QxrbJtgeVSh5AkVcqrwF9ThyhY8jki3XaRSZKylHJ+yNU5r/8j5hyUPgX4ALHbYzhzAT8nhnhldSfCZGBHoqDRrLHAx+n+IshQlgC+DDxM7Bj5EPW5K1zSwL5E/HyrCwsikqD6w8ar/vVJktK4MHWAgq2bOkCZLjhJUqtSFkQuynn9p4Gz+/35NeKutT838diliJZPB2eY5w1g+8a6zZgPOIYYWP4LylcEGczWwHnErpETgVXTxpGUwA7AkalDFOz21AGkCnk1dYAO7EvM8KuiJYgbj8rK9q6S1L3+kDpAwVZJHaAKF58kaSAjgTUSnXsKcHkB5zmp8fZFYAvg7008ZjPgFmIeRlb6ijHNnH9h4Diipdj3ibYyVbQwcDRwCg7elOpkNeBc6vccO6+ZWVIdnZc6QAfmAT6SOkROPkZ5n9NdT9y8JEnqTv8mrtPUxSLAgikD1O3FmqT6WJSY9ZDC5cQsjbzdBfwS2BS4bZjP7QGOAq4iZnVk5VXg/cQLraEsBfw/ohDyNRL/8ivIPcAHgZmpg0gqxELAxVT37ujB3Ei572iXus1ZwIzUITpwGPG8s0pGUu5h6qelDiBJGta1qQMULGk3DQsikqpqgYTnzrtdVn+fAO4b5nPGES+EfgiMyvDcLxMtom4c4nPGAz8gWmN9hnRFqqK9AOwMvJI6iKRCjAZ+A6yYOkgCzcytktS854E/pg7RgbXIdidyN9gOWCZ1iDZNo9y7jiSpLm5KHaBgSdtmWRCRVFWpCiKzgEsKPN9w/YCXA/4B7J/xeScRxZDBtnX2AHsB9wKfJrvB7WUwFdgFeDR1EEmFWBS4FNgqdZBEfp86gFRBE1MH6NBhqQNk7JDUATpwId6gI0llULeCiDtEJCkH8yc67z+I3QHdYBvgZuA9Ga/7GLAJg7fpWp4oCv2WGEBZNwcAN6QOIakQWwN3EK0D6+gu4MHUIaQKuhR4KXWIDuxNddqjLkns+i2riakDSJKa8jDRhaMuLIhIUg5S7RC5MNF5++sBPg/8mehpn6WbgY2InR+zGwN8CfgXsGPG5y2Lo4lCkKRqGwUcB1xB7BCpK9tlSfmYTswSKauxxA0iVfBxyjtM/Rni95Qkqfv1Etdb6sKWWZKUgxQ7RKYCZyQ4b3/zAucC3yP7n/EXA1sAzw7wsRWIXREnEDNL6uhI4OTUISTlqgfYFrgG+BrVGxzcqt+lDiBVWNkHYVdhuPpI4ODUITpwBjAzdQhJUtPq1DZruZQntyAiqapS7BA5nbTtslYCrgc+lMPapwC7A5MH+NgHgFvJvjVXWcwCDgJ+nDqIpNzMCxwO3EPsvts4bZyu8BBwd+oQUoXdRrSlK6t3ApulDtGh7YGlU4foQNmLapJUN3XaITIfCXdgWhCRVFUpdoj8IME5++xC/PJ8dw5rHw0cxZx3mI0Evg38gXQzW1KbAXwY+zNLVTQSWAs4Cfg38BPiAp/CBcTWfkn56KX8zy/KPlz90NQBOnATUcSXJJVH3WbzzZfqxKNSnViScja+4PP9kYHnauRtHHAi8Mkc1p4G7AecP8DHJgBnEwOF62oasBcxQF5S+S0GbNA4NgTWI3aGaGC2y5LydxbRBrWsMyz2JJ4zPp86SBuWBnZKHaID7g6RpPJ5InWAgs0PvJLixBZEJFXV9ILPl2J2xBrAOcDqOaz9ErHr5LoBPrYOsStkyRzOWxYvEK3J/po4h1Qm85FPS79m9BAF5AWABRtH//eXApZNlK2MbqFePY6lVJ4jbrr5QOogbRoNHEgUdcrm45S3o8Z0YqagJKlcXgNepT4dOIq+kfn/WBCRVFWvF3iuO4C/FHi+HuAIYmfIXDms/xCwIwNv13wf8cI82S+uLtA3p+XfqYNIJbMocF7qEMrECdguSyrKRMpbEIFoO3UiMXOtLEYRBZGyupi4uUmSVD5PEDe/1kGywk9Z73iQpOG8VuC5Tqa4C0MLAxcBPyKfYsj1wEYMXAzZBricehdD/gfYAoshkurrPuD3qUNINXIJ5b64vQLxHLJMdiB2DpbVxNQBJEltq1PbLAsikpSxonaIPEJxdzxvA9xJfncJXkDMBHlxgI99gHhBPndO5+52k4F9gE9TfDs2Seom36Vcd3pLZTedmNtWZmUbrl7mYerPA39OHUKS1LYnUwcokAURScpYUQWRTxPDtfM0hui9fAWweE7nOIloAzVlgI/tTQzPzWNHShncA6yPvZgl6UnKf2FWKqOyD8jeBVgidYgmLUPsECmrM4G3UoeQJLXNHSIFsCAiqaqKaJl1KbFrIk8rE4PNP5/T+rOAI4FjGPiO332Ii191nDk1FfgqMUT+nsRZJKkbnIi75KQUbgXuTh2iAyMpz0yOMg9Th/IXzySp7p5PHaBAydqxl/kXvSQNJe8dItOBz+S4fg9wIHAb8N6czvEmsBvw40E+vinRg7iOvysuB94NfJv8dwBJUhm8CPwidQippnop/1yIQ+j+G2xGAQenDtGB24j2upKk8hqoa0dVuUNEkjL2dM7rfx94KKe1FyB2ZfwamCenczwPbA5cPMjHVwYuJNp11cmzwIeB7YGHE2eRpG7yQ6KQLimNs4CZqUN0YCm6vxXVTpSntddA3B0iSeVXp+fbFkQkKWOPkl//3CeBE3Ja+33A7cRF+bzcB2wI3DzIxxci2oG9I8cM3WY68CNgNeA84k5MSVJ4kcF3E0oqxrPAn1KH6FC3D1cv8zD1GTjjSZKqwB0iBbAgIqmqZgAP5rT254DJGa85Cvg6cC2wbMZr93cNsDFRMBrIGGKA+so5ZugmbxC7fZYDjgJeSZpGkrrTEcDLqUNIKn3brB2I51zdaFlih3BZXQq8kDqEJKljFkQKYEFEUpXdl8OafwAuyHjNZYCrgWPJ9+fy2cB2DH1R6wRgsxwzdIuXiALUMsAXgGfSxpGkrvU74LepQ0gC4BJgUuoQHeihe2d0HEzkK6uJqQNIkjJRp5ZZDlWXpBzcm/F6jxGDzrNsp7QXcAewSYZrDuTbwH4MPyD8y8AHiaHiVWwb9RTwWeIuwG/iHc+SNJRJwCep5u8DqYymUf62SAcDo1OHmM1o4OOpQ3TgJeCPqUNIkjLhDpECWBCRVGVZ7hCZThQvsrqAPg/wC+Ku2wUyWnMgM4FDgK/S3AWt6cD5xE6SFYFvkf+A+rxNJ4bH7wesAPyA7FueSVIVHQU8lzqEpP8wMXWADi0K7Jo6xGx2BhZPHaIDZxHPdyVJ5WdBpAAWRCRVWZYFkc8At2S01jrAreR/J9obxAu8n7f5+EeBrxG7KXYl2oWV5ZfzdCLv/sAEYBd8sShJrbiY8t+JLlXRrcC/UofoULcNVz8kdYAOnZY6gCQpM2Vu39iqmalObEFEUpXdQzYXwM8BTs1gnRHA0cANwCoZrDeUx4BNgcsyWGsGUVzYFVgQ2BI4HriJ7mqjMo3IuR+wCJH3TODVlKEkqYReIS5YdtPPeEmhl/LvEtkaWDl1iIbliJ3RZXUXcFvqEJKkzMydOkCBkl2rsSAiqcreBK7rcI37iLvGOr0otBjwJ+BE8u+bfCnwXuD2HNaeBvwV+AqwPrAw0UrsVOJ7NSOHcw5kJjF75ZfERbt1ie2WuxI7QV4rKIckVdFnKX+7RKnKziLhXZUZ6ZZdGZ+g3HfjnobFa0mqknGpAxQoWUFkVKoTS1JBrgS2aPOxbxAX+9/oMMOOxJ18i3S4znB6iRZXJwCzcj5Xn0nABY0DotizHLEDZhVg1X7vL9ni2m8ALwDPN94+RxRBbiaKPWVp3yVJZXI+tl+Rut0zxC7gnVIH6cBBxPPWqQkzjAY+lvD8nZpJFMckSdVhQaQAFkQkVd2VxGDwVk0hXmR20qN5LPBdYiht3l4E9iG+3pTeAh5sHJfO9rExxC/3sQO8HUu8KJ3E2wUQCx6SVKy/ErOXvNtY6n4TKXdBZCFgT9Je0P8AsYu7rC4Dnk0dQpKUKVtmFcCCiKSqu4VonzS+hcdMJ1ovXdvBedchXqiu0cEazboB+BDwZAHn6sT0xuFMD0nqPncAu5H2bm1JzbsYeJmY71ZWh5G2IHJownNnYWLqAJKkzNVph0iyVufOEJFUdTOAq1v8/L2AK9o83zjgO8CNFFMM+RGwOd1fDJEkda9HgO2xYC2VyTTg7NQhOrQJsHqic68AbJvo3Fl4mSiKSZKqxR0iBbAgIqkOmm0jNQv4CO2/uNiUmG3xRWBkm2s0600i61HErgtJktrxPLAdtl2Rymhi6gAZSLVL4xOJzpuVc4iimCSpWiyIFMCCiKQ6+APD90PvBQ4EftvG+vMBpxAttlZp4/Gtuh9Yn3ghJElSu14HdgAeSh1EUltuAe5JHaJDBwDzFHzOMZR7mDrAaakDSJJysXjqAAWyICJJOXoCuGqIj88EDgbOaGPt7YG7gSPaeGw7fgusR2fD3iVJmk7MDLk1dRBJbeul/LtE5gf2LvicuwATCj5nlu4FbkodQpKUi6VTByiQBRFJytmvB/n7ScD7gV+1uN5CxJ1ZfwKW6SBXs2YAnyVeML5ewPkkSdU1DdgH+EvqIJI6dibR9rXMDiv4fGUfpn4aw+9+lySVUxHXl7qFBRFJytmFwGuz/d29ROupVoau9xBD1+8htvgX4WlgC+AH+OJHktSZZ4DNgd+lDiIpE88Al6UO0aH1gHUKOtdKwDYFnSsPs4gimCSpmiyIFMCCiKS6eBM4r9+f/whsBDzcwhqLAxcQbauK2mZ/NfEC8R8FnU+SVF03AesC/0wdRFKmJqYOkIGidm0cXNB58nIF8FTqEJKkXPRgQaQQFkQk1Ulf26wTid7Bzf7w7QEOInaF7J5DrsF8B9gWeK7Ac0qSqulMYmfI06mDSMrcxcDLqUN0aF9gfM7nGEM8py+ziakDSJJysxAwLnWIAlkQkaQC3ADsCnyeGKTejOWAPxMzRhbIJ9YcXiVyfpmYHSJJUrt6id97BwBTEmeRlI+pwDmpQ3RoHqIokqfdKPcw9VeBi1KHkCTlpk67Q8CCiCQVohf4Q5OfOxI4CribGLpelDuA99J8TkmSBvMasDOxM9IZVFK1TUwdIAOHEzuz81L2YernYWFbkqpstdQBCjSTaG2fhAURSZrTasC1wA+Ju9WK8mtan2siSdJAHgA2IGZmSaq+m4F7U4fo0BrAhjmtvTKwVU5rF+W01AEkSblaP3WAAk0i4Q1bo1KdWJK60Giircg3iB7DRZkGHAH8MuN15wGWABYd5JhA7ISZ2sgwbYD3nyMuqj3YOF7POKMkKVtvAd8DjifhXVeSCtdL7BL5buIcnToUuD6HdT+Rw5pFepB8vi+SpO6xXuoABXoo5cktiEhSWIcoSKxd8HkfA/YEbu1wndHEXXUbEHcVrE/sdMm67cCzxAuyviLJjcB1RAFFkpTWNUTLmbLfJS6pPWcCJ1DuThB7A58j7hzNylyUf5j6adj6UJKqbDTwntQhCnR/ypNbEJFUd+OArxM7Q0YWfO5LiSG37bzgmx/YnmixtT7xi3NsdtEGtVjj2LTf300B/gZcAVwJ3AnMKiCLJCm8ABxNXAz1gplUX08DfwZ2SB2kA2OJ58c/yHDN3YGFM1yvaL3AGalDSJJytTrFXNPpFhZEJCmRTYhdIasUfN5ZRFuu42mtcDAPMRx3b2BH4m63bjAO2LZxALwIXEUUSH4HvJwolyTVwf8CXybbu6kllddEyl0QATiMmOWXVYH3kIzWSeUvwBOpQ0iSclWndlmQuCBS5q20ktSu+YBTiF0NRRdDHiQKMd+iuWLIWGA34BzgeeBc4i63bimGDGRhomjzC+AZ4o7lzcm+fZck1dmdwMZEv32LIZL6/AF4JXWIDq1KPHfMwirAlhmtlcrE1AEkSbmzIFIgCyKSusljxMDD63I8x3bA3cQQ86KdQrS2amYg4trAr4mh5r8HPgzMnV+03MwF7Av8FbiPaE02IWUgSSq5R4EjgffigF1Jc5pK3EhTdodmtE7Zd4e8QbwWkCRVVw/w/tQhCjQLeDhlAAsikrrBw8DHiDu4fgFMz+EcE4hhhJcBy+Sw/lD+Tfxy+xQweZjP3RT4I3AbcCAwPtdkxVoF+B7wFHA+sFnaOJJUKn8D9gBWBn4MzEgbR1IXm5g6QAb2pPObaMYSz6fL7DcM//pBklRuawLLpQ5RoEeBaSkDWBCRlNKDwEeBdxK7Id7K4Ryjgc82znVADusP53RgDWLY+GB6gJ2AvwPXUv6+z8MZRbzIvQb4E7FrRpI0pxnAWcC6RBH598DMpIkklcFNxM7cMhsNHNThGrsDC2WQJaXTUgeQJOVu19QBCnZv6gAWRCSlcD+wP/AuomCQ112u2xE91k+m+J0WLxJ38n6Uwfs49zQ+5zbgEuB9xUTrKtsDtxKtHVZKnEWSusUk4HjiTrH9gFuSppFUNr1UY5fIoXR2zSKrtlupPELcMCVJqrbdUgco2A2pA1gQkVSk+4h5EqsTg7bzKoSsRAyUvIzYfVK0i4B3M3S/35WJfBcAaxURqst9mLhL4CfA4omzSFIq9wCHAUsDXyFaDEpSO84kenSX2fK031P9nWQ3mD2V0yn/v6EkaWjLUr+uGRZEJNXCv4gL3u8Gzia/dh/zAic0zveBnM4xlNeIPsW7E8PQBzIOOI4Y7L5tMbFKYxRwOFEYKXrOiySlMIWYG/UpolC+OvAz4M2UoSRVwlPA5alDZKDdXR5lH6YOURCRJFVb3dpl9RKtPZMalTqApEq7m7j4fwH53t3UQ+w8+S6wRI7nGcpfiD7HTwzxOTsCpxB3u2lgU4ji2VDfR0kqs3uJHYKXEXOjpqaNI6nCJhLtSctsF2BJWtsxN5ZoW1tm1xBDZyVJ1fah1AEKdjdxM3FSFkQk5eEOohByIflv814X+B9go5zPM5ipwBeAHzP417ogccfvB4sKVVKvEsPl/5E6iCRl6A3gSqIA8mfgsaRpJNXJ/2fvvsMkqarGj39nA+ySQcmioCCoREVQMaBEBcQACqKoZAmiYg4vZn1N+CoGRGRJioKAoqCACCpZxAQoIjkISI7Lsju/P87Mb2aHCXW7q+pWdX8/z3Ofnd2trjrdPR2qzr3n/FYLaHAAACAASURBVIz4frV07kC6MB3Ykzi3KOqNwHLVhFObObkDkCRVbiP6r5ds9nJZYEJEUrmuIE5Wfk71iZAViIazexArRHK4FNidaBI/kY2Bn+CqkKncCWwD/Dl3IJLUoQeJz4N/Ej2zRv/5eMa4JPWvx4AfEb2J2mxv4nt/0f6DbW+m/gixwl6S1NvenTuADEyISOoZlwOfAn5B1AOs0kzgQOCTwFIVH2siTxD394tMfGI2AOwPfA1YpKa42uomomHmNbkDkaQpDAI38uSExz+B26n+M1CSUs2h/QmRpxGlZ39eYNvnAi+rNpzKnUwk2SVJvWsF4C25g8jAhIik1ruMSAycQT0XgbYG/g9Yp4ZjTeTvxKqQKybZZkngSODNtUTUbhcRNTNvyR2IpMo9DJyeO4hR5hLlrFJH0RnKktQElxJJ27VzB9KlfSmWENm76kBqcEzuACRJldub/ps8eycxoSw7EyKSOnExkQj5NfUkQp5FrLR4bQ3Hmsgg8BXgf5i8Ae5zgVOBZ9cRVMt9FfgIMC93IJJqcTuwa+4gJKnPDBKrRL6QOY5uvRpYncn7MM2m/c3UbwLOyx2EJKlSM4mKIv3mDKovr1/ItNwBSGqVC4k+Dy8hmsNWnQxZgqgXfBV5kyHXAa8gmqdPlgzZBPg9JkOmch/wOuD9mAyRJEmq2nE05AJEFwaYevXHTsCyNcRSpWNp/3MlSZrcbsAquYPI4IzcAQwzISKpiN8DWwIvBc6i+kTIAPEB8U9iBUHOZYRHABsQj8FkXgX8Bliu8oja7XLg+cDPcgciSZLUJ24Fzs4dRAn2ZPLzgrY3UwfLZUlSr1sC+FzuIDJ4grie2AgmRCRN5nziQv8riIv9dZTHegHwB+B48mbMbyeaN+5H1IyfzOuAM4kPNo1vAXAYsBlwfeZYJEmS+s2c3AGUYEVgxwn+73nE98w2uwC4NncQkqRKfZD+XB3yB+D+3EEMMyEiaTy/ATYfGr+lnkTICkQj8suIklw5/QhYl0hyTGV34GT6rxlWiouBjYH3EU2MJUmSVK+f0aALEV2YaBXIPrVGUY05uQOQJFXq6cAHcgeRSWPKZYEJEUkj5hE1azciymOdX9NxZwLvAa4B9iLKZeVyD/Bm4C1DP09lZeDTwPQqg2qxe4jndDPgisyxSJIk9bNHgRNzB1GCLXhyv77ZxCSlNnsMOCl3EJKkSn0RmJU7iEx+mTuA0UyISLqHqF+4OvB24M81Hntr4C9EKaWlazzueE4kVoX8JOE2twPrECsf7q4iqBb7PrA2cBQ2hpQkSWqCObkDKMnY1SBvApbJEUiJTqE3VvBIksb3EmDX3EFkcj1wde4gRjMhIvWva4B3AasBHwduq/HYGwCnA78GnlPjccfzT2JFzK5EgiPVY0RC55nEapGHywutlX4BbArsDfw3cyySJEkacQnx3bft3snCM2x7oVyWzdQlqXctSe9MSujE8dRTir8wEyJS/zkX2J5IRHwXeKTGY69NrMT481AMOT0KfBRYn+iZ0q0HgEOJxMg3iBJk/WIB8EPisdwBuDRvOJIkSRrHIL1x4X05YKehn9clf//Bbt1KOecjkqRmOhxYK3cQGR2bO4CxTIhI/WF0f5AtiNp9dZYxegbwA+AqokdHbqcRCaEvAI+XvO87gYOJD7svAneUvP8mmUsk1dYCdgP+ljccSZIkTeE4GjZLs0P7Df05UZP1NjkOmJ87CElSJXan/X2uunEhcG3uIMYyISL1tuH+IM+g/v4gEE3HDwf+RSxtz/2ecz2xMuX1wI0VH+tG4CNESbI3AGfQGyefEOXWPg2sQZRduy5vOJIkSSroFuDs3EGUYDNgE+BtuQMpQS+s2pEkPdmzgW/nDiKzxq0OAZiROwBJlfgn8HXijafOkljDngJ8EDgImJ3h+GM9TqzW+CJRKqtO84BTh8ZqwB7AnkM/t8mNRLmzE4G/0DvJHUmSpH4zB9g6dxAl+AmwdO4gunQJ8I/cQUiSSrcocf1k8dyBZPQ48VndOCZEpN5yLvA14EzqLYk1bCngvcD7hn5ugl8TiZl/5Q4EuBn4FPBZ4KXAVkRD9xeSf/XMeG4jPrxOJPqCmASRJElqv9OI/ndN+b7eqWfkDqAEc3IHIEkq3XTgBKJsfT/7OXBv7iDGY0JEar95wI+Aw6i/JNawxYADgA8Rq0Oa4BbgPcApNO9C/nzg/KHxcWAZYHMiObIl0Xw+h38Ts9QuHfVnjsRaU00jfr/vyh2IJElSFx4lJrzskzuQPjcX+HHuICRJpRoAjgDemDuQBmhkuSwwISK12T3Ad4BvAbdnimERYG/gY0S/kCZ4gkgOfRp4KHMsRd1HzNQ7bejvqxE1kdciak4O/7lCice8A7ickcTHZcDdJe6/12wKfBP4PvC9zLFIkiR1aw4mRHL7GQ2dOStJ6sgA8GWiTHq/+zfRS7eRTIhI7ZO7PwjEe8dbgUOB1TPFMJ7fAfsDV+YOpEs3D42xlmYkObISUZNy1tCfY38eBO4kEh9jx53EyiJNbUWi98w7hv7+/XyhSJIkleZi4Brie6XysJm6JPWWjwCH5A6iIb5OVEdpJBMiUnvk7g8CUTJoJ2L1Ra6yTuO5A3g/UaOxaeWxynQ/8MehoWrNBA4EPkn762tLkiSNNUisEvl85jj61X+As3IHIUkqzXuAz+UOoiHuBY7OHcRkmtjEV9KIecRKkI2ALYBfkicZMgBsD/yJqHPblGTIAuBwYB3geHo7GaL6bEH04/kaJkMkSVLvOg6/P+dyPFHqV5LUbtOJ1RCH5Q6kQb4LPJw7iMm4QkRqpib0Bxn2SiLL/eLMcYx1CVEe60+5A1HPWB34KvCGzHFIkiTV4RbgHGCr3IH0IctlSVL7LQH8ENghdyANMo+YuNxoJkSkZvktcCRwKvBY5lg2JRIhW2SOY6x7gA8DR5GvdJh6y2zgg8Tv1azMsUiSJNVpDiZE6nY58PfcQUiSurIqcDpR0UUjTgBuyx3EVEyISPndQZyIHAX8K28oAGwAfIZmZri/TzSp+m/uQNQTlgT2At4LrJY5FkmSpBxOAx7AMqF1mpM7AElSVzYBTiGSIlrY13IHUIQJESmPQeBXxGqQXxBLynJbG/gU8ObcgYzjz0R5rItyB6KesCrwbmBfYOnMsUiSJOX0CNEjcO/cgfSJecCPcgchSerIIsAniIm60zPH0kQnAn/LHUQRJkSket1MrAQ5GrgpcyzD1gE+BOwOTMscy1gPEB8238amg+re+sAhwFvw80+SJGnYHEyI1OV04O7cQUiSkm1A9H/aIHcgDfUEcf2uFbwgJFXvCeDnRLmns4D5ecP5/zYDPgDsmDuQcQwCxxOJmtxN5dVuA8CWwPuBrTPHIkmS1EQXEaV718odSB+wmboktcsM4trUocDMzLE02RHAtbmDKMqEiFSda4kkyDHAfzLHMmwa0Rvkg8BLMscykTOI5Yd/zR2IWm0RYBdiRcj6mWORJElqskFilcjnMsfR6+4CzswdhCSpkAFiUuUXgQ0zx9J0DxO9iFvDhIhUrrnAT4neIOcTJxdNMAt4KzFLfu3MsUzkEiLrfn7uQNRqywD7AAcDq2SORZIkqS2OAz5LXABSNU6gGb0jJUmTewnwBeDluQNpia8Bd+QOIoUJEakcfyeSIMcD92SOZbRlgf2IBtIrZY5lIv8APgqcRnMSSGqXmcCriBUhOwFL5A1HkiSpdW4GzgG2yh1ID5uTOwBJ0qTWJ1ZLbp87kBb5L/CV3EGkMiEide5h4ESiLNYlNOti/mrAe4iZ8k29OHwr8EnixMCG6Uo1DXgpkQTZGXhq3nAkSZJabw4mRKryl6EhSWqW6cRn375Ej11XSqb5JPBA7iBSmRCR0l1GJEFOpHkv+vWIRum70tzX933E0sNvAo9mjkXtMgBsTCRB3gysmjccSZKknnIa8CCwZO5AetCc3AFIkhayCrAHsBfwjMyxtNWlwHdzB9GJpl4wlZrmfqIc1pE0b2bPAPAKolH6qzPHMpnHgG8QDanuzRyL2mVdIgmyC/CszLFIkiT1qkeAHxMXh1SeJ4Af5g5CksTiwBbAO4EdiNUh6sx8oirN/NyBdMKEiDS53xNJkJNp3mqG6cAbiBUhL8wcy2QWAEcTy+huyRuKWuRZjCRB1s0ciyRJUr+YgwmRsp0B3Jk7CEnqU2sCrxkamwOLZo2md3yF5k0YL8yEiPRkNxAzo+YQDb+bZjbwDuAQmj9b/jSiYfrVuQNR480CNiW+oGxHs5N8kiRJvepC4FriApLKcUzuACSpTwwQ5a+eD7ycSIKslTWi3nQ98OncQXTDhIgUbiOSICcSPUKa1CB92FOAA4CDaH4D6d8BHwYuyh2IGms28CIiAfKKoZ+dqSFJkpTXIDEx7LOZ4+gVdwO/yB2EJPWgGUTy/vnARqP+XDZnUH1iP6LMZmuZEFE/uws4iUiCXECUdmqiNYD3AnsCi2WOZSp/IxIhZ9LMpJLyWQx4MZH82JxYDbJIzoAkSZI0ruOAzxAzbdWdHwGP5w5CkhpsAJhJVI2YPWrMApYkmp8/bZyxEvYAyeEE4KzcQXTLhIj6zb3AKUQS5DyiwV1TPZ/oD/ImYFrmWKZyI/AJollgKxsqJdqZSKhdSsuz4hVanEiAbE4kQTYlvuRIkiSp2W4CfgNsmTuQHjAndwCSlGBl4IEajzeNSH40/ZqXwk1E1ZrWMyGifvAQ0cviROBsmj1DZwDYikiEtOEE5G5iOf13gLmZY6nTPsTz8wRwOfCHoXEBkSjpN8sCaw+N5wIvBTbBzxhJkqS2mkM7zkea7ErgT7mDkKRES+YOQI00H9iVmGjeel6sUq96lKjVeiJRvunRvOFMaWlgN6IO33qZYyniEeBrwFeA+zPHktMMYuXDpkSTe4B/EsmRy4lm8lcDd9L+EmIzgGcykvgYHusAy2eMS5IkSeU7FXgQL4x1Yw7tPweQJAng48CFuYMoiwkR9ZJ5RPLjROB0YmVI020M7Au8heb3B4FYEXEk8GngP5ljaarhRMGeo/7tXkaSI6PHTTSvxNhTWDjZMfzzs7DklSRJUr94BPgxsFfuQFpqAVFnXZKktjsb+FLuIMpkQkRtNx84h0iCnAbclzecQpYgEiD7En1C2uLHREb42tyBtNCywEuGxmgLiBJb/xkad4z6efjv9wKPTTBGzzgbIPp2LDk0lhr189i/T/R/KwFPLetOS5IkqdWOwYRIp34F3J47CEmSunQH8Dbi+lXPMCGiNhoEzieSIKfQnp4NGxJJkN1o19Lzc4APEyWgVK5pwIpDY4MObj+XSIwMEIk2G5FJkiSpLBcA/yZWCivNMbkDkCSpS4PAW4mkSE8xIaI2uYhIgpwM3JY5lqIWB95MJEI2yRxLqtOBLxCPe90GsN5uEYsODUmSJKlsg0QfjM9kjqNt7gN+njsISZK69EFiknTPcTaxmu5PxAtwdaLc0DdoRzJkXeCbwK3AUbQnGTKfqHW7PvBa6k+GrAf8EHhpzceVJEmS9GTH4kSlVCcSq7glSWqr7wFfzR1EVVwhoibbDLgldxAJZgM7E6tBxvaKaLq5wA+ArwDXZTj+JsDHiCQMxBuvJEmSpLxuAs4FtsgdSIvMyR2AJEldOBs4kB6eEGFCRE3WlmTIOkQS5O1E8+w2eRD4NvB1ool3nQaAVxCJkC1rPrYkSZKkYuZgQqSofwKX5g5CkqQOXUVM9p6XO5AqmRCROrMo8EYiEfLyzLF04i4iCfJtosZtnQaA1wAfpX0raSRJkqR+cyoxkWrJ3IG0wBx6eEatJKmn3QlsB9yfO5CqmRCR0qwF7AO8A3hq3lA6chPwZaI81iM1H3s68AYiEbJhzceWJEmS1JmHgZOAPXIH0nCDwPG5g5AkqQOPEGXsb8gcRy1MiEhTWwTYEdgPeFXmWDp1NfC/RMPyupe9zQTeAnwEWLvmY0uSJEnq3hxMiEzlbNpT9lmSpGGPEJVcLskdSF1MiEgTeyawN/HFf4XMsXTqMuALwM+ABTUfexbx2H0QeEbNx5YkSZJUnj8A1xHnSBrfMbkDkCQp0aNEmazzcwdSJxMi0sIWJ5aIvR3Ymuh30Ua/IRIh51J/DdsliNU0hwAr1XxsSZIkSeUbJFaJfDpzHE31AHBa7iAkSUrwGLA9cF7mOGpnQkSKkljbEGWdXgssljecrpxKJEIuy3Ds5YADgYOHfpYkSZLUO47FhMhEfkL9PRolSerUY8AOxETqvmNCRP1qOvAyIgmyE7Bs3nC68gRwAtEj5OoMx18ReB+wP7E6RJIkSVLvuZG4cNLWvopVmpM7AEmSCppLTAg/J3cguZgQUT8ZAF5AJEHeDKySN5yuPQp8H/gqcXJSt6cDHwD2IvqFSJIkSeptczAhMta1wIW5g5AkqYC7gR2BC3IHkpMJEfWDdYBdiUTImpljKcP9wOHAN4A7Mxz/2cCHgbfhe4gkSZLUT04Bvo0rw0c7hvr7NkqSlOo64NXANbkDyc2Lmf1pPnAF8HDuQCq0GrALkQjZKHMsZbkDOAz4DtG0r27rAx8FdgamZTi+JEmSpLweBk4C3pk7kAY5LncAkiRN4WKiTNZduQNpAhMi/eFuYgnv8Pgjvdnw7alEP5C3EP1BesX1wJeJ5emPZjj+psDHiGZLkiRJkvrbHEyIDDuXPOWLJUkq6lTgrfTmteCOmBDpPYPAlUTi46KhP/9F7y7hXZKofbcrsDW99Tv9W2I5+mlE4/Q6DQCvJFaEbFHzsSVJkiQ11x+IshvPzB1IAxyTOwBJkiZxGNH/d37uQJqkly4e96sHiWVPw8mPS4D7skZUvUWBbYmVIDsAs/OGU6oHiC/V3wGuznD8acBriBUhL8pwfEmSJEnNtoA4Z/lU7kAyewj4ae4gJEkax8PAPsAPcwfSRCZE2udaRpIfFxKrQfohyzcd2JxYCfJGYJms0ZTvb8C3gBOIL9Z1WwZ4B3AAvdF4XpIkSVJ1jsWEyMn0dl9OSVI7/Y3o//vP3IE0lQmRZpsLXMZI8uMi4M6sEdVrAHghsRLkzcBKecMp3TziS/S3iOc3R1mz9YgkyNuAxTIcX5IkSVL73ECU+H1l5jhympM7AEmSxjgKeDf2C5mUCZFmuQ24gJEEyJ+Bx7NGVL8ZRKmmHYiVIM/KG04lbga+S7xJ3ZHh+DOIvisHEqtuJEmSJCnVHPo3IXID8PvcQUiSNOQRYD/guNyBtIEJkXzmEkuYRq/+uJnebX4+maWJniDbE/0rlssbTmXOIpqk/5L6m6QDrADsTbxBPi3D8SVJkiT1jlOI85vFcweSwTFELxVJknL7I7A7eXoRt5IJkeotIPp+/J1IgAz/+W/yXBRvijWJVSDbAy+nd38X7wOOJpqk/ytTDJsSq0HeBCySKQZJkiRJveUh4CSiF2G/OTZ3AJKkvvcY8Ang6/T3NeZkvXoROpdbeXLi42rg0ZxBNcQM4CVEEmQHYO284VTuT0RvkBPJU7dvFpEAOZDowyJJkiRJZZtD/yVEfgdclzsISVJfO4+oAnNt5jhayYRIZ+7jyYmPK4F7cgbVQMsC2xAJkFcP/b2XzQV+TCwbv5Q85c+eTpTE2ht4aobjS5IkSeofvweuB9bIHUiNjskdgCSpbz0AvJ/oS2zpxg6ZEJncXOAqFk58/J1YCdKPvT6KeDYjpbBeBkzPG04tridKYh0N/DfD8QeI5ugHEc3Sp2WIQZIkSVL/WUAkCD6ZOY66PEKUCZMkqW6nEtf+bs0dSNuZEAkLiP4Oo5MefyeWHc3PGFcbzAQ2YyQJ8uy84dRmEDiDWA3ya/L8niwBvI0oi/XcDMeXJEmSpGPpn4TIKcCDuYOQJPWVPxKrQs7PHUiv6KeEyOPATcCNo8b1RKkr+3ykWQ7YlkiCbAsskzecWt1NLEv7LvH7k8OzgQOIWr1LZYpBkiRJkiDOi84jVq33ujm5A5Ak9Y2bgI8Q/Yktj1WiXkqIPMTCyY4bxvz9Dvzl6dQA0QR9eyIJshn9UQprtEuIJuknAY9lOP50og/LgURfFkmSJElqimPo/YTIzcBvcwchSep5DwCfB/6PPNcge16bEiL/ZeEEx9hxL/b1KNMiwEsZSYKsmTecLB4Ffkj0B7k8UwzLAXsA+9NfjQolSZIktcfJwOHA4rkDqdCxOMlSklSdR4DvEcmQuzLH0tOakhAZBG5j/ETHDcQSoYdzBdcnFgE2Bl5JzOzZDJidM6CMLgGOB04gEm05bEA0StoNmJUpBkmSJEkq4iEiKfL23IFU6NjcAUiSetK9wDeHxn8zx9IXqkqI3AfcQzyh90zx8y1D4/GKYtH4ZgIvYCQB8lJgsZwBZXY9cByRBLkmUwxLAm8E9iSeD0mSJElqizn0bkLkQvKdJ0qSetNtwNeIVSEPZo6lr0yWEHmcaCBdJKkx+uf7gfnVhawOzQCez8IJkCVyBtQA9wI/IRIhF5Kn5NoMYGvgbcCO9O+qHEmSJEnt9juiwsPqecOoxDG5A5Ak9Yx/AV8mVh7OzRxLX5oB7MX4iY9HsSdHm80ANmQkAfIyYgVCv5sH/IJIgpxBnjeeASI59TZgV2CFDDFIkiRJUpkWEImDQ3MHUrLHiIl0kiR16nHgVOBI4LfYkyqrGcBRuYNQKaYTfSeGEyAvB5bKGVDDXED0BfkJkfTL4elET5C3Ac/JFIMkSZIkVeVYei8hchpRFlySpFRXE0mQ47A/SGM0pam60k0D1mfhBMgyOQNqoGuJN5zjgesyxbAUsBORBHkFsTpEkiRJknrRdUTprJfnDqRElsuSJKV4GDiZSITkKtGvSZgQaY9pwLqMJEBeASybM6CGuhs4kUiEXEqeN52ZLNwXZFaGGCRJkiQphzn0TkLkNuDs3EFIkhrvXuDnwCnE58ajecPRZEyINNc04LksnAB5Ss6AGmwu8aZzPPAroi5f3QaAFzDSF2T5DDFIkiRJUm4nA4cDi+UOpATHA/NzByFJaqQ7iL4gpwDnEX2L1QImRJpjReCFo8YmmACZyu+IlSAnk6+m6zMY6QuyTqYYJEmSJKkpHiTO0XbPHUgJLJclSRo2D7iEaIp+FnARJs1byYRIHksTqwmGEx8vBFbLGlF7/INIgvwQuCFTDEuzcF8QSZIkSdKIObQ/IXIZcFXuICRJ2cwnPgt+OzQuJPqDqOVMiFRvFrAhI4mPFwJrZ42ofe4CfkQkQi4nX1+QbYgkyGuxL4gkSZIkTeR84EZiRX1bzckdgCSpNo8Qk7CvHhp/Av5ArHpUjzEhUq4ZwPNYuPTVevg4d+Ix4DQiCXI2eerwDQAbE0mQXbAviCRJkiQVsYAoN/U/uQPp0OPAibmDkCSV7h5Gkh7D4yrgZuKzS33AC/WdGwDWZOHkx/OB2TmDarlBYgnacURDogcyxfFMojH623A1jyRJkiR14ljamxD5OXHRTJLUTreycMJj+Oe7yFN5Rg1iQqS4VVk4+bExsGzWiHrDAmIJ2mlE472bM8QwHdgU2GFoPC9DDJIkSZLUS/4N/B54We5AOmAzdUmq3wLgIaJM1dgx0b+P9/93kW+StVrAhMj4liMSHsPJj02AlbNG1FvmAmcRSZDTiTequi0BbE30A3kNlsOSJOW3be4AJKnhDge+lTuIivVauY7NieoKbdNrz0OvT+Z0treqdgdeQ63DAnw9qwb9/mJeCnju0HjeqD9XyxlUj7of+AVwKvBrInNbt6czsgrklcAiGWKQJGki83MHIEkN12sXqfuBz1kz+B1D6s4gvo6kntEvCZGlgeewcNLjecDTcgbVB24jVoGcCpxP/Y3RpxErfYaTIBvUfHxJkiRJkiRJUkP0WkJkacZf8WHioz7/IBIgpwF/pP4ZQYsBWxIJkO2BlWo+viRJkiRJkiSpgdqaEBlOfIxd8bFqzqD62CVEAuQ0IiFSt1WJ5McOwBbArAwxSJIkSZIkSZIarOkJkWUYf8WHiY+8ngDOJRIgPwdurfn4A8BGjJTCekHNx5ckSZIkSZIktUwTEiLTiQTHGsCzWXjFxyoZ49LCHgbOJMphnQHcV/PxZwGvYiQJYlJMkiRJkiRJklRYHQmRAaKPw+pE0mONMT8/vaY4lO4uYgXIacA5wGM1H39FRkphbUX0B5EkSZIkSZIkKVkZiYgBYDnGT3asPjTs6dAe1zPSFP1CYH7GWC4lEmaSJEmSJEmSJHWlaEJkKcZPdgz/uWT5oalGfyYSIKcCfwMG84YjSZIkSZIkSVK5hhMiiwHPYOJVHstliE3VWQD8gUiA/IxYFSJJkiRJkiRJUs+aAfyH6NWg3nYrcPaocVfecCRJkiRJkiRJqs8MTIb0qoeB84CziATIP7AUliRJkiRJkiSpT5XRVF3NsAC4jJEVIBcDj2eNSJIkSZIkSZKkhjAh0m7XMbIC5LfAvXnDkSRJkiRJkiSpmUyItMt9wG8YWQVyXd5wJEmSJEmSJElqBxMizTYPuJCRBMjlwPysEUmSJEmSJEmS1EImRJrnKkYSIOcDD5Wwz2WAtccZ2wE3lbB/SZIkSZIkSZIazYRIfncykgA5B7i1w/3MANZg/MTHihPcZnqHx5IkSZIkSZIkqVVMiNTvMeB3jCRB/gYsSLj9U1g42bHO0J/PAmaWGqkkSZIkSZIkST3ChEg9/sRIAuQCIikykenA8sBKwOo8ebXHU6oMVJIkSZIkSZKkXmRCpBo3M5IA+Q3wX2BJIsmxCbDy0M+jx/C/LQ9Mqz9kSZIkSZIkSZJ6lwmR7i0ArgGuBW4HHgBmE8mNg4DPD/08O1eAkiRJkiRJkiT1OxMi6QaB+cQqjuGxztCQJEmSJEmSJEkNZEIk3QA+bpIkSZIkSZIktYq9KiRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMizPgyYwAAIABJREFUkiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMikiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMikiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs+bkTsASZIkSSrRAPBUYGXgKcBDwN3APcD9wGC+0CSprywOLAM8DNyXORZJkgATIpIkSU3zWmDFkvf5OHEx+O6hcQftvzDxdeAFBbabB+xAXIxpklcDTyuw3YPAiRXGsSSwS8L2c4jHtCkWB7YmnuP1iCTIikx8nvMEcC/wX+DPwLnAb4DrK4+0Wh8Dti2w3SDwFuCWasNJ9nJg7QLbzQOOBRZUFMc0YM+E7U+i/e+lrwKelbD99cA5FcUy1gbAJgnbPwD8uKJYOjUA/BRYvsC2/wF2rjacyiwJvIR4Lb8UWJNISC86apsniPfe4fFP4LfAecT3kjYaAE4hkvBTuQ14c7XhtMZ6wItK3N8C4r34DuDOodH09+aNgY1yBzGBc4F/l7CfnYBlS9jPaI8zcj7zX+I5f6DkY9Tt+xT7DvQw8X23Sd/DAXYEViiw3d3E+2VVlgPemHKDQUffjjVothvJ/xg58ozNabazyf8YOfKMfZCqdzH1/D5fAxwJ7AasVMs9K8/qwHyK39d3ZYlycmdRPP59K4xjjYQ4BoGlK4ylqBWB/YEzgcco5/VwPXAUsEWN96MsSxGJs6L39XN5wpzU0RSP/9MVxrFIQhyDwPMqjKUuPybtPj8KrFVDXLOB6xJju76GuFJtTdp9eGWeMDu2IfH67fa9+CrgWzT/PHCsbUm7n6/IE2bjHEI5n92TjbnAtcTF5p0p/8J8tz5P9Y9Bp2PXku7j1TXFexXwHSLhWCT53CTrkXZf35InzEldSvH4q0wKb5gQxyCJGzt6a5gQcTR1bE6zmRDp32FCRHWoKyEyejwB/IjmzlQb60uk3b8r84Q5qZSEyGPA8yuKo00JkaWJCwgPjxNXmeNCYgVPWxxM2v27k4VnbTfB0RSPfwGwTUVxmBApNupYIfLFDuK6voa4Uv2ctPtQ5ezZMq1F/B5U8R58OXHRrw0VTX5J2n07KU+YjVNHQmTsmE98xz6UWE2amwmRasbjxGrmtnw+f4+0+3dhnjAnlZIQeZBiq2E6YULEUXiYEHE0dWxOs5kQ6d9hQkR1yJEQGT3OAp5d+b3s3GxiyXXq/XpVjmAnkZIQGSRKFyxTQRxtSIjMAt5PZ897N+MyYLsa7l83BojVXqn3bfccwU7iaNLiv4tiJedSmRApPnarMKZ1iZIgqTFdX2FMnViDtNWMg8QEhafnCLagAeAAqk9MDwI3Ae+luYmRZ5H+/M6jmveutsmREBk9HgX+D1il6js6CRMi1Y4FwOnEqvKmWpbO3kuLlAyuU0pCZBD4G7BYBXEkJUSmVRCAJEmS2msrYnbmW3MHMoHdiBqxqQ4qO5CaPZO4aNxvXkLUmf8ynT3v3dgY+AVRSquKE7cybENn5Yva/np4KvATYGbuQPrY16imBM0AcATNvQie4gCiL02K6TSzzCPEczMHOJx63hNXI37PLiGSZE3TyfM7g+Y+v/1kFvBuYrLJN8mbGFE1BoDtgSuA12eOZSJ70Nl7adu/w60LfDt3ECZEJEmSNNYSwHFE3eWmfV/s9CRgB+AZZQaSweuIWZX94p1Ew93cs6X3AP5I1Hlumk5fDxtTbkPbHF4M/G/uIPrYCkRZq7LtRSRC224x4r2jE3sTF2yb5tvkWV32fGKixoeJhFETLE53z2/Tyhb2q1nAgcDfgddkjkXVWIYoRfi13IGMMY1IqnZiF9rXK2WstwN75gygaSe4kiRJao49adYJxMuB9Tu87XSiEXfbfRHYLHcQFZtO/N79gChh1ATPIUoCNGnl1Jp01+uk7TMMIcrpvCF3EH1sb8pNXqxA7yS53krnK2ieQnkla8ryUWC/jMdfBPgCzflO8jY6LyG5PHFBU82xLLEi9NN4nbRXvRf4ZO4gRtmOztsYLEp8/rbd4cAGuQ7uC12SJEmTOZgoK9AE3V7A3YvoQdJmM4ia/0/NHUhFFiFqPr83dyDjGCTKdzXFAURJiE7tDKxUUiw5/YCo5a/6DZe3Kqt0WVVluHLo9vOqSQnLZwKfyB0E8ADNSYgc2OXtm/T8KgwQv+dnEklJ9Z5DiZUJTdDte8C7aH9pyVnAycBSOQ5uQkSSJElTOQzYKHMMTyNKRnVjOeAtJcSS26rACfTmd/nv0t2qhyrtQTRab4LFiZJi3ZgJ7FtCLLktTZxQN7HEUD9YF3hfCfvZkmobtddpc7rvebERzVkN+A2a8fp6D3Bj7iCAVwHP63IfLyDK/ql5tgZ+Q5SPVe85ks56r5VpHeIzrxtlnBc1wZrExJba9eJJlCRJkso1jfxlTMqaCdUrszK3Bj6eO4iSHUz3F/mr8lngxNxBjLI7nZdrGW1feqMx+YbERVvl8T/A6l3cflEa0GC1RGV9zjTh82o9orRLp+YDdwCPdxnHz4Cju9xHWXrp+dX4NiA+85vSs0blmQl8PnMMB9LdCt9hvfIe8kbiHKBWbV9eI0mS1M/uAf4zxTaLEk2pu73oudXQOLvL/XSizFq5GwAvA35f0v5yOhS4EDgndyAl2BL4apf7eIKY1XkucMvQeJjoS7ACsCLwbKJx6soJ+z2FuODbJN2Waxm2MrAT8KOS9pfT3sDvgONzB9KHFiMSGp02Jf4o+WfsluXpwI4l7euNwCrAbSXtrxM7d3CbPxArSy8HbiXemweIUo9PIz6DdwBeQbHvJnfSnHr5zyBiL8NOwCHA7SXtr1c9AVwzxTYDRLm95SkvibEd8XvchLKx/wUuqPF4t9R4rGF3DY3JzAZWo/tr2TsBmwKXdLmfTixFeWW7hnsr/rWk/eX0ZeL5uLjOgw46+nZ02sCnLjeS/zFy5Bmb02xnk/8xcuQZ+yBV72KK/04eVnCf04iT+FcSs6IeTDjG6JEjGQJx4lDma/kn9YY/rrMo577cQVww69QaiccrY1XCWKsAdyfGMXrcDuxP8ZrfA8DGxKqPe6fY9xVEeaom2YJyXw8X1hv+uI6mnPvyEPDcLuJYJPF43ZbNaYIfU97vUicXz9cG5pZ0/Os7OH7ZvkC5r89P1xv+k1xF8VjnA29O2PdSRHL3zin2+9oS7kdZ/pdyn99P1hp9cxxC8cfo5oT9TiOSIlsR/WZSfn8nGgd0fC8n9/mEGM6tKIaqXU3x+3howX1OJ767bkFMpHkk4Rijx8nd3rkOvTshxiLjyHrDH9ellHNfbqK7/j0bJh6v1CfC0a5hQsTR1LE5zWZCpH+HCRHVoYqEyFjLA18B5iUca5AoebFkh8fsxh8T45xqzCNmqeZUVkJkkFjt0ulsuSYkRI5IjGH08/gVuvudXG5oH4+Ns///EDMRm+Y0yv98e0Gt9+DJjqa8+3IVnSexTIh0N24jvTnqb0s8/vWJxy7bLGImd5mvzf8Qv5c5LF0wxuHxkQ6PsxTwOca/sJmltvwEZtNd8n68cTu9UbYwVVUJkfG8DDg/4Xhjx0OkrSotyoTIwuPQDo+xMnA4kZBNeV4foP731gFitVOZ7yGPEN9lcyorITIInEHn5cSSEiL2EJEkSeo/dwHvJ/3ixUyid0WdXkzxi7ULCm43A9ivs3Aa6aXkr4fcqbWIZuWpHiLK87yfWPHUqXuG9rEOcNGof58LvJ7uL8SUbXWKl2sp+nqA3qlDDfAc4Hu5g+hTKxMXtot6O82fCJViV4rPbi36+lwReFNn4XRt1cTtj+vwOA8AHyM+D45m5LG5gQx15SfxFopfeCz6/K5EZyurVNzvifJsryESlqkWBz5VakQq0+3ESrMvJN5uSSJZVqdtKF4esuh7yGxgz87CaaRX03lyPYkJEUmSpP71VeD0xNtsW0Ugk0i5UPuxhG33IXqT9Ir306yyIkV9lvTVLXcRF1HLLOF2A3HB5KvEzLG9WThB0hT7U/wc7uPEfSliF2LlWK94C72V9GyT/YEXFtjuKcTqrF5S9PNqHmmlknIlLFPKMT5I930HbiUS5BsCZwLvoLuEd9l67fntN2cS5TL/0sFt96C7coyq3qHESqAUvXJOk/LdsA0+TQ2TJXrpAZMkSVKaQWDfxNvUWXJzuOFzEX8Hvgj8reD2y5NW67zpBoBjaH5J1NFeQPrM2CeIlRuXlx8O84jE0np0PtO5SimzAO8gLjb/uuD2i9KcpsVl+Tr5S4H1o2lEGbypGht/iWiy3Ss2AzYquO1pRPL1/oLbbzI06pZShmVJYgVbGf5GzOZPvbhZpZcBGxTc9hSif8UDBbd/EXGhXtW7kXit/jnxdtOJ/jFqrvnAuxJvU+d35jWJ1Q9F/IH4jLyh4ParU3z1cBtMB35ErKCrjAkRSZKk/nY7abM6K/1yOsa+FK+t/Z0xfxbRa7MylyEaxrdl5cv+pNcJ/hhwQQWxjHZlxfvv1G4Uv0B5FJHgSXk9vIvOe9E00aLAScTrQvXaiGgcO5GXAe+sKZa6pHyefIeo+35sRfsvy32J229ZSRTNkPr8PkxaYr3Xvo802cPA60gvn7U9sHb54ahE/6B4IhLqPac5gOLfeb9DlMxKKf/Za+8hKwEnMvXkio6ZEJEkSdIVCduuWFkUC5tJ8dUrDzFy4eH4ob8XsTExM7OXbEzMTG26AWC7xNtcAHy5gljaoujJ7uiT6F9SvA/K04iLRL1kDWBO7iD61KeB1cb595nAd+m8aWoTrQK8seC2/yAayUM8DkW9ifo+f4fdmbj9N4mLxr3macTKxCKuYmRlS0pC+s30VtnCprsR2L2D27WxNGk/GSStJFpd76mLU3wSwF3AyUM/HwU8XvB2W9B7Zd1eAXymqp2bEJEkSdJfE7Yt2jC2WztTfObWCYzUGX+QSIoU1WszqiBWXuyaO4gpbEL6ieihFO+J0WteDqxfcNsziIs9ECUk+nmGIcCORCk0dW9uwrZLAN8Y598/QNpFm9SL8jnsR/HVVaOTIKMvnk9lEaL3VZ1SH/tZRLmoLwLPKD+cbDp9fq8kGnoXsSj1P7/97kzgvMTb7FhBHCpXE89pdgeWLrjtDxhJgtxJvKcWdWBKUC3xYdInUBViQkSSJElLJmybshS9G6nlKSb7+2RSEi+5XNPBbb4HrFN2ICVKrXX8B+A3VQTSEt28Hr5PlM8qIiXxkksnr4cvEHXj1Z3DgXsStn8dC8+ofhbw8YTb30Tz6/anJCoeJXo9jZbyebUfxctIluF24D+Jt5kJfAi4DvgZUTO/LWUcx5OSqHiYJ5dB6+eyhW1waOL2L8aVPE3XxHOaoomKQaIH12gp7yEpiZdcUr/DDRDvq6Un2U2ISJIkKaVsVEq/kU6llLK6iCcvj//r0L8XkVKaK5ejSJshBjE7+2RgsfLDKUVq2YkjK4miHVJKWd0A/GrMv/2HaOJcVNNXifyKuDCfYgbwY7yQ1a07gPck3uZw4v0I4NvA7ITb7sPI6r+mSilldSJP7stxCvG4FrEK8IaC25ZhEDi9w9tOI97nzyCSaL8k3lvWKie02qSUsvoRcP+Yf/spxVfarErx0lwqx++AvydsP43eLAvXS5p2TpNSyurXwPVj/u13FO9tl1KaK5evA2cn3mY5okfiImUGYkJEkiSpv80GNkzYvo6Th25mw0/17+NJad6eyx7AvxNv8zzSHoe6LAKsm7D9IE++yN9PUmYNH0H0EBkr5fcgpXl7LocAlybeZlWivJ7nwN05jri4XdRqwKeAXYCtE253NHFxqOm6/byaRyS9qzheGU4tYR+LAa8hSqhdA1xL9Lp6Cc3vJdPt8/s4UQKniuOpHKnvMxtVEsXkXkR8B6xytHkl17CnAM9O2L4t5zQp/aZSmrfnsID4nnlr4u02Ab5SZiAux5MkSepvnyJtxs1NVQUyZHliRmYRdxMzhsbzE+AwitUHXhnYiZjd2VT3EzFeRNRpL2p3oob596sIqkMrkXay9ic67yOwP7B6h7edzCXEzN+qLQrsXXDbx5n4wupviWbORcqozQb2pNkN7B8nZub/ibTkzVbAJ4j3PXVuX2LGatHSHAfz5JURk7kNeF9qUBlsMjSKuBy4bIL/+x5RJ71Ism4z4oLsFQWP261fE7G/oMR9Pgt479C4hVglcxJwAc3qE/UiYsVqEZcS70fjOQL4IMWe35cBG5DWGFrd+RWRZC9q5aoCmcRs4JkVH6MXJgt8IXH7myuJYsTqFC8RezMTTzY4lujNtHiB/axJlCo8o+Bxc7iLONc7j7S8xEFECd2Jzv2SDTr6dqxBs91I/sfIkWdsTrOdTf7HyJFn2OxQdbiY4r+Th3V5rC2ImTopr4M3dXnMqXwsIZapLth+OWFfF5Z8P6ZyVkJsHxx1u70Sbjc8HiUusIxnjcR9lVGbeNPEY3aTzLkw8VhFR10lvN6eENMPp9jXwQn7up56L44cnRDb/4263WtIfw+bTyRGxrNI4r6e1+X9boIfU/z+fmDU7fZIuF3qGH0Bae+E211fwuOR4riE2PacYl+nJ+wrZcVBGTYmXjdVPd/D41bgm1R/4beoEyge+zum2NcvE/bVpAkMVTmE4o9H1Retl02IZZCYZFKGzycet+qRUs6wqKsTjn9ol8d6XcKxhsc2XR5zKl9KiGWq/lrfS9jXmSXfj6lcmhDb6DLF70+43fB4gIlXAW2Ysq9eyABKkiQp3bbExZyUmfqPklYqJdUMojxQEYM8ufHgWEcMbVfEiyl3BmxVvs+Tm7ZOZRbRT2Sp8sPpSOrsytSmvr2kjFILw44BHim4r9VJb3yfwxnErMkU04gLnauWH05f+QGR2C3bCXTet6JOK1J8gsB9TL0CMaWs3a7AUxO279YfgU/WcJxViObDVxKruKq4QFvUSsDOBbe9l0gsTibl+X0LzS9b2EvuI0rXFZVjhYgm93rSSg9C9Db6TQWxDBtebVvEPKZOhKa8h2xDWumwXL5CWo87gCWJc5quPx9MiEiSJPWXNYmLTWeSflJ3BvBw6RGNeD3FL1KeQ9Qhn8y1pDXua0vt7neR1gQU4nmve1bxREyIFJOSpLuSqWet3sfUF+1Ga8vr4RNE2YUUyxOPhSWku7M35TY9vwN4d4n7q9I+FC83eSxTJyN/BdxQcH+ziNWCdfoM8D81HWvW0LGuJBqz55DSW+wYYsLIZM6geMnR2dT//PazQaKET1EmRJrjucT3/FNITyKeBjxRekQjUvqxncbU33WvoHjvtAGil0gbvAO4LvE26wHf6vbAfgGUJElqrw2Y+gvvDKJe9zrAc4iEQ6fN9o7u8HZFlTkbfvR2RRv57kKUhEk5Mc7hEWLm6mXAEgm3eyNRNun/ptqwYsskbl9lEq7JUl4PRRtufgd4Z8FttyAuNlyVEEcO84kZ81cQs7qL2oyoN/6BqTbUhG4iSvqlzFydzP7ErN2mmwnsl7B9kdfnAqIkyucL7vNdRFnI+QlxdOszxIWrzwNPr+F4awA/I1am7kV9yfGZLFzWZSopz+9nC+5zf+Cr1Pv89rN7iBVKRSxG/I6krCrR1F7I1Oc0M4G1iHOadSj+nI2nrec0RftWvYMoQ/xQQhw53E+c01xI9M0r6p3ERKCunsfcdeoc+YY9RBxNHZvTbPYQ6d9hDxHVIaWHSJ2j6hImGyTEcgswveB+pxP1p4vu+6Ol3JupddpDZLRdEvYxPB4nGsUOy9FDZN/EY3ZzwbqtPURWJp6rIrE8RFo5tD8W3O8g8O3u70ohRyfENFFCb3Nitmfqc7njqH3YQyT9tTgAnJuwj4nGRE1Sm9hD5M0JMf02Yb8rAHMT9v2G7u9KRxYlekDcXSDGssbfqK+M1K4JcaWU3FmR4u/rg0RPhF7VpB4iEMndovE8UNIx7SGSb5xQwX0d7eUJsVydsN/ZRPKu6L7rWiXSaQ+R0VLPDQaJCWLrjdqHPUQkSZJUqkeovnxOyv6PpPisyfmkNSh9F+1ZRX0i6ResZxIXHp9SfjiF3ZG4/QqVRNFsKeVafkjaBZqU2fy7U04SrA7n0VlJnzk0f6JYkw0Ss/e7Wcn1X9pT3gOqWb0FcCdR+qWKOMo0l1i98Eziom7R3kTdWJcoO1W0TFk3qpjZDfHZd2pFcahzA6StLry1qkBUi/uA91V8jJTX7lT9EEd7lPjOUtSBdF4VoG5HkJ6omk30E1mykwOaEJEkSdJUPkLx2uadWI5oIlrEE6TPzj+S4nWCn0a7ZmW+l5jxn2I14HjynSSllj1ZsZIomiu1XEtquaIfERcEilic4iW2muALxEXTFMsAJ5FWqkELu47uVtcdRPNLFQ7biCi3VsQdpCU4IO31vDkLz46t2/1ESZY1iBJiZwCPVXi8TYmyj1V6AdG/qYjbSW8InPL8voooW6hqPZXiExAAbqsqENXiPaRPzEmRch7xKNGDKMV3iYkIRawDbJm4/5z2Jb1M67NJm/j2/7Vl9pskSZLy+ATwjYqPsSfFl+rfQpSKSnUzxWeBH0TMOGqDx4nau38Clk243bbEBcwfVhHUFFJPRF809SY9ZWeKz1a9F3jl0EhxA1FaoIj9iTJVRU/AcxoE3kb0E0npcfAC4DDiQok6803id/elibc7jVjt1hYHJmx7I53N8n+YSEYWcSBpCdQq3EnM7j2CiHsrohn6dpS/wu/jRJP6qi5opjxfNwLv7uAYjxB9KIo4kHgPVnVekri9K0Ta62DSExCpUlaa30Bnk07uoPj3xIOIku9t8DDxPeJSin8GAryJ6Cfyh5SDmRCRJEnSRD5J8QagnZpG2sn+6kSpjiq9HFgf+GvFxynLDcDbieazKas+PkXMcK1b6gqRtYhk1vUVxNJEKRfklqX618NaRALtzIqPU5Z7GDk5Tpn1+y7gkkoi6g+DwB7AXyie4L6XeNzb4ikUX80I0fy2aAPcTr0V+DDxWDbBw0SS6zTi831TYPuhsX4J+1+KSHp+pYR9jbU8aRMuXkT1CfvdiVW691d8nH62beL2N1USxeQuJy0Z24kqV3c1wXuofoLXokTfq6KeQ/Xf4bajXd+hryKS/Mcn3u6rJE5AMCEiSZKksf5LzKKqY/XADkSSo2kOIu2kJrfTgS8BH0q4zXRiVnfdHgWuIZa5F7U1aXWWhx1A8R4YW9Fd2Z8ybEwzV8QcRHsSIhCJjfczcQP2idTVRL5X/Yvo4/Llgtu/h/QEaU57AbNyBzHGYkQiquqLap1YAFw0ND5GlGvcbmhsQ1rCcrQdqCYhsjfNK503XLbw67kD6VEDpCdEzqkikCk8AFyc4bi94HYi8f6zGo61C5FYbZJpxHfh9+cOJMEJwMtIW/24CLHStzB7iEiSJGm0HxIzluoqpdTUpqG7Eb1N2uRjwO8Sb1O0bEfZUvs87EdnPU+uIJptFxn/6GD/ZWvq62FbYqVIm3wD+EnibXK9HnrJYRRbaXMGUfqoLabT3NJFB9COazs3E/XvdyAasn8NeKiD/WxGrBQp0wyau1rpANrTGLltXk/apJx7SCzLo6yOIvrw1JEMgeZ+h9uD9n2/OZgoB5wi6T624UNTkiRJ1XoEOJoobbEbsUKkDs8FtqjpWKlmE71N2mQ+MTutymaRZUlNiGxI1KTvZcsDb84dxAQGiItybbMXsRpJ9ZlPzGifO8k29wP71BNOaV5LWl+aOq1BrLpok1uAQ4jH9KeJt51ONC4u0+sq2GdZ1gRenTuIHjSNKB2a4kzgiQpiUXkeIlYUb0R8B7ivpuO+mOhH1kTLEuUV22Qu0U+ksufPhIgkSVJ/uoOo8X0gsCoxe+jSmmOouh5yt/anfd+Xbydq3C/IHcgUzid9ZvChxIWwXrUPzSvXMto7gSVyB5HoQWAnokyb6nM18OlJ/v/9tK8xcVNn/g5renwTuRfYlSj7mGLFkuNo+uPX9PjaaB9g3cTb/LyKQNS1W4nE6r7AKsSq4j/XHEPTX6NNj28819FZ0/lC7CEiSZLUXv9i6i/8c4kLDvcM/Xk7kfi4odLIprY00Sy0yVYnSnvUtdS+LOcSyYPP5A5kEo8DvwF2TLjNRsDniAbCvabJ5VqGLUW8ZtvWZ+NvxOqWH+QOpM98CXgj8Pwx/3428P36w+nKusArcwcxhS2Bdai+9N/6wF9L3uc84BPE521RZdbpXx94eYn7q8I2RN8tV7yV48Wk95h6kHb10mqbK4mG2pN5jIXPaW4lzmlurja0Ka1MTL5osnWBzYkSsW1yGtEj65Cyd2xCRJIkqb1+Cbw3dxAdeifRLLTpDqJ9CRGIxMFmpDcLrdORpCVEAD4IXEjvzdJ8PbFSq+kOpH0JEYiSgC+jwpmGepIniMf7j4w0z36IaFzdNk1fzQhR1u5Aqo31Y8TKny8QSff5Je7770T5zqI14MtcBdmGmdPDZQsPzh1ID3gWcArRhDnFl4ikiKpxEuklzJpiX0Y+55rsINqXEIGYCPUi4rymNG0rASBJkqT2a1M/gi2IXidtM0jUC849a24yvySSGykGgBOA7csPJ6s2XJADeA4xE72NDqD8me2a3F+Bz4/6+4eAGzPF0qllaE/t9bdTfrPxYW8gVh1OIxIj51NuT5XZpF2gLqvk2nJE77Q2eAftK1vYNFsDlwErJd7uNuBr5YejHjCTSIi0wY40txfWZJ4geuzdVeZOTYhIkiSpbq8mmoS2RRtmB4/nbuBNRDmSpvpoB7dZglhC/+4S45gGrF3i/lJsQKxeaIuR5GznAAAK+0lEQVS2JG/GepRo0OkM33p9jkiMnAd8J28oHdmDdqxmhHhvfEcF+90IOI5ISA/bDPgL0Q9mVgnHeClpFUxuKeGYAHsSyZg2WIpIeind0sR70RlEg+lUhxIrmKSxdiY9wZbLdJpfnnUit1Jyj0RLZkmSJKluKRdULyN9FUERLwY2Kbjt7sBHgPsriKNqFxNlpg7LHcgEzgfOImZtpphO1P/eDvgAnc/8n0nM/v4Q+RIiKa+Hq4nHq2zrAa8quO32wBrA9RXEUbVriAugP8kdSB+ZR1zEeIRYudYm00hbzfhrqunhsR3FJxEcCHyT8h7rlYkSheOVsloG+DKRnP4kcAydldFahijDVdSjRD+0bk0D9k/Y/lfAP0s47ljbE2WcihguW9i211IuKxNl+t5L/J514kqi7KI0npTvcH8ALq8ghs2JyTVF7E2UJnusgjiqdg5RtvGTZe1w0NG3Yw2a7UbyP0aOPGNzmu1s8j9GjjxjH6TqXUzx38mmXuSezLOJ2T1F7+OLK4rjRQkxDALvKfn4ZyUc+4MlHO+khONNNpYuIZaxNiKarHca03zgeKJfStGSK0sSJ7Gdft88svO7u5DlGLlQXGRU1bTzGcTjWDSOL5d8/KMTjp3aCHc830g43mTjeSXEktuPKX5/P5Ahvr0T4ru+5GNvn3DsucAKJR9/2DsT4hikvN5Rs4BLEo77b+CLxGSDgXH2N57nJx5jkOj/UIYdE445l3IbuY+2Z0Icg8BWFcVRp0Mofn9vA1abYjwd2JCYXLEb8Rn114RjTDTup7r3+c8nxHFuRTFU7WqK38dDM8XYjY1J+32qqgTvtolxlN1P7dKEY3dbXmwaaedQEw5XiEiSJKlOB1D8QslfgIsqiuNi4M/ECXQRBxAXYgcriqdqexKzx9bKHcg4riCSE9/t8PbTiAsguxHlkM4BriVmEN9OXNR75pixYnchl2YvipdruZ0oFVaFG4nZz68puP2etLuEyCHERdtNcweiRkuZ+XsqcGdFcZxI9C8oOsP9IOL13K2jKb6SEuK99UND45ahGG4kLmjfCvyHuA+rEhex35C4/2E/7eA240l5fn9KyfXrR/kR8FWKTzg4iJig1y9WBm7KcNwniHJIV2Y49livIFZG1eXXwOtqPF5bpbyH/A64qqI4fk1MCCg66f0g2rvqaQHxff8K4rOkYyZEJEmSVJfU+uadXiAv6giK17Rfk+h9ckZ14VTqAeLE/mLKqfdetiOA9UkrXzKeJYHXdx9OLaaTdn9/QFygqcp3KZ4QWZY4IS1rpUzd5hH9da4gVulIY61N2kz8Kj+vHiXKUR1ccPvhPl3XdnHM/wF26eL2TyMSvmV7BDi9hP08F9giYfsqn99HiB4tRfuVbUd7yxa2yUFUU6KyE9Oo97vbojUeq62WJxp9F1Xle8gg8D2Klx7ciOgDdUFlEVXrLuKxP48u8ho2VZckSVJd3k40BS3iIeCECmOBKLOU0mC5rc2kh/2FZjeIPxj4be4gCiqjUf0ORKmqIhYQJ7tV+iVps3Db/nq4CXgb7V31pWodSPHVjFcTF2aqlHIxbYC03idjPY/mlq/5HJHg71bKZ+GVxOzuKhWdnAHpvW2U7ktUPylH7bYPxRNHd1LeyraJHEWUny2q7d/hLgA+3M0OTIhIkiSpDgOkXYA4gbRkRSdSky7bED1Q2uwoYqZxEw2Xp7gidyBT+DHwkRL2k3IyegbVlwxZQNqKj/WIMh5tdgZpzZzVH5YkEvhFHVFVIKP8g7SkyzuBxTs81pVE/5SqSkR16p/AV0rYz9LA7gnb1/H8XgX8PmH7PRi/0b268xixsulDuQNRo80A3pWw/dGkJSs6cRdp/ZXeCKxSUSx1+SpdlJI1ISJJkqQ6bAmsk7B9ymzJbqQcp9tZt02xP/D33EFM4G5iGf8PcwcyjoeIi1C7EI1Wu/E84FUJ29c1U/X7pJXlavsMQ4jSQOflDkKN8g4iKVLEcDmrOqS8D6Re9B/rTKLHVlNW7T0G7E05FxVTkkWPAMeWcMwiUp7fZYG3VhVIn7oReCkxcUSazOsp3r9ikHqSqpD2HjID2K+qQGr0DuC6Tm5oQkSS/l979xIiRxWFcfzviG+MmonGV3wQNFmIgoIIQQ0IPpCgCxF8LASjAWcnLuNCUHChuNFAVEQRNAZRhCgiIsSADBqziKv4iJKoGR8kM4Nj5h0XXzfKMLHO6a57b033+UExWdR03Ux1VVffc885IYQQcvBMnA6j8k457MXXuP0h1AtlKfsbuIf0GTidOor6UzwBzBUeS9vXwLXU14TSky31E5qczGEE32q7u1Fz5KVsDrgP/d9D8GYzbgNGE41loffwNW7vtkTir2gxw5OUvRdPoQbsngyK4/EubHib7gPgVu/iy8rphYB0U3wEXIc+60Oo4rn22g3Pc9iJr3H7o8DJicaSyxjKLp/y/mIEREIIIYQQQmqXoyagVrmyQ9o8K6qW4Sul0lT70GrbJnseuB2t2izlR+Bh4Abgu5pe82zUu8LqFVTOKhfP9XAivrIRTTWCMn+aEoAL5dyKrzRizj4DM/hWr3sbhy9mHnga3QN3kL/nzl8ogF9XULjdcN4q5/mdxhd0vwpYn2YofeNzlK15J8pQDaHKNcCNjv1z96LxZKOsBO5NNZCM9qA+hC4REAkhhBBCCKkNYX/uPAxsTziWxWxvHdfK02y3yd4BXio9iAqfosnJIbRaOZcDwCZgDfAavjJSVTzlWrwToHX4DPjWsf8jwKmJxpLTTrQSPvQ3z8rfPcCXqQZyHC/jC5DWlUWwG9iAymhtI0/w8BM06b+jxtf0/D12t7actuILOkWWSGd2oWDhzTSnLFxYGjzX3EHqvX9ZvIEywa165R6yFV9fyAiIhBBCCCGEpE5HfResXke1wnOabB3Xai0qI9ILHge+Kj2ICtPAFmA1Gq+nZIzHMfS3GAKuQBOPMzUfYwBfuZb3gd9qHkMVb73rFSi7ohc8C3xYehChmNUog8Aq98pfUAm9jx37bwAuq/H4e1GJubUoe228xtdu+wb1P7mNejMEr2y9plWJ87sfBYKs7gIuSTSWXjKLgiCbUWmsm1DwPwSP5cD9jv1fJX/m6RgKWltd39p6wSYcJcMiIBJCCCGEEFJ6EDX/tMjZeHChfl2VOY1q73oyZEqZBF5APStuAZ6j++bwE6hnxkbgQvSlcAv1NO5dzB1o0tWqxIQc+AOTvXI9HEMTsSXLtIVyPNmM48BbCcfyfzz3hQHgsQRj+B7Vnx8E1gFPAV/QeTbdn6h5+TrgauDNGsa40BD27M4x1D+khH4sW1iXCRRUGgY+AF5E/WcGURDkGZTZFUInNgKnGfedRQGRErzPjr3yDDeBSixOWHY+Afgh6XBCk61HKVxNtQt9MQ395wH0ENNU7Yf10H82U+7LUegfK4FTjPuOk6+Za6cGsZcHmgN+STiWKhehyQWLeeDnLo51LvYvVUdI3wB9ObZm8QfJX0O+yiq06ncNun7a23no/TcKHGptI//59z5UJsndiLELZ7U2qwOpBmJwPr5mm928N6zvP8hz37Oep0PUn0WUm+ceneNetNAZaIwWs3RXWs/z+TtJumy1KgPAxY79p8iXabYM1de/lH/vw+2f56Dr90hr+x2VpBomz7yU554W5zetM7EvlrGYRws7PKWCSvM+D+R0FPijhte5ADjJuO8oaTLO6rQCZb5bzKBnhFJWYQ8A5/zsPIx6Q6VkOk//AFaCityvIS1JAAAAAElFTkSuQmCC", "companyName": "PT Pangan Masa Depan", "defaultCurrency": "IDR", "fiscalYearStartMonth": 1}	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 15:02:52.282
9211f35c-ec42-473e-8861-6c8970ac779f	57bfda57-46b8-4a94-bdd6-b5653522e4fb	LOGIN	user	57bfda57-46b8-4a94-bdd6-b5653522e4fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 17:19:34.665
3305fedb-eb8c-4fc9-b7ea-d278c6cfadb6	57bfda57-46b8-4a94-bdd6-b5653522e4fb	LOGIN	user	57bfda57-46b8-4a94-bdd6-b5653522e4fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 19:55:11.437
3d60402e-aba9-489c-9b84-09d873c0ceec	57bfda57-46b8-4a94-bdd6-b5653522e4fb	LOGIN	user	57bfda57-46b8-4a94-bdd6-b5653522e4fb	\N	\N	::1	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36	2026-03-16 20:49:45.531
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_settings (id, company_name, address, phone, email, tax_id, logo_url, default_currency, fiscal_year_start_month, slug) FROM stdin;
2106f4c5-b680-4bfb-bc8e-2cff10c2bbf7	PT Pangan Masa Depan	Cirebon, Jawa Barat	\N	\N	\N	data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAABkQAAAGVCAYAAACvs53PAAABgWlDQ1BzUkdCIElFQzYxOTY2LTIuMQAAKJF1kb9LQlEUxz9qYZRhUERDg4Q1aVhB1NKglAXVoAZZLfryR6D2eE8JaQ1ahYKopV9D/QW1Bs1BUBRBNNda1FLyOk8DI/Jczj2f+733HO49F6yRjJLVG3yQzeW1UNDvmo8uuOwv2OnGRjOdMUVXZ8ITEeraxx0WM954zVr1z/1rLcsJXQFLk/CYomp54Unh6bW8avK2cIeSji0Lnwp7NLmg8K2px6v8bHKqyl8ma5FQAKxtwq7UL47/YiWtZYXl5bizmYLycx/zJY5Ebi4ssUe8G50QQfy4mGKcAMMMMCrzMF4G6ZcVdfJ9lfxZViVXkVmliMYKKdLk8YhakOoJiUnREzIyFM3+/+2rnhwarFZ3+KHxyTDeesG+BeWSYXweGkb5CGyPcJGr5a8ewMi76KWa5t4H5wacXda0+A6cb0LXgxrTYhXJJm5NJuH1BFqj0H4NzYvVnv3sc3wPkXX5qivY3YM+Oe9c+gY08mfP56nFPwAAAAlwSFlzAAAuIwAALiMBeKU/dgAAIABJREFUeJzs3XeYHXXZ//H3ppFQAgiE3puIFJEuHaRLV0SKoEgRxAK2x/aAChbgp4+o+NhCBwUFAUWKCCogvUnvSIdQQwpJ9vfHffZhTbacMjPfMzPv13XNtZvsnu98dgO758w93/sGSZKU0tzAecAiqYNIkiRJkiRJkiTlYQLwT6AX+ELiLJIkSZIkSZIkSZlbBXiYKIb0Nt4fkTSRJEmSJEmSJElSht4HvMTbxZC+Y/uUoSRJkiRJkiRJkrKyJzCVOYshvcCFCXNJkiRJkiRJkiRl4uPALAYuhvQCM4Glk6WTJEmSJEmSJEnq0G5EwWOwYkjf8Y1UASVJkiRJkiRJkjqxGYO3yZr9uDVRRkmSJEmSJEmSpLatCbxCc8WQvmPJJEklSZIkSZIkSZLasDzwDK0VQ3qBT6QIK0mSJEmSJEmS1KoJwAO0XgzpBS5MkFeSJEmSJEmSJKklo4HraK8Y0gtMBsYWnlqSJEmSJEmSJKkF36L9YkjfsV3hqSVJkiRJkiRJkpq0OTCLzgsiJxUdXJIkSZIkSZIkqRnvAJ6k82JIL/CXgrNLkiRJkiRJkiQNqwe4gGyKIb3AS401JUmSJEmSJEmSusbBZFcM6TuWLvQrkCRJkiRJkiRJGsKqwGSyL4jsXOQXIUmSJEmSVGUjUgeQJKkCfgjMncO6a+ewpiRJkiRJkiRJUsu2I/udIX3H+QV+HZIkSZIkSZIkSQMaCdxJfgWRe4v7UiRJkiRJkiRJkgb2cfIrhvQCk4r7UiRJkiRJkiRJkuY0L/A0+RZEeoFRRX1BkiRJkiRJVeZQdUmS2nMMsHgB51mogHNIkiRJkiRJkiTNYQlgMvnvDukFVi/oa5IkSZIkSao0d4hIktS6I4G5CzrXIgWdR5IkSZIkqdIsiEiS1Jq5gIMLPN/CBZ5LkiRJkiSpsiyISJLUmj0pdteGBRFJkiRJkqQMWBCRJKk1hxd8vt6CzydJkiRJklRJFkQkSWremsAmBZ9zasHnkyRJkiRJqiQLIpIkNa/o3SFgQUSSJEmSJCkTFkQkSWrOeGC/BOe1ICJJkiRJkpQBCyKSJDVnb2DeBOedkuCckiRJkiRJlWNBRJKk5uyU6LzuEJEkSZIkScqABRFJkoY3Btg60bktiEiSJEmSJGXAgogkScPbiDTtssCWWZIkSZIkSZmwICJJ0vC2T3ju1xKeW5IkSZIkSZIk1chtQG+CYwrevCBJkiRJkiRJUu2tV8A5FiNNMaQXuL2Ar0+SJEmSJKkWvOtUklRGPcDXgb8Bi+Z8rm1zXn8o9yc8tyRJkiRJUqVYEJEklU0PcBJwLDAXcETO59sq5/WHcl/Cc0uSJEmSJEmSpERGAr/kP9tKvQjMneM5byRNu6xe4CM5fl2SJEmSJEmSJKkLjQF+w8CFg8NyOmcP8Nog5yziWCenr0uSJEmSJEmSJHWhuYE/MXjh4AHyaQO5+BDnLOKYN4evSZIkSZIkSZIkdaGRwMUMXzzYNYdzb9nEefM6Hs/h65EkSZIkSaoth6pLkrrd94Gdm/i8g3I49ztzWLNZf0l4bkmSJEmSJEmSVKBDaX5HxVRgfMbn/0EL58/62Dvjr0WSJEmSJEmSJHWh9wMzaK2IsG/GGS5r8fxZHTOBhTL+WiRJkiRJkiRJUpdZDXiF1gsJF2ac45E2MmRx3JDx1yFJkiRJkiRJkrrMwsDDtFdIyLpt1ktt5uj0+O8MvwZJkiRJkiRJktRleoA/01kxIcu2WW92mKXdY8MMvwZJkiRJkiRJktRlDqbzYsLvM8rSA8zKIE+rxyRgZEZfgyRJkiRJkiRJ6jLLAK/ReUHhRaKY0akxGWRp5zg7g+ySJEmSJEmSJKkL9QCXk11RYZUMMs2fYZ5Wji0zyC5JkiRJkiRJkrrQJ8i2qHBABpkWzThTM8e9ZLO7RZIkSZIkSbMZkTqAJKn2lgFOynjNjTJYY2wGa7Tqp0RhRJIkSZIkSRkblTqAJKnWeoCfA/NlvG4ZCyJvAqcXfM7BjANWAN4BLDjIMTcwGXgdeKPxtv/7LwH3AU9jkUeSJEmSJHUBCyKSpJR2BLbNYd01iCLL6x2sUXTrqrOAVwo+Zw+wGLAWsHbj7VrAqmS3i/Q14J7G8a9+7z+JhRJJkiRJkiRJUg30ALfQvcPJF84x20DHezrM26yVgWOIIfbP5/w1DXW8CJwN7A9MyPUrliRJkiRJkiQpod3J94L7wR3mGwnMyjlj33F9h1mHMgLYADie2JmRqgAy1DELuAk4jmh3NjKX74QkSZIkSZIkSQUbAdxFvhfZj80g5ws5Z+w7dssga38jgO2AU3l7hkeZjhvIrmWXJEmSJEmSJEnJ7E3+F9V/nUHOewvIeQ3ZzSuZB/gk8GABufM6ZgAbZvT9kCRJkiRJkiQpmZEUU2i4KoOs1xaQc90Mci5BtMSaVEDevI8sdvZIkiRJkiRJkpTcfhRzYf2BDLL+LueMZ3aYb23gdGB6zjmLOm4ERnf4PZEkSZIkSZIkqSvcTjEX16fQeSuqn+aYbyqwTJu5VgIuyTFbiuNNYNU2vx+SJEmSJEmSJHWVtSj2IvuEDvMemWO2E9rIMzfwTWBajrlSHYe38f2QJEmSJEmSJKkrnUyxF9lX6jDvJjnlegGYv4UcPcCuwGM55Ul9nEZ2g+UlSZIkSZIkSUpqNPA8xV5oX7nDzONzyrV/CxlWAi7NKUc3HFcDY1r4fkiSJEmSJLVlVOoAkqTa2B5YJHWIFr0GPAKskOGaZ9PcMPVRwFeBL1PdgsH9wB7EUHjBKkQRTsWYDkwG3mi8fROYlTSRpOEsCiydOkSX+DfwbOoQSm5tvK4DMIl4zi7lZTTR/ln56iWem7/eOCbj83PlwF+ckqSifDTBObNow3Q72RVEHgM+STzRG8oSwLnAphmdtxu9AOwIvJw6SBf5MbBN6hA19ybxIqyvSDL720nAQ8ADwIPA48CMJEmletob+GHqEF3iEuADqUMoqdWA21KH6BJnAfulDqFKWwi4KXWIGuolnoO/3uIxCXgUeAJvvtMARgF7pg6hZC4jfrB0qx2IAcKqn2uJi6WqjoWAXVKHaNMdxC6GTs0EPgK8OsznbUkUQzodCN/NphEzUbyTT91m7sbR7P9/bxH/HfcVSPrePgg8hXe0ScrPjsAyxMUe1dMhqQNIUs56gHkbx+JtPH4WsaPyUeI5+yP93r8Pb86rrVHA+alDKJkViB8E3epU4km+6mdL4K+pQyhTexPbjIuWxQ6RrO68Oxa4foiPjwC+BHyz8X5VvQXsw9DfC6ksRgOrNo7ZTSHawl0DXNF4+0Zx0SRV3AjgYODrqYMoiXGk2X0tSWUygriuuAyw+QAff5x4vd//eIrhOzqo5GyZJUkqwraJzptFQeQa4iJ+JwWdvwHHD/HxdwBnEHd7VtlUYrfNn1IHkQowjujtvjbwaaK11vVEceRKou2C7bYkdeJg4kaKt1IHUeH2BBZMHUKSSm7ZxrFbv797kWibfTNxo+4/8KamyqnyHaiSpO4wgnLPwniNaOPWrpeJnsYzB/n4ssA/qX4x5HVgOyyGqL5GET8LjwOuA14CLgSOIHaYZFHAlVQvi+Mckbo6NHUASaqohYm5jl8iRg28TDx3/3bj723tXwEWRCRJeVud2AGRQlb9+y9t83FTgJ2J/t4D/c5dFfg7sFKb65fFJGBrOissSVUznpilcwrRw/gx4k7vpRNmklQ+h6UOoMKtDmySOoQk1cQoYCPgv4id3i8Tr2u/DqyBNzWVkgURSVLeNkt47mcyWueSNh4zE/gQcTfJ/MTcpv7WIp5ILdVZtK73LNGv9abUQaQutwzwVaIw8nvg/fhcXdLw3g+smDqECuUwdUlKZwyx6/tY4E7gAeC7wAb43L00/IeSJOUtVUHkZaJNUxYebBytOJgopMxLtMx6qN/HNiT6kU7IIlwXu5u4g/Hu1EGkEhlB9DG+nNg58lnsEy9paF4gr49xwAGpQ0iS/s9KwBeAG4gh7f8DbAGMTJhJw7AgIknKUw/pCiKPZ7xeK7tEvghMJF60/hg4u9/HtiIGKi+QWbLudDpxl8zDqYNIJbYycDLwFPBL4L1p40jqUh8D5kodQoX4INV/DilJZbUU8CngaqJt9jeB5VIG0sAsiEiSNie/nQorA4vltPZwnsh4vYua/Lz/B3yfuDBxAVEYeLnxsfWJwso8GWfrJtOIO1UPBN5MG0WqjHHEBc+bgX8C26aNI6nLLAzskTqECuEwdUkqhyWIdriPAH8G9iLabakLWBCRpHrbmfjlfERO62+a07rNyHqHyLVEf9ChnA4cQwxe+w1wP3BV42PLAxcTFzar6hFi4NzPgd7EWaSqWp/4uX0Rzg2Q9DaHq1ffu4GNU4eQJLWkh7iZ6bfAk8D3iBtHlZAFEUmqr32Iwb1zAZ8knwv1q+awZrOy3iHSC5w6xMe/DxxE/G49i7hQ+eXGxxYALqXaM0MuJNr53JY6iFQTuwD3AMcTs4ok1dtmwGqpQyhXzoqRpHKbAHyeuNHy98B6aePUlwURSaqnQ4mL9qMaf16YfAY0LpvDms3KeocIwGnA1Nn+bhZwJDFIDeBXxEDkfRufO4ZonVXVixRPEG069gBeSZxFqpsxROH1fuJnTk/aOJISs51Sdc2Nw9QlqUp2A24k5otuhc/jC2VBRJLq5wvETofZf+F+jux/LyyT8XqtyHqHCMAk4Lx+f54C7E4MTh8B/AzYn+gVegfxPT6VeIJTNW8Rd6a/i7i7xRZZUjpLAGcCf8fB61KdfZS4cK7q+RAwf+oQkqTMbU202b4B2BWv1RfCb7Ik1UcP8G3gu4N8fBVipkiWUu0QmQHcldPaP228fQHYAvgD8b39IXAw8DfgpMbnfI5oo1U1lxN9rL8CTE6cRdLbNgZuIub4eOFMqp8FiAvnqh53/0hSta1PtKG+kyiMuGMkRxZEJKk+Pgv81zCf87kMzzcXsHiG67XiJuDNnNa+ETgX2LDxfg8xGO1I4HWincFM4D3ACTllSOVJYE9ge4YfMC8pjR6iOHsjsYNLUr04XL161iSed0qSqm91ojDyF2CdxFkqy4KIJNXDLsCJTXze5mS3q2OpjNZpx7U5rt0LfAR4pPHnY4FjGu8fCTwGjCXa14zOMUeRniSGv60G/A7bY0llsArwT6KIKak+NgDWTh1CmXKYuiTVzxbAzcQc05TXVirJgogkVd/awNk0v+Vyr4zOm3Kgep4FEXi7IPBl4GuN988Hzmi8fwLVuDP7ZmAfYEWioGZ7LKlc5iV+Nn0HGJk4i6Ti2F6pOuYh5tNJkuqnh+hA8QDwTWC+tHGqw4KIJFXbEsAlxIupZmXVezpVQWQW8I8CzvNZYqg4wDNEi4peYijaZwo4f156iS26mxJ9TM8lBqhLKq8vApcBC6UOIqkQ++FFk6rYGxifOoQkKalxwFeJwoi7vzNgQUSSqmtu4CJgyRYftz7ZFDMWyGCNdtwOvJrzOQ4HTu7354OAl4AFgYk5nzsvzwGnEG12dgf+jq2xpCrZBrgFexFLdTAv0d5T5We7LElSn8WI3d/nN95XmyyISFI1jSDaN63b5uOzapuVQt7tsg4CftLvz6cAf268P67x52uAGTnnyML9wHeBjYndRJ8CHkqaSFKeliV20Nl+Raq+w2m+Xaq601rETBhJkvrbE7gHOBB/17fFgogkVdOngD06eHwWbbNS7S7IsyDyEeCX/f58H9GKps/TRIFhC6I1zZ7AL4CncszUil7gOiLzasA7gS8B1xOtxiRV31jgdOIFlKTqWovY9avychaMJGkwCwK/Bv5E2vmtpTQqdQBJUuZWJoZ6d2J9YCng3x2skaIgMhm4Iqe19yQuIvbdgTED2Bd4c5DPfw34XePoAVYHtgLeTQxcX51824rNBO4F7mgctwO3AS/meE5J5fFLor3g71MHkZSbQ4F/pg6htsxLzIKRJGko2wH/Aj4N/ArbXjfFgogkVcsI4pfguAzWeh9wXgbrFOl84I0c1t0ZOAcY2e/vvgHc2uTje4G7G0efHmBRojDyrsaxIjEEdT7ihXDf2zGzrTcNeHmA4wXgLqL4cU/j8yRpICOAc4EdgasSZ5GUjw8DRxPPEVQuexPPAyVJGs48RGeKzYmWmZPTxul+FkQkqVo+BWyS0Vob0VlBJMWdCaflsOb7gQuA0f3+7jrgex2u2ws82ziGuxg5hiiMzAW8Akzp8NySBPGz5SJga7yLXKqiccTMoP9JHUQts12WJKlV+xNzZD9I7BrRIJwhIknVkUWrrP427PDxRRdEHieGmWdpc+JiYf8dGm8QTzSKHJo+HZgEPIPFEEnZmofoPfzu1EEk5eIwHLhaNu8B1ksdQpJUSqsBN+G8wCFZEJGkasiyVVafdYjhu2VxOtkOBt8IuIQ5v6efBh7J8DySlNqCwOXACqmDSMrcasCmqUOoJe4OkSR1YhwxcP3XwNyJs3QlCyKSVA1Hkl2rrD6jiaJIu2ZmFaRJp2e41nuBy4g2Vf1dSDypkKSqWRy4svFWUrV4gb085gX2TR1CklQJBxJdNBZNnKPrWBCRpPIbTwz4zsNGHTz22cxSDO/vwEMZrbUmcaf0+Nn+/jngENLMRpGkIixPFJdtryNVy17AIqlDqCn7MOcNOZIktWtd4AbgnamDdBMLIpJUfp8B3pHT2ut38NgnM0sxvF9ltM5qxB3SA30/Pw68kNF5JKlbbUPMHJBUHWOwl3hZuJtHkpS15YDrgM0S5+gaFkQkqdzeARyd4/rLd/DYJzJLMbRHgTMzWGcl4CoGvoPy+8ClGZxDksrg+8CKqUNIytSh+Pq/2723cUiSlLUFgSuAD6cO0g18QiRJ5XY0c7Z2ytIyHTz2BWB6VkGGcBzwVodrLEsUQwbqnX8V8F8dri9JZTIPMS/J1wpSdawIbJ06hIZ0SOoAkqRKGwOcA3yJmrfI9UWOJJXXIsCncz7HosBcbT52FvDvDLMM5AE63x2yHHA1Axd/HifuoJjR4TkkqWw2Jf/fMZKKZTum7jUf8JHUISRJtXAC8N+pQ6RkQUSSyusLxF28eVuqg8fm3TbrWDorVqxKDGQfqDXYVGB34MUO1pekMjue+DkpqRp2A5ZIHUID+ggOU5ckFefrwDdSh0jFgogkldNiwBEFnWvpDh6b52D1e4DzOnj8msC1wJKDfPwQ4LYO1pekshsLnAaMSh1EUiZGAh9LHUJz6MHdO5Kk4v03URipHQsiklROBwPjCjpXJ3NE7sosxZy+Acxs87HrA38FJgzy8R8BZ7S5tiRVyQbAMalDSMrMIURhRN3jvcB7UoeQJNXSscDXUocomgURSSqfHuCjBZ6vkx0i12eW4j/dDvyuzcduTgxKX3CQj/+NGFafSg8xt2V+omCzNLASsDrxYnkFoqVCrYegSSrUV4B3pA4hKRNLAzukDqH/4O4QSVJKxxHP92vD7e+SVD4bExfIi9LJnJJbiBkfWf6+mQl8ghja3qodiELK2EE+/hTwQeCt9qI1pQdYBFi537FK4+2KNN8/egrwPPBc423f+3cDNwMP0d73SJJmNy9wFDUfvihVyKHAJalDCIDxwD6pQ0iSau9bwKvAKamDFMGCiCSVT5G7Q6CznQhTiDkc62WUBeB7xAX/Vu0JnAOMHuTj0xuf81ybuQYzF7AR8H5gS+BdxO6PTo0Dlm0cA3mVKEjd3DhuAh4HejM4t6T6OQo4CXg9dRBJHduJeP7weOogYl86u/lIkqSs/BB4FLg0dZC8WRCRpHIZB+ydOkSLbiC7gsi/iB6XrdofmMjQrSKPAP7Zxtqz6wHeTRRAtiFadM2dwbqtmh/YqnH0eYG4I/R8om3YtAS5JJXTgsDhRFFaUrn1EPPoatczvMs4TF2S1E1GAOcCmxJtyivLGSKSVC67EVvri9TprIqs5ojMBA6k9Yv4hwGnM/TvvP8FftFeLCC+RxsBvwSeBu4k7qTegTTFkMEsAhxE3PHxPDE4fjei0CZJw/kc/ryQquJgBt81q2KsB6yVOoQkSf3MS9xEuWTqIHmyICJJ5VJ0uyzonoLId2m9VdYxwE+H+ZwbiFYw7ZgfOBK4A7gO+BiwWJtrFW08sB/we2LnyHnAokkTSep2ixI/5ySV32LALqlD1Jy7QyRJ3WhJ4GKan29aOhZEJKk8FiPaMJXN48D9Ha7xL+C4Fj6/hxj++/1hPu85YC9a23XSA2wA/Ap4BvgRsEYLj+9G8xAD2J9PHURS1/sC3lUuVYUX5NOZH/hw6hCSJA3iPcQM1pGpg+TBgogklccWpPm53ekOkV7gtx08fhqxM6bZokUPcCLwjWE+bwZRDHmqyXVHELNIbiN2lRxEdVrHPAAcggPXJQ1vGWJ3maTyez+wUuoQNbUv3dVWVZKk2e0MfCl1iDxYEJGk8tgsdYAOdFIQ+ShwS5OfO4JokfW5Jj73s8Dfm1x3m0aG06ler+epwAeB11MHkVQaX6TzYrmk7nBI6gA15DB1SVJZHEcMWa+UUakDSJKalqogMiODNe4idiGs0uLjvk7MtmjGKODXNHfn8unAj5v4vDWA7wHbN5mhjD5FDIGX8vYScHyic/cA8wELDHIsBsyVKFsZrQqsTeyYk1RuHwO+RmvtQ9WZDYA1U4eQJKkJI4Czief+LyXOkhkLIpKUjX2J4eGP5LT+wsDqOa09nH9nsEYv8Bvgqy085izgW01+7lxEf8vdm/jcW4HDGLo91JLEnRAHUu3dlGcAv0wdQrXxMnBy6hCDGE1cnNqQuFC1IbBy0kTdbw8siEhVsBCwJ3GxQ8Vwd4gkqUyWAiYCu1CRNttVvsgjSUUYQdzxfCbR2ikvKbcoPp7ROq20zboOOJjmftnODVxEc8WQF4mLeFMG+fhcwLHAg8Qdk1X+PXkjcDgVeUIjdegtoi3ej4EDiN1sCxN9c38DzEwXrWvtkTqApMwcljpAjSwA7J06hCRJLdoZ+HTqEFlxh4gktW8+4g77XRt//ihxMX1WDudKOT/kiYzWuQu4D3jnMJ/3GFHcmNrEmuOBS2iuYDSLeAE6WIFndWJXStVmhAzkHmBHYHLqIFIXewm4tHEsRRQQDyXupha8i/h5fl/qIJI6tinx//Q9qYPUwH7AuNQhJGkQz1Ps6+ERwFji52L/o+/vxgNLAEsTz8f73o4vMKPe9j1iDuvNqYNkodejtsfydLfHSf898khzbEH3W46YuzB79q1yOt8tA5yrqCPLJxtHDnOul2i+Ndg7iF0OzX4dRw+yTg8xR2NKC2uV+XiUaAmm7nMF6f/7yPN4MLtvVTLjiN1jD5D++9kNx5c7+3ZKLTuK9P/dV/X4YQv/DmpPD3GDUOp/6yoeZ7bw7yC1YzHS/3dexPF0Vt+wnI0nrhvsRXTs+DPRDSL1968Ox13AmOH/ibpf6m+kR7rDgohHtx5b0N02BV5g4Oxn5HC+eYl2LSn+LV7J+GuZB5g0yLmeBt7d5DqLMnBBarDjHOJF6OwWA/7UwjplP54FVmrye6ziWRApj3mAX5H+e5r6uKnTb6TUIgsi+R2vEG1IlZ+NSf/vXNXDgojyZkGk+/UQO0h2A74JXAPMIP33tIrHV5r8N+laVe6NLkl5+BBwFdFbfiB7kv32zeVJ9/M6q/khfSYDpw7w948Shaa7m1hjaeBvwBpNnvMuBp5HskvjY9s3uU7ZvQJsCzyUOohUAZOJnSIHUO/Wc+sCy6QOISkT8+Nsi7wdkjqAJFVYL/AkcCHwNWBzYBFgH6I19qR00Srna8TMxdKyICJJzduV+EU6eojPGUcUTbK0bMbrtSKr+SH9/YgYYNznXqIY8nATj12JKIas3OS5XiHmkfS/YNkDfIkYxD5YYatqXiFmhtyZOohUMWcA76Xe/2/tnjqApMw4XD0/C2LBSZKK9jJwLjG/aQKwCfBdonOC2jcX8DMG7sJRChZEJKk52wG/AUY18bk7Z3zulHffZr1DBOAZorAEMRtlM+CpJh73LuBami8QzSCKU/0LLaOAnwAnNLlGFTxOtGi4PnUQqaLuJ/4fuz11kET2TB1AUmbWB96TOkRF7U8MCZYkpTET+Adxc+QyxPyRK5MmKrctgINSh2iXBRFJGt4WxLbLZgdHbUlzhZNmpdwhcmNO655E9PTcihh+Npx1iGLI4i2c40BiJkOfeYl/xzrd/XgLsCGxC0dSfiYTuwifSx0kgY2oyGBFSQAcmjpABfXg91WSuslbwAXA+4nWTydhS612nEjMdy0dCyKSNLSNgEto7Y6u8UQLlayk3CFyTU7r3k08+Xitic/dGLgaWKiF9Y/h7V0oEEPw/grs1MIaZXcpUcxzO7BUjCeI9lHTUwcp2CjgnalDSMrMvsB8qUNUzMbETmdJUvd5kLh+sBTweaLNlpqzINGCrHQsiEjS4NYB/gTM08Zjt8kwR6odIk+QT8usPm8N/ylsTezyaGVQ/cnEHR59VgZuINsiVbc7FdgNeCN1EKlmrgc+kTpEAmulDiApM/MSRRFlx90hktT9phA7HlYAvtP4s4Z3ALBG6hCtsiAiSQNbCrgMmL/Nx2dZEEm1Q+TaROft82Hgj8DcLTzmbOKujj5LEQWVlG3HijQVOAL4JDFDRVLxTm8cdbJm6gCSMnUYJR6U2mXeQcy0kySVwyvAl4GVgP8lZo9ocD2UcEarBRFJmtNo4DxgkQ7W2JjWLuQPlWWJDNZpR6qCSA8x6OwcWutLfyUx1GtW488LA5dTn2LIbcSupp8AvYmzSHV3HPV68WRBRKqWtYgB6+rcAcBcqUNIklr2NLHDb23g9sRZut1OwOapQ7TCgogkzek7REGjE2OA92WQZW7S3aGXoiAyimj31OodBrcCe/B27/75iHZnq2UXrWv1At/D4elSN3kYOCN1iAJZEJGq57DUASqgBzgkdQhJUkfuBjYAvs3bN19Ul1GhAAAgAElEQVRqTt+lRLtLLYhI0n/aHfhcRmuV+QLRc8ADBZ9zPuBiWn/h+AiwI/B6489jgYuAdbOL1rX+DWwFfJH6DXKWut23qc8ukcWACalDSMrUh4lhqWrfJtTj5hxJqrrpwFeJm14fSpylW21AXE8rBQsikvS2FYBfZ7jeOzNYI1Xro2sLPvcSjXNu3+Ljnge2Iwo4ACOJVltbZhetK80CfkEU3f6aNoqkQTwEnJk6RIHKfBOApDmNJdo9qX0OU5ekarmBaKF1auogXeoEou1717MgIklhLHA+7Q9RH0gWBZFUflPgudYA/kk8sWjFZGJnSP87NL4B7JZRrm71J6K39yeAlxNnkTS0H6UOUCALIlL1OFy9fQsBe6UOIUnK3GTgcOCT2EJrdqtQkt99FkQkKZwIvCfjNbPYIp9ih8jLROuqImwD/B1YqsXHzSBmhtzS7++2JbaxVtVtxPdrR6KPqaTudxv1KVyulTqApMy9E9g0dYiS+igOU5ekKvspsAtRINHbjqEEN1NYEJEkWJ+o7mdtIWDhHNbN2znAtALOcyCx22F8m4+9vN+flwTOogS/eNvwBLA/MRPlqsRZJLVmFnB16hAFabWwLakcHK7eOoepS1I9XApsDjybOkgXWYf4nnQ1CyKS6m4E8GPyu5DeadusFDtETst5/R7gWGJey6g2Hn8MUfzoMwo4l3IWn4byJPAFYFViDoHbcaVy+kvqAAXJsuWkpO6xFzAhdYiS2Yx4/iZJqr5bgA2Be1IH6SJHpw4wHAsikuruY8Sd93kpW0HkPuCmHNcfA0wEvt7m408GTprt774FbNJBpm4yC7gE+ACwPPB9YGrSRJI6ZUFEUpmNJnbmqnkOU5ekenkc2AJ4IHGObrEz2bSQz40FEUl19g7gOzmfo9M76mZkkqJ5E8mvCLMA0SLrgDYffzbw+dn+bl5gRWBKB7m6wVPAccByRDHkEmBmykCSMnMf9dhGb0FEqq5D8dpBsxYG9kwdQpJUuBeA7YCnUwfpEp9NHWAoPqmRVGfHEXM+8jRfh4+fBkzKIkgTZhGtmfKwLDE8fas2H38lcBBzto16A/ggsEjj7bmNvyuDycAfgF2JQsg3iDZZkqqlF/hX6hAFsCAiVdcKwNapQ5TER4kd0ZKk+nmMKIq8nDhHNziALm65aUFEUl2tDRxewHnaGRg+uycyWKMZfyR2KmRtHeAGYPU2H38rsAcwfYjPmQycD+xDFEd2Bc4AXmnznHmYBfyTaPG1BbFDaVeiKFL0TiBJxXopdYACjAHGpg4hKTcOVx+ew9QlSXcTLaPK3sWiU3MB+6cOMZh2htlKUhX8gGKKwp3uEIHYNbB2BusM59gc1twJOA+Yp83HPwLsCLzewmOmEkWGPxD/xqsQc2LWBdYD3gOMazNPK2YCDwFXA1c03nqniFRPL6YOUJD5ce6RVFW7AktgK5ChbEE875Qk1dt1RAeLi4lieV0dwJwzYLuCBRFJdbQRsHlB58qiIFLEDpGLgJszXvNw4BTaLzz19eB8roMMs4j+/ffxdjuwUcSAr/WANYFFia2cExrvL0zzT1p6iQFqDzaOB/q9/xjwVgfZJVVHHXaIQOyK7ORntqTuNRL4OPDN1EG6mMPUJUl9LgWOB76SOkhCawJrAXekDjI7CyKS6qjI4U5ZtMwqYq7E1zNcawQxrH72AeitmEzsDHkok0T/aQZwV+MYyEhitswEYEGiqDGNuOt52mzHFGx3JWl4dSmIOEdEqrZPEBd3ZqYO0oUWIVq8SpLU51hiBteGqYMk9FHgc6lDzM6CiKS6WQ7Ys8DzlWGHyG+BOzNaayxwGvChDtaYQbygzHrHSrNmAs83DknKQp1aZkmqrqWBHYBLUgfpQgcCo1OHkCR1lbeAjwC3k83NsmW0L/AFuuxGUoeqS6qboyj2Z9/IDNbIsyAyC/hGRmstBFxJZ8UQgIOAyzuPI0ld49XUAQrS7rwoSeXhcPU5jcBh6pKkgT1KvVsqTgC2TR1idhZEJNXJ/MDBBZ8zi4tgdxGzKvJwNnBvBuusCFwPvK/DdY7m7VkfklQVWewWLIM3UweQlLsdgWVTh+gyWwIrpQ4hSepa5wITU4dI6IDUAWZnQURSnXyc4i9KvZLBGq8Bd2ewzuzeAo7LYJ0NgRuAlTtc5/PAyZ3HkaSus3DqAAWpy04Yqc56iFkiepu7QyRJwzmGbK4PldEuwLjUIfqzICKpLkYBn05w3qwuDl2f0Tr9/TfwYIdr7AFcTecX+z4LnNjhGpLUrRZKHaAgdX2RJ9XNx3FeRp8JwO6pQ0iSut5LwDdTh0hkHLBF6hD9WRCRVBdbAcskOG9WF4eyLojcAnyvg8f3EEWM84lB6p04EvhBh2tIUjerS0HEHSJSPSxG3O2pmH1ncUiS1IxTgIdSh0hkx9QB+rMgIqkudk103qwuDt2Q0ToA04EDgRltPn4k8EOivVVPh1kOB37c4RqS1O1smSWpahyu7jB1SVJrpgNfSB0ikZ3o/PpRZiyISKqDEaQriGS1Q+QB4OWM1jqW9meSLAhcDHyqwwy9RP/pUztcR5LKoA47RKYC01KHkFSYbeh8flzZbQWskDqEJKlULgSuSR0igeWBVVOH6GNBRFIdvBdYMtG5syqIzCKbtlmdtMpaA7gJ2KHDDL3Ax4BfdLiOJJXFKqkDFMD5IVL91H13xKGpA0iSSqcX+GLqEInslDpAHwsikuog1e4QyPYC0aUdPr6TVll7E227VuwwwyzgAGBih+tIUlksDyybOkQBbJcl1c9BdD5LrqwWA3ZLHUKSVEr/JNu26GXRNXNELIhIqoOUL1buz3Ct3xF3E7Tri7TeKmsU8H3gXGDuDs4NMBPYDzizw3UkqUy2Sh2gIO4QkepnIWCP1CESOYh4nixJUjt+lDpAApsB86YOARZEJFXfSsDqic49FXgww/WeBa5t87E/Jwaht2Jh4DLgmDbP2d9MYB/gnAzWkqQyqUtB5MXUASQlUcfh6iOIWXiSJLXrfOIaT52MAtZNHQIsiEiqvpTtsu6mvfZUQ/ltG4+5CjiC1naXrEPMG9m6jfPNbgbwIdrLLkll1kN9CiJ3pQ4gKYlNSXfzUSrbEO0QJUlq13Tg1NQhEtgwdQBwi6ek6tsk4bnvyGHNC4itlT1Nfv79wAeBt1o4xwHAz8imJ/RbjfNflMFazegB5gcWASY03i5CFIOmNo4pA7x9CnitoIyS6mM1os98HeTxO09SORwKHJU6RIEcpi5JysLPgK8Ao1MHKZAFEUkqwFoJz53HxaG+tlmbN/G5k4CdgZebXHs0cDJwZHvR5jAd2BO4JKP1+lscWI/YbrkOsCRvF0DafTLxLPDAAMcjwLQO80qqpzq1krEgItXXAcCXgDdTBynA4qTdgS5Jqo5ngQuJm0jrYkPiRtZO5uN2zIKIpCobT9rt7HldHDqX4QsibwG7Aw81ueZiwG+ItgdZmEYMs78sg7UW4u3iR9/bJTJYd3aLNY7NZvv7mcDNwJXAFcD1RLFHkoayBHBI6hAFyXpmlqRymR/YG/h16iAFOAgYmTqEJKkyfk+9CiKLAssCj6UMYUFEUpWtmfj8d+a07pnACcACg3x8FvFirdkB7BsSrbiyKjJMBXYhigftmgDsQcwe2Zy0M69GAhs0jq8Qdz9eQ3x9VxKzYpLe3SCpK30RmCt1iILkMTNLUrkcRvULIg5TlyRl7Y/EDa11a5v1WMoADlWXVGUpCyKPA6/ktPYbDD586y2iiHBWk2sdQhROsiqGvAnsRHvFkAnEi+m/AM8APwW2pPt+V80N7EC0F7sT+DdwPLBCylCSusri1Gd3CNguSxKsT7QxrbJtgeVSh5AkVcqrwF9ThyhY8jki3XaRSZKylHJ+yNU5r/8j5hyUPgX4ALHbYzhzAT8nhnhldSfCZGBHoqDRrLHAx+n+IshQlgC+DDxM7Bj5EPW5K1zSwL5E/HyrCwsikqD6w8ar/vVJktK4MHWAgq2bOkCZLjhJUqtSFkQuynn9p4Gz+/35NeKutT838diliJZPB2eY5w1g+8a6zZgPOIYYWP4LylcEGczWwHnErpETgVXTxpGUwA7AkalDFOz21AGkCnk1dYAO7EvM8KuiJYgbj8rK9q6S1L3+kDpAwVZJHaAKF58kaSAjgTUSnXsKcHkB5zmp8fZFYAvg7008ZjPgFmIeRlb6ijHNnH9h4Diipdj3ibYyVbQwcDRwCg7elOpkNeBc6vccO6+ZWVIdnZc6QAfmAT6SOkROPkZ5n9NdT9y8JEnqTv8mrtPUxSLAgikD1O3FmqT6WJSY9ZDC5cQsjbzdBfwS2BS4bZjP7QGOAq4iZnVk5VXg/cQLraEsBfw/ohDyNRL/8ivIPcAHgZmpg0gqxELAxVT37ujB3Ei572iXus1ZwIzUITpwGPG8s0pGUu5h6qelDiBJGta1qQMULGk3DQsikqpqgYTnzrtdVn+fAO4b5nPGES+EfgiMyvDcLxMtom4c4nPGAz8gWmN9hnRFqqK9AOwMvJI6iKRCjAZ+A6yYOkgCzcytktS854E/pg7RgbXIdidyN9gOWCZ1iDZNo9y7jiSpLm5KHaBgSdtmWRCRVFWpCiKzgEsKPN9w/YCXA/4B7J/xeScRxZDBtnX2AHsB9wKfJrvB7WUwFdgFeDR1EEmFWBS4FNgqdZBEfp86gFRBE1MH6NBhqQNk7JDUATpwId6gI0llULeCiDtEJCkH8yc67z+I3QHdYBvgZuA9Ga/7GLAJg7fpWp4oCv2WGEBZNwcAN6QOIakQWwN3EK0D6+gu4MHUIaQKuhR4KXWIDuxNddqjLkns+i2riakDSJKa8jDRhaMuLIhIUg5S7RC5MNF5++sBPg/8mehpn6WbgY2InR+zGwN8CfgXsGPG5y2Lo4lCkKRqGwUcB1xB7BCpK9tlSfmYTswSKauxxA0iVfBxyjtM/Rni95Qkqfv1Etdb6sKWWZKUgxQ7RKYCZyQ4b3/zAucC3yP7n/EXA1sAzw7wsRWIXREnEDNL6uhI4OTUISTlqgfYFrgG+BrVGxzcqt+lDiBVWNkHYVdhuPpI4ODUITpwBjAzdQhJUtPq1DZruZQntyAiqapS7BA5nbTtslYCrgc+lMPapwC7A5MH+NgHgFvJvjVXWcwCDgJ+nDqIpNzMCxwO3EPsvts4bZyu8BBwd+oQUoXdRrSlK6t3ApulDtGh7YGlU4foQNmLapJUN3XaITIfCXdgWhCRVFUpdoj8IME5++xC/PJ8dw5rHw0cxZx3mI0Evg38gXQzW1KbAXwY+zNLVTQSWAs4Cfg38BPiAp/CBcTWfkn56KX8zy/KPlz90NQBOnATUcSXJJVH3WbzzZfqxKNSnViScja+4PP9kYHnauRtHHAi8Mkc1p4G7AecP8DHJgBnEwOF62oasBcxQF5S+S0GbNA4NgTWI3aGaGC2y5LydxbRBrWsMyz2JJ4zPp86SBuWBnZKHaID7g6RpPJ5InWAgs0PvJLixBZEJFXV9ILPl2J2xBrAOcDqOaz9ErHr5LoBPrYOsStkyRzOWxYvEK3J/po4h1Qm85FPS79m9BAF5AWABRtH//eXApZNlK2MbqFePY6lVJ4jbrr5QOogbRoNHEgUdcrm45S3o8Z0YqagJKlcXgNepT4dOIq+kfn/WBCRVFWvF3iuO4C/FHi+HuAIYmfIXDms/xCwIwNv13wf8cI82S+uLtA3p+XfqYNIJbMocF7qEMrECdguSyrKRMpbEIFoO3UiMXOtLEYRBZGyupi4uUmSVD5PEDe/1kGywk9Z73iQpOG8VuC5Tqa4C0MLAxcBPyKfYsj1wEYMXAzZBricehdD/gfYAoshkurrPuD3qUNINXIJ5b64vQLxHLJMdiB2DpbVxNQBJEltq1PbLAsikpSxonaIPEJxdzxvA9xJfncJXkDMBHlxgI99gHhBPndO5+52k4F9gE9TfDs2Seom36Vcd3pLZTedmNtWZmUbrl7mYerPA39OHUKS1LYnUwcokAURScpYUQWRTxPDtfM0hui9fAWweE7nOIloAzVlgI/tTQzPzWNHShncA6yPvZgl6UnKf2FWKqOyD8jeBVgidYgmLUPsECmrM4G3UoeQJLXNHSIFsCAiqaqKaJl1KbFrIk8rE4PNP5/T+rOAI4FjGPiO332Ii191nDk1FfgqMUT+nsRZJKkbnIi75KQUbgXuTh2iAyMpz0yOMg9Th/IXzySp7p5PHaBAydqxl/kXvSQNJe8dItOBz+S4fg9wIHAb8N6czvEmsBvw40E+vinRg7iOvysuB94NfJv8dwBJUhm8CPwidQippnop/1yIQ+j+G2xGAQenDtGB24j2upKk8hqoa0dVuUNEkjL2dM7rfx94KKe1FyB2ZfwamCenczwPbA5cPMjHVwYuJNp11cmzwIeB7YGHE2eRpG7yQ6KQLimNs4CZqUN0YCm6vxXVTpSntddA3B0iSeVXp+fbFkQkKWOPkl//3CeBE3Ja+33A7cRF+bzcB2wI3DzIxxci2oG9I8cM3WY68CNgNeA84k5MSVJ4kcF3E0oqxrPAn1KH6FC3D1cv8zD1GTjjSZKqwB0iBbAgIqmqZgAP5rT254DJGa85Cvg6cC2wbMZr93cNsDFRMBrIGGKA+so5ZugmbxC7fZYDjgJeSZpGkrrTEcDLqUNIKn3brB2I51zdaFlih3BZXQq8kDqEJKljFkQKYEFEUpXdl8OafwAuyHjNZYCrgWPJ9+fy2cB2DH1R6wRgsxwzdIuXiALUMsAXgGfSxpGkrvU74LepQ0gC4BJgUuoQHeihe2d0HEzkK6uJqQNIkjJRp5ZZDlWXpBzcm/F6jxGDzrNsp7QXcAewSYZrDuTbwH4MPyD8y8AHiaHiVWwb9RTwWeIuwG/iHc+SNJRJwCep5u8DqYymUf62SAcDo1OHmM1o4OOpQ3TgJeCPqUNIkjLhDpECWBCRVGVZ7hCZThQvsrqAPg/wC+Ku2wUyWnMgM4FDgK/S3AWt6cD5xE6SFYFvkf+A+rxNJ4bH7wesAPyA7FueSVIVHQU8lzqEpP8wMXWADi0K7Jo6xGx2BhZPHaIDZxHPdyVJ5WdBpAAWRCRVWZYFkc8At2S01jrAreR/J9obxAu8n7f5+EeBrxG7KXYl2oWV5ZfzdCLv/sAEYBd8sShJrbiY8t+JLlXRrcC/UofoULcNVz8kdYAOnZY6gCQpM2Vu39iqmalObEFEUpXdQzYXwM8BTs1gnRHA0cANwCoZrDeUx4BNgcsyWGsGUVzYFVgQ2BI4HriJ7mqjMo3IuR+wCJH3TODVlKEkqYReIS5YdtPPeEmhl/LvEtkaWDl1iIbliJ3RZXUXcFvqEJKkzMydOkCBkl2rsSAiqcreBK7rcI37iLvGOr0otBjwJ+BE8u+bfCnwXuD2HNaeBvwV+AqwPrAw0UrsVOJ7NSOHcw5kJjF75ZfERbt1ie2WuxI7QV4rKIckVdFnKX+7RKnKziLhXZUZ6ZZdGZ+g3HfjnobFa0mqknGpAxQoWUFkVKoTS1JBrgS2aPOxbxAX+9/oMMOOxJ18i3S4znB6iRZXJwCzcj5Xn0nABY0DotizHLEDZhVg1X7vL9ni2m8ALwDPN94+RxRBbiaKPWVp3yVJZXI+tl+Rut0zxC7gnVIH6cBBxPPWqQkzjAY+lvD8nZpJFMckSdVhQaQAFkQkVd2VxGDwVk0hXmR20qN5LPBdYiht3l4E9iG+3pTeAh5sHJfO9rExxC/3sQO8HUu8KJ3E2wUQCx6SVKy/ErOXvNtY6n4TKXdBZCFgT9Je0P8AsYu7rC4Dnk0dQpKUKVtmFcCCiKSqu4VonzS+hcdMJ1ovXdvBedchXqiu0cEazboB+BDwZAHn6sT0xuFMD0nqPncAu5H2bm1JzbsYeJmY71ZWh5G2IHJownNnYWLqAJKkzNVph0iyVufOEJFUdTOAq1v8/L2AK9o83zjgO8CNFFMM+RGwOd1fDJEkda9HgO2xYC2VyTTg7NQhOrQJsHqic68AbJvo3Fl4mSiKSZKqxR0iBbAgIqkOmm0jNQv4CO2/uNiUmG3xRWBkm2s0600i61HErgtJktrxPLAdtl2Rymhi6gAZSLVL4xOJzpuVc4iimCSpWiyIFMCCiKQ6+APD90PvBQ4EftvG+vMBpxAttlZp4/Gtuh9Yn3ghJElSu14HdgAeSh1EUltuAe5JHaJDBwDzFHzOMZR7mDrAaakDSJJysXjqAAWyICJJOXoCuGqIj88EDgbOaGPt7YG7gSPaeGw7fgusR2fD3iVJmk7MDLk1dRBJbeul/LtE5gf2LvicuwATCj5nlu4FbkodQpKUi6VTByiQBRFJytmvB/n7ScD7gV+1uN5CxJ1ZfwKW6SBXs2YAnyVeML5ewPkkSdU1DdgH+EvqIJI6dibR9rXMDiv4fGUfpn4aw+9+lySVUxHXl7qFBRFJytmFwGuz/d29ROupVoau9xBD1+8htvgX4WlgC+AH+OJHktSZZ4DNgd+lDiIpE88Al6UO0aH1gHUKOtdKwDYFnSsPs4gimCSpmiyIFMCCiKS6eBM4r9+f/whsBDzcwhqLAxcQbauK2mZ/NfEC8R8FnU+SVF03AesC/0wdRFKmJqYOkIGidm0cXNB58nIF8FTqEJKkXPRgQaQQFkQk1Ulf26wTid7Bzf7w7QEOInaF7J5DrsF8B9gWeK7Ac0qSqulMYmfI06mDSMrcxcDLqUN0aF9gfM7nGEM8py+ziakDSJJysxAwLnWIAlkQkaQC3ADsCnyeGKTejOWAPxMzRhbIJ9YcXiVyfpmYHSJJUrt6id97BwBTEmeRlI+pwDmpQ3RoHqIokqfdKPcw9VeBi1KHkCTlpk67Q8CCiCQVohf4Q5OfOxI4CribGLpelDuA99J8TkmSBvMasDOxM9IZVFK1TUwdIAOHEzuz81L2YernYWFbkqpstdQBCjSTaG2fhAURSZrTasC1wA+Ju9WK8mtan2siSdJAHgA2IGZmSaq+m4F7U4fo0BrAhjmtvTKwVU5rF+W01AEkSblaP3WAAk0i4Q1bo1KdWJK60Giircg3iB7DRZkGHAH8MuN15wGWABYd5JhA7ISZ2sgwbYD3nyMuqj3YOF7POKMkKVtvAd8DjifhXVeSCtdL7BL5buIcnToUuD6HdT+Rw5pFepB8vi+SpO6xXuoABXoo5cktiEhSWIcoSKxd8HkfA/YEbu1wndHEXXUbEHcVrE/sdMm67cCzxAuyviLJjcB1RAFFkpTWNUTLmbLfJS6pPWcCJ1DuThB7A58j7hzNylyUf5j6adj6UJKqbDTwntQhCnR/ypNbEJFUd+OArxM7Q0YWfO5LiSG37bzgmx/YnmixtT7xi3NsdtEGtVjj2LTf300B/gZcAVwJ3AnMKiCLJCm8ABxNXAz1gplUX08DfwZ2SB2kA2OJ58c/yHDN3YGFM1yvaL3AGalDSJJytTrFXNPpFhZEJCmRTYhdIasUfN5ZRFuu42mtcDAPMRx3b2BH4m63bjAO2LZxALwIXEUUSH4HvJwolyTVwf8CXybbu6kllddEyl0QATiMmOWXVYH3kIzWSeUvwBOpQ0iSclWndlmQuCBS5q20ktSu+YBTiF0NRRdDHiQKMd+iuWLIWGA34BzgeeBc4i63bimGDGRhomjzC+AZ4o7lzcm+fZck1dmdwMZEv32LIZL6/AF4JXWIDq1KPHfMwirAlhmtlcrE1AEkSbmzIFIgCyKSusljxMDD63I8x3bA3cQQ86KdQrS2amYg4trAr4mh5r8HPgzMnV+03MwF7Av8FbiPaE02IWUgSSq5R4EjgffigF1Jc5pK3EhTdodmtE7Zd4e8QbwWkCRVVw/w/tQhCjQLeDhlAAsikrrBw8DHiDu4fgFMz+EcE4hhhJcBy+Sw/lD+Tfxy+xQweZjP3RT4I3AbcCAwPtdkxVoF+B7wFHA+sFnaOJJUKn8D9gBWBn4MzEgbR1IXm5g6QAb2pPObaMYSz6fL7DcM//pBklRuawLLpQ5RoEeBaSkDWBCRlNKDwEeBdxK7Id7K4Ryjgc82znVADusP53RgDWLY+GB6gJ2AvwPXUv6+z8MZRbzIvQb4E7FrRpI0pxnAWcC6RBH598DMpIkklcFNxM7cMhsNHNThGrsDC2WQJaXTUgeQJOVu19QBCnZv6gAWRCSlcD+wP/AuomCQ112u2xE91k+m+J0WLxJ38n6Uwfs49zQ+5zbgEuB9xUTrKtsDtxKtHVZKnEWSusUk4HjiTrH9gFuSppFUNr1UY5fIoXR2zSKrtlupPELcMCVJqrbdUgco2A2pA1gQkVSk+4h5EqsTg7bzKoSsRAyUvIzYfVK0i4B3M3S/35WJfBcAaxURqst9mLhL4CfA4omzSFIq9wCHAUsDXyFaDEpSO84kenSX2fK031P9nWQ3mD2V0yn/v6EkaWjLUr+uGRZEJNXCv4gL3u8Gzia/dh/zAic0zveBnM4xlNeIPsW7E8PQBzIOOI4Y7L5tMbFKYxRwOFEYKXrOiySlMIWYG/UpolC+OvAz4M2UoSRVwlPA5alDZKDdXR5lH6YOURCRJFVb3dpl9RKtPZMalTqApEq7m7j4fwH53t3UQ+w8+S6wRI7nGcpfiD7HTwzxOTsCpxB3u2lgU4ji2VDfR0kqs3uJHYKXEXOjpqaNI6nCJhLtSctsF2BJWtsxN5ZoW1tm1xBDZyVJ1fah1AEKdjdxM3FSFkQk5eEOohByIflv814X+B9go5zPM5ipwBeAHzP417ogccfvB4sKVVKvEsPl/5E6iCRl6A3gSqIA8mfgsaRpJNXJ/2fvvsMkqarGj39nA+ySQcmioCCoREVQMaBEBcQACqKoZAmiYg4vZn1N+CoGRGRJioKAoqCACCpZxAQoIjkISI7Lsju/P87Mb2aHCXW7q+pWdX8/z3Ofnd2trjrdPR2qzr3n/FYLaHAAACAASURBVIz4frV07kC6MB3Ykzi3KOqNwHLVhFObObkDkCRVbiP6r5ds9nJZYEJEUrmuIE5Wfk71iZAViIazexArRHK4FNidaBI/kY2Bn+CqkKncCWwD/Dl3IJLUoQeJz4N/Ej2zRv/5eMa4JPWvx4AfEb2J2mxv4nt/0f6DbW+m/gixwl6S1NvenTuADEyISOoZlwOfAn5B1AOs0kzgQOCTwFIVH2siTxD394tMfGI2AOwPfA1YpKa42uomomHmNbkDkaQpDAI38uSExz+B26n+M1CSUs2h/QmRpxGlZ39eYNvnAi+rNpzKnUwk2SVJvWsF4C25g8jAhIik1ruMSAycQT0XgbYG/g9Yp4ZjTeTvxKqQKybZZkngSODNtUTUbhcRNTNvyR2IpMo9DJyeO4hR5hLlrFJH0RnKktQElxJJ27VzB9KlfSmWENm76kBqcEzuACRJldub/ps8eycxoSw7EyKSOnExkQj5NfUkQp5FrLR4bQ3Hmsgg8BXgf5i8Ae5zgVOBZ9cRVMt9FfgIMC93IJJqcTuwa+4gJKnPDBKrRL6QOY5uvRpYncn7MM2m/c3UbwLOyx2EJKlSM4mKIv3mDKovr1/ItNwBSGqVC4k+Dy8hmsNWnQxZgqgXfBV5kyHXAa8gmqdPlgzZBPg9JkOmch/wOuD9mAyRJEmq2nE05AJEFwaYevXHTsCyNcRSpWNp/3MlSZrcbsAquYPI4IzcAQwzISKpiN8DWwIvBc6i+kTIAPEB8U9iBUHOZYRHABsQj8FkXgX8Bliu8oja7XLg+cDPcgciSZLUJ24Fzs4dRAn2ZPLzgrY3UwfLZUlSr1sC+FzuIDJ4grie2AgmRCRN5nziQv8riIv9dZTHegHwB+B48mbMbyeaN+5H1IyfzOuAM4kPNo1vAXAYsBlwfeZYJEmS+s2c3AGUYEVgxwn+73nE98w2uwC4NncQkqRKfZD+XB3yB+D+3EEMMyEiaTy/ATYfGr+lnkTICkQj8suIklw5/QhYl0hyTGV34GT6rxlWiouBjYH3EU2MJUmSVK+f0aALEV2YaBXIPrVGUY05uQOQJFXq6cAHcgeRSWPKZYEJEUkj5hE1azciymOdX9NxZwLvAa4B9iLKZeVyD/Bm4C1DP09lZeDTwPQqg2qxe4jndDPgisyxSJIk9bNHgRNzB1GCLXhyv77ZxCSlNnsMOCl3EJKkSn0RmJU7iEx+mTuA0UyISLqHqF+4OvB24M81Hntr4C9EKaWlazzueE4kVoX8JOE2twPrECsf7q4iqBb7PrA2cBQ2hpQkSWqCObkDKMnY1SBvApbJEUiJTqE3VvBIksb3EmDX3EFkcj1wde4gRjMhIvWva4B3AasBHwduq/HYGwCnA78GnlPjccfzT2JFzK5EgiPVY0RC55nEapGHywutlX4BbArsDfw3cyySJEkacQnx3bft3snCM2x7oVyWzdQlqXctSe9MSujE8dRTir8wEyJS/zkX2J5IRHwXeKTGY69NrMT481AMOT0KfBRYn+iZ0q0HgEOJxMg3iBJk/WIB8EPisdwBuDRvOJIkSRrHIL1x4X05YKehn9clf//Bbt1KOecjkqRmOhxYK3cQGR2bO4CxTIhI/WF0f5AtiNp9dZYxegbwA+AqokdHbqcRCaEvAI+XvO87gYOJD7svAneUvP8mmUsk1dYCdgP+ljccSZIkTeE4GjZLs0P7Df05UZP1NjkOmJ87CElSJXan/X2uunEhcG3uIMYyISL1tuH+IM+g/v4gEE3HDwf+RSxtz/2ecz2xMuX1wI0VH+tG4CNESbI3AGfQGyefEOXWPg2sQZRduy5vOJIkSSroFuDs3EGUYDNgE+BtuQMpQS+s2pEkPdmzgW/nDiKzxq0OAZiROwBJlfgn8HXijafOkljDngJ8EDgImJ3h+GM9TqzW+CJRKqtO84BTh8ZqwB7AnkM/t8mNRLmzE4G/0DvJHUmSpH4zB9g6dxAl+AmwdO4gunQJ8I/cQUiSSrcocf1k8dyBZPQ48VndOCZEpN5yLvA14EzqLYk1bCngvcD7hn5ugl8TiZl/5Q4EuBn4FPBZ4KXAVkRD9xeSf/XMeG4jPrxOJPqCmASRJElqv9OI/ndN+b7eqWfkDqAEc3IHIEkq3XTgBKJsfT/7OXBv7iDGY0JEar95wI+Aw6i/JNawxYADgA8Rq0Oa4BbgPcApNO9C/nzg/KHxcWAZYHMiObIl0Xw+h38Ts9QuHfVnjsRaU00jfr/vyh2IJElSFx4lJrzskzuQPjcX+HHuICRJpRoAjgDemDuQBmhkuSwwISK12T3Ad4BvAbdnimERYG/gY0S/kCZ4gkgOfRp4KHMsRd1HzNQ7bejvqxE1kdciak4O/7lCice8A7ickcTHZcDdJe6/12wKfBP4PvC9zLFIkiR1aw4mRHL7GQ2dOStJ6sgA8GWiTHq/+zfRS7eRTIhI7ZO7PwjEe8dbgUOB1TPFMJ7fAfsDV+YOpEs3D42xlmYkObISUZNy1tCfY38eBO4kEh9jx53EyiJNbUWi98w7hv7+/XyhSJIkleZi4Brie6XysJm6JPWWjwCH5A6iIb5OVEdpJBMiUnvk7g8CUTJoJ2L1Ra6yTuO5A3g/UaOxaeWxynQ/8MehoWrNBA4EPkn762tLkiSNNUisEvl85jj61X+As3IHIUkqzXuAz+UOoiHuBY7OHcRkmtjEV9KIecRKkI2ALYBfkicZMgBsD/yJqHPblGTIAuBwYB3geHo7GaL6bEH04/kaJkMkSVLvOg6/P+dyPFHqV5LUbtOJ1RCH5Q6kQb4LPJw7iMm4QkRqpib0Bxn2SiLL/eLMcYx1CVEe60+5A1HPWB34KvCGzHFIkiTV4RbgHGCr3IH0IctlSVL7LQH8ENghdyANMo+YuNxoJkSkZvktcCRwKvBY5lg2JRIhW2SOY6x7gA8DR5GvdJh6y2zgg8Tv1azMsUiSJNVpDiZE6nY58PfcQUiSurIqcDpR0UUjTgBuyx3EVEyISPndQZyIHAX8K28oAGwAfIZmZri/TzSp+m/uQNQTlgT2At4LrJY5FkmSpBxOAx7AMqF1mpM7AElSVzYBTiGSIlrY13IHUIQJESmPQeBXxGqQXxBLynJbG/gU8ObcgYzjz0R5rItyB6KesCrwbmBfYOnMsUiSJOX0CNEjcO/cgfSJecCPcgchSerIIsAniIm60zPH0kQnAn/LHUQRJkSket1MrAQ5GrgpcyzD1gE+BOwOTMscy1gPEB8238amg+re+sAhwFvw80+SJGnYHEyI1OV04O7cQUiSkm1A9H/aIHcgDfUEcf2uFbwgJFXvCeDnRLmns4D5ecP5/zYDPgDsmDuQcQwCxxOJmtxN5dVuA8CWwPuBrTPHIkmS1EQXEaV718odSB+wmboktcsM4trUocDMzLE02RHAtbmDKMqEiFSda4kkyDHAfzLHMmwa0Rvkg8BLMscykTOI5Yd/zR2IWm0RYBdiRcj6mWORJElqskFilcjnMsfR6+4CzswdhCSpkAFiUuUXgQ0zx9J0DxO9iFvDhIhUrrnAT4neIOcTJxdNMAt4KzFLfu3MsUzkEiLrfn7uQNRqywD7AAcDq2SORZIkqS2OAz5LXABSNU6gGb0jJUmTewnwBeDluQNpia8Bd+QOIoUJEakcfyeSIMcD92SOZbRlgf2IBtIrZY5lIv8APgqcRnMSSGqXmcCriBUhOwFL5A1HkiSpdW4GzgG2yh1ID5uTOwBJ0qTWJ1ZLbp87kBb5L/CV3EGkMiEide5h4ESiLNYlNOti/mrAe4iZ8k29OHwr8EnixMCG6Uo1DXgpkQTZGXhq3nAkSZJabw4mRKryl6EhSWqW6cRn375Ej11XSqb5JPBA7iBSmRCR0l1GJEFOpHkv+vWIRum70tzX933E0sNvAo9mjkXtMgBsTCRB3gysmjccSZKknnIa8CCwZO5AetCc3AFIkhayCrAHsBfwjMyxtNWlwHdzB9GJpl4wlZrmfqIc1pE0b2bPAPAKolH6qzPHMpnHgG8QDanuzRyL2mVdIgmyC/CszLFIkiT1qkeAHxMXh1SeJ4Af5g5CksTiwBbAO4EdiNUh6sx8oirN/NyBdMKEiDS53xNJkJNp3mqG6cAbiBUhL8wcy2QWAEcTy+huyRuKWuRZjCRB1s0ciyRJUr+YgwmRsp0B3Jk7CEnqU2sCrxkamwOLZo2md3yF5k0YL8yEiPRkNxAzo+YQDb+bZjbwDuAQmj9b/jSiYfrVuQNR480CNiW+oGxHs5N8kiRJvepC4FriApLKcUzuACSpTwwQ5a+eD7ycSIKslTWi3nQ98OncQXTDhIgUbiOSICcSPUKa1CB92FOAA4CDaH4D6d8BHwYuyh2IGms28CIiAfKKoZ+dqSFJkpTXIDEx7LOZ4+gVdwO/yB2EJPWgGUTy/vnARqP+XDZnUH1iP6LMZmuZEFE/uws4iUiCXECUdmqiNYD3AnsCi2WOZSp/IxIhZ9LMpJLyWQx4MZH82JxYDbJIzoAkSZI0ruOAzxAzbdWdHwGP5w5CkhpsAJhJVI2YPWrMApYkmp8/bZyxEvYAyeEE4KzcQXTLhIj6zb3AKUQS5DyiwV1TPZ/oD/ImYFrmWKZyI/AJollgKxsqJdqZSKhdSsuz4hVanEiAbE4kQTYlvuRIkiSp2W4CfgNsmTuQHjAndwCSlGBl4IEajzeNSH40/ZqXwk1E1ZrWMyGifvAQ0cviROBsmj1DZwDYikiEtOEE5G5iOf13gLmZY6nTPsTz8wRwOfCHoXEBkSjpN8sCaw+N5wIvBTbBzxhJkqS2mkM7zkea7ErgT7mDkKRES+YOQI00H9iVmGjeel6sUq96lKjVeiJRvunRvOFMaWlgN6IO33qZYyniEeBrwFeA+zPHktMMYuXDpkSTe4B/EsmRy4lm8lcDd9L+EmIzgGcykvgYHusAy2eMS5IkSeU7FXgQL4x1Yw7tPweQJAng48CFuYMoiwkR9ZJ5RPLjROB0YmVI020M7Au8heb3B4FYEXEk8GngP5ljaarhRMGeo/7tXkaSI6PHTTSvxNhTWDjZMfzzs7DklSRJUr94BPgxsFfuQFpqAVFnXZKktjsb+FLuIMpkQkRtNx84h0iCnAbclzecQpYgEiD7En1C2uLHREb42tyBtNCywEuGxmgLiBJb/xkad4z6efjv9wKPTTBGzzgbIPp2LDk0lhr189i/T/R/KwFPLetOS5IkqdWOwYRIp34F3J47CEmSunQH8Dbi+lXPMCGiNhoEzieSIKfQnp4NGxJJkN1o19Lzc4APEyWgVK5pwIpDY4MObj+XSIwMEIk2G5FJkiSpLBcA/yZWCivNMbkDkCSpS4PAW4mkSE8xIaI2uYhIgpwM3JY5lqIWB95MJEI2yRxLqtOBLxCPe90GsN5uEYsODUmSJKlsg0QfjM9kjqNt7gN+njsISZK69EFiknTPcTaxmu5PxAtwdaLc0DdoRzJkXeCbwK3AUbQnGTKfqHW7PvBa6k+GrAf8EHhpzceVJEmS9GTH4kSlVCcSq7glSWqr7wFfzR1EVVwhoibbDLgldxAJZgM7E6tBxvaKaLq5wA+ArwDXZTj+JsDHiCQMxBuvJEmSpLxuAs4FtsgdSIvMyR2AJEldOBs4kB6eEGFCRE3WlmTIOkQS5O1E8+w2eRD4NvB1ool3nQaAVxCJkC1rPrYkSZKkYuZgQqSofwKX5g5CkqQOXUVM9p6XO5AqmRCROrMo8EYiEfLyzLF04i4iCfJtosZtnQaA1wAfpX0raSRJkqR+cyoxkWrJ3IG0wBx6eEatJKmn3QlsB9yfO5CqmRCR0qwF7AO8A3hq3lA6chPwZaI81iM1H3s68AYiEbJhzceWJEmS1JmHgZOAPXIH0nCDwPG5g5AkqQOPEGXsb8gcRy1MiEhTWwTYEdgPeFXmWDp1NfC/RMPyupe9zQTeAnwEWLvmY0uSJEnq3hxMiEzlbNpT9lmSpGGPEJVcLskdSF1MiEgTeyawN/HFf4XMsXTqMuALwM+ABTUfexbx2H0QeEbNx5YkSZJUnj8A1xHnSBrfMbkDkCQp0aNEmazzcwdSJxMi0sIWJ5aIvR3Ymuh30Ua/IRIh51J/DdsliNU0hwAr1XxsSZIkSeUbJFaJfDpzHE31AHBa7iAkSUrwGLA9cF7mOGpnQkSKkljbEGWdXgssljecrpxKJEIuy3Ds5YADgYOHfpYkSZLUO47FhMhEfkL9PRolSerUY8AOxETqvmNCRP1qOvAyIgmyE7Bs3nC68gRwAtEj5OoMx18ReB+wP7E6RJIkSVLvuZG4cNLWvopVmpM7AEmSCppLTAg/J3cguZgQUT8ZAF5AJEHeDKySN5yuPQp8H/gqcXJSt6cDHwD2IvqFSJIkSeptczAhMta1wIW5g5AkqYC7gR2BC3IHkpMJEfWDdYBdiUTImpljKcP9wOHAN4A7Mxz/2cCHgbfhe4gkSZLUT04Bvo0rw0c7hvr7NkqSlOo64NXANbkDyc2Lmf1pPnAF8HDuQCq0GrALkQjZKHMsZbkDOAz4DtG0r27rAx8FdgamZTi+JEmSpLweBk4C3pk7kAY5LncAkiRN4WKiTNZduQNpAhMi/eFuYgnv8Pgjvdnw7alEP5C3EP1BesX1wJeJ5emPZjj+psDHiGZLkiRJkvrbHEyIDDuXPOWLJUkq6lTgrfTmteCOmBDpPYPAlUTi46KhP/9F7y7hXZKofbcrsDW99Tv9W2I5+mlE4/Q6DQCvJFaEbFHzsSVJkiQ11x+IshvPzB1IAxyTOwBJkiZxGNH/d37uQJqkly4e96sHiWVPw8mPS4D7skZUvUWBbYmVIDsAs/OGU6oHiC/V3wGuznD8acBriBUhL8pwfEmSJEnNtoA4Z/lU7kAyewj4ae4gJEkax8PAPsAPcwfSRCZE2udaRpIfFxKrQfohyzcd2JxYCfJGYJms0ZTvb8C3gBOIL9Z1WwZ4B3AAvdF4XpIkSVJ1jsWEyMn0dl9OSVI7/Y3o//vP3IE0lQmRZpsLXMZI8uMi4M6sEdVrAHghsRLkzcBKecMp3TziS/S3iOc3R1mz9YgkyNuAxTIcX5IkSVL73ECU+H1l5jhympM7AEmSxjgKeDf2C5mUCZFmuQ24gJEEyJ+Bx7NGVL8ZRKmmHYiVIM/KG04lbga+S7xJ3ZHh+DOIvisHEqtuJEmSJCnVHPo3IXID8PvcQUiSNOQRYD/guNyBtIEJkXzmEkuYRq/+uJnebX4+maWJniDbE/0rlssbTmXOIpqk/5L6m6QDrADsTbxBPi3D8SVJkiT1jlOI85vFcweSwTFELxVJknL7I7A7eXoRt5IJkeotIPp+/J1IgAz/+W/yXBRvijWJVSDbAy+nd38X7wOOJpqk/ytTDJsSq0HeBCySKQZJkiRJveUh4CSiF2G/OTZ3AJKkvvcY8Ang6/T3NeZkvXoROpdbeXLi42rg0ZxBNcQM4CVEEmQHYO284VTuT0RvkBPJU7dvFpEAOZDowyJJkiRJZZtD/yVEfgdclzsISVJfO4+oAnNt5jhayYRIZ+7jyYmPK4F7cgbVQMsC2xAJkFcP/b2XzQV+TCwbv5Q85c+eTpTE2ht4aobjS5IkSeofvweuB9bIHUiNjskdgCSpbz0AvJ/oS2zpxg6ZEJncXOAqFk58/J1YCdKPvT6KeDYjpbBeBkzPG04tridKYh0N/DfD8QeI5ugHEc3Sp2WIQZIkSVL/WUAkCD6ZOY66PEKUCZMkqW6nEtf+bs0dSNuZEAkLiP4Oo5MefyeWHc3PGFcbzAQ2YyQJ8uy84dRmEDiDWA3ya/L8niwBvI0oi/XcDMeXJEmSpGPpn4TIKcCDuYOQJPWVPxKrQs7PHUiv6KeEyOPATcCNo8b1RKkr+3ykWQ7YlkiCbAsskzecWt1NLEv7LvH7k8OzgQOIWr1LZYpBkiRJkiDOi84jVq33ujm5A5Ak9Y2bgI8Q/Yktj1WiXkqIPMTCyY4bxvz9Dvzl6dQA0QR9eyIJshn9UQprtEuIJuknAY9lOP50og/LgURfFkmSJElqimPo/YTIzcBvcwchSep5DwCfB/6PPNcge16bEiL/ZeEEx9hxL/b1KNMiwEsZSYKsmTecLB4Ffkj0B7k8UwzLAXsA+9NfjQolSZIktcfJwOHA4rkDqdCxOMlSklSdR4DvEcmQuzLH0tOakhAZBG5j/ETHDcQSoYdzBdcnFgE2Bl5JzOzZDJidM6CMLgGOB04gEm05bEA0StoNmJUpBkmSJEkq4iEiKfL23IFU6NjcAUiSetK9wDeHxn8zx9IXqkqI3AfcQzyh90zx8y1D4/GKYtH4ZgIvYCQB8lJgsZwBZXY9cByRBLkmUwxLAm8E9iSeD0mSJElqizn0bkLkQvKdJ0qSetNtwNeIVSEPZo6lr0yWEHmcaCBdJKkx+uf7gfnVhawOzQCez8IJkCVyBtQA9wI/IRIhF5Kn5NoMYGvgbcCO9O+qHEmSJEnt9juiwsPqecOoxDG5A5Ak9Yx/AV8mVh7OzRxLX5oB7MX4iY9HsSdHm80ANmQkAfIyYgVCv5sH/IJIgpxBnjeeASI59TZgV2CFDDFIkiRJUpkWEImDQ3MHUrLHiIl0kiR16nHgVOBI4LfYkyqrGcBRuYNQKaYTfSeGEyAvB5bKGVDDXED0BfkJkfTL4elET5C3Ac/JFIMkSZIkVeVYei8hchpRFlySpFRXE0mQ47A/SGM0pam60k0D1mfhBMgyOQNqoGuJN5zjgesyxbAUsBORBHkFsTpEkiRJknrRdUTprJfnDqRElsuSJKV4GDiZSITkKtGvSZgQaY9pwLqMJEBeASybM6CGuhs4kUiEXEqeN52ZLNwXZFaGGCRJkiQphzn0TkLkNuDs3EFIkhrvXuDnwCnE58ajecPRZEyINNc04LksnAB5Ss6AGmwu8aZzPPAroi5f3QaAFzDSF2T5DDFIkiRJUm4nA4cDi+UOpATHA/NzByFJaqQ7iL4gpwDnEX2L1QImRJpjReCFo8YmmACZyu+IlSAnk6+m6zMY6QuyTqYYJEmSJKkpHiTO0XbPHUgJLJclSRo2D7iEaIp+FnARJs1byYRIHksTqwmGEx8vBFbLGlF7/INIgvwQuCFTDEuzcF8QSZIkSdKIObQ/IXIZcFXuICRJ2cwnPgt+OzQuJPqDqOVMiFRvFrAhI4mPFwJrZ42ofe4CfkQkQi4nX1+QbYgkyGuxL4gkSZIkTeR84EZiRX1bzckdgCSpNo8Qk7CvHhp/Av5ArHpUjzEhUq4ZwPNYuPTVevg4d+Ix4DQiCXI2eerwDQAbE0mQXbAviCRJkiQVsYAoN/U/uQPp0OPAibmDkCSV7h5Gkh7D4yrgZuKzS33AC/WdGwDWZOHkx/OB2TmDarlBYgnacURDogcyxfFMojH623A1jyRJkiR14ljamxD5OXHRTJLUTreycMJj+Oe7yFN5Rg1iQqS4VVk4+bExsGzWiHrDAmIJ2mlE472bM8QwHdgU2GFoPC9DDJIkSZLUS/4N/B54We5AOmAzdUmq3wLgIaJM1dgx0b+P9/93kW+StVrAhMj4liMSHsPJj02AlbNG1FvmAmcRSZDTiTequi0BbE30A3kNlsOSJOW3be4AJKnhDge+lTuIivVauY7NieoKbdNrz0OvT+Z0treqdgdeQ63DAnw9qwb9/mJeCnju0HjeqD9XyxlUj7of+AVwKvBrInNbt6czsgrklcAiGWKQJGki83MHIEkN12sXqfuBz1kz+B1D6s4gvo6kntEvCZGlgeewcNLjecDTcgbVB24jVoGcCpxP/Y3RpxErfYaTIBvUfHxJkiRJkiRJUkP0WkJkacZf8WHioz7/IBIgpwF/pP4ZQYsBWxIJkO2BlWo+viRJkiRJkiSpgdqaEBlOfIxd8bFqzqD62CVEAuQ0IiFSt1WJ5McOwBbArAwxSJIkSZIkSZIarOkJkWUYf8WHiY+8ngDOJRIgPwdurfn4A8BGjJTCekHNx5ckSZIkSZIktUwTEiLTiQTHGsCzWXjFxyoZ49LCHgbOJMphnQHcV/PxZwGvYiQJYlJMkiRJkiRJklRYHQmRAaKPw+pE0mONMT8/vaY4lO4uYgXIacA5wGM1H39FRkphbUX0B5EkSZIkSZIkKVkZiYgBYDnGT3asPjTs6dAe1zPSFP1CYH7GWC4lEmaSJEmSJEmSJHWlaEJkKcZPdgz/uWT5oalGfyYSIKcCfwMG84YjSZIkSZIkSVK5hhMiiwHPYOJVHstliE3VWQD8gUiA/IxYFSJJkiRJkiRJUs+aAfyH6NWg3nYrcPaocVfecCRJkiRJkiRJqs8MTIb0qoeB84CziATIP7AUliRJkiRJkiSpT5XRVF3NsAC4jJEVIBcDj2eNSJIkSZIkSZKkhjAh0m7XMbIC5LfAvXnDkSRJkiRJkiSpmUyItMt9wG8YWQVyXd5wJEmSJEmSJElqBxMizTYPuJCRBMjlwPysEUmSJEmSJEmS1EImRJrnKkYSIOcDD5Wwz2WAtccZ2wE3lbB/SZIkSZIkSZIazYRIfncykgA5B7i1w/3MANZg/MTHihPcZnqHx5IkSZIkSZIkqVVMiNTvMeB3jCRB/gYsSLj9U1g42bHO0J/PAmaWGqkkSZIkSZIkST3ChEg9/sRIAuQCIikykenA8sBKwOo8ebXHU6oMVJIkSZIkSZKkXmRCpBo3M5IA+Q3wX2BJIsmxCbDy0M+jx/C/LQ9Mqz9kSZIkSZIkSZJ6lwmR7i0ArgGuBW4HHgBmE8mNg4DPD/08O1eAkiRJkiRJkiT1OxMi6QaB+cQqjuGxztCQJEmSJEmSJEkNZEIk3QA+bpIkSZIkSZIktYq9KiRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMizPgyYwAAIABJREFUkiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMikiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs8zISJJkiRJkiRJknqeCRFJkiRJkiRJktTzTIhIkiRJkiRJkqSeZ0JEkiRJkiRJkiT1PBMikiRJkiRJkiSp55kQkSRJkiRJkiRJPc+EiCRJkiRJkiRJ6nkmRCRJkiRJkiRJUs+bkTsASZIkSSrRAPBUYGXgKcBDwN3APcD9wGC+0CSprywOLAM8DNyXORZJkgATIpIkSU3zWmDFkvf5OHEx+O6hcQftvzDxdeAFBbabB+xAXIxpklcDTyuw3YPAiRXGsSSwS8L2c4jHtCkWB7YmnuP1iCTIikx8nvMEcC/wX+DPwLnAb4DrK4+0Wh8Dti2w3SDwFuCWasNJ9nJg7QLbzQOOBRZUFMc0YM+E7U+i/e+lrwKelbD99cA5FcUy1gbAJgnbPwD8uKJYOjUA/BRYvsC2/wF2rjacyiwJvIR4Lb8UWJNISC86apsniPfe4fFP4LfAecT3kjYaAE4hkvBTuQ14c7XhtMZ6wItK3N8C4r34DuDOodH09+aNgY1yBzGBc4F/l7CfnYBlS9jPaI8zcj7zX+I5f6DkY9Tt+xT7DvQw8X23Sd/DAXYEViiw3d3E+2VVlgPemHKDQUffjjVothvJ/xg58ozNabazyf8YOfKMfZCqdzH1/D5fAxwJ7AasVMs9K8/qwHyK39d3ZYlycmdRPP59K4xjjYQ4BoGlK4ylqBWB/YEzgcco5/VwPXAUsEWN96MsSxGJs6L39XN5wpzU0RSP/9MVxrFIQhyDwPMqjKUuPybtPj8KrFVDXLOB6xJju76GuFJtTdp9eGWeMDu2IfH67fa9+CrgWzT/PHCsbUm7n6/IE2bjHEI5n92TjbnAtcTF5p0p/8J8tz5P9Y9Bp2PXku7j1TXFexXwHSLhWCT53CTrkXZf35InzEldSvH4q0wKb5gQxyCJGzt6a5gQcTR1bE6zmRDp32FCRHWoKyEyejwB/IjmzlQb60uk3b8r84Q5qZSEyGPA8yuKo00JkaWJCwgPjxNXmeNCYgVPWxxM2v27k4VnbTfB0RSPfwGwTUVxmBApNupYIfLFDuK6voa4Uv2ctPtQ5ezZMq1F/B5U8R58OXHRrw0VTX5J2n07KU+YjVNHQmTsmE98xz6UWE2amwmRasbjxGrmtnw+f4+0+3dhnjAnlZIQeZBiq2E6YULEUXiYEHE0dWxOs5kQ6d9hQkR1yJEQGT3OAp5d+b3s3GxiyXXq/XpVjmAnkZIQGSRKFyxTQRxtSIjMAt5PZ897N+MyYLsa7l83BojVXqn3bfccwU7iaNLiv4tiJedSmRApPnarMKZ1iZIgqTFdX2FMnViDtNWMg8QEhafnCLagAeAAqk9MDwI3Ae+luYmRZ5H+/M6jmveutsmREBk9HgX+D1il6js6CRMi1Y4FwOnEqvKmWpbO3kuLlAyuU0pCZBD4G7BYBXEkJUSmVRCAJEmS2msrYnbmW3MHMoHdiBqxqQ4qO5CaPZO4aNxvXkLUmf8ynT3v3dgY+AVRSquKE7cybENn5Yva/np4KvATYGbuQPrY16imBM0AcATNvQie4gCiL02K6TSzzCPEczMHOJx63hNXI37PLiGSZE3TyfM7g+Y+v/1kFvBuYrLJN8mbGFE1BoDtgSuA12eOZSJ70Nl7adu/w60LfDt3ECZEJEmSNNYSwHFE3eWmfV/s9CRgB+AZZQaSweuIWZX94p1Ew93cs6X3AP5I1Hlumk5fDxtTbkPbHF4M/G/uIPrYCkRZq7LtRSRC224x4r2jE3sTF2yb5tvkWV32fGKixoeJhFETLE53z2/Tyhb2q1nAgcDfgddkjkXVWIYoRfi13IGMMY1IqnZiF9rXK2WstwN75gygaSe4kiRJao49adYJxMuB9Tu87XSiEXfbfRHYLHcQFZtO/N79gChh1ATPIUoCNGnl1Jp01+uk7TMMIcrpvCF3EH1sb8pNXqxA7yS53krnK2ieQnkla8ryUWC/jMdfBPgCzflO8jY6LyG5PHFBU82xLLEi9NN4nbRXvRf4ZO4gRtmOztsYLEp8/rbd4cAGuQ7uC12SJEmTOZgoK9AE3V7A3YvoQdJmM4ia/0/NHUhFFiFqPr83dyDjGCTKdzXFAURJiE7tDKxUUiw5/YCo5a/6DZe3Kqt0WVVluHLo9vOqSQnLZwKfyB0E8ADNSYgc2OXtm/T8KgwQv+dnEklJ9Z5DiZUJTdDte8C7aH9pyVnAycBSOQ5uQkSSJElTOQzYKHMMTyNKRnVjOeAtJcSS26rACfTmd/nv0t2qhyrtQTRab4LFiZJi3ZgJ7FtCLLktTZxQN7HEUD9YF3hfCfvZkmobtddpc7rvebERzVkN+A2a8fp6D3Bj7iCAVwHP63IfLyDK/ql5tgZ+Q5SPVe85ks56r5VpHeIzrxtlnBc1wZrExJba9eJJlCRJkso1jfxlTMqaCdUrszK3Bj6eO4iSHUz3F/mr8lngxNxBjLI7nZdrGW1feqMx+YbERVvl8T/A6l3cflEa0GC1RGV9zjTh82o9orRLp+YDdwCPdxnHz4Cju9xHWXrp+dX4NiA+85vSs0blmQl8PnMMB9LdCt9hvfIe8kbiHKBWbV9eI0mS1M/uAf4zxTaLEk2pu73oudXQOLvL/XSizFq5GwAvA35f0v5yOhS4EDgndyAl2BL4apf7eIKY1XkucMvQeJjoS7ACsCLwbKJx6soJ+z2FuODbJN2Waxm2MrAT8KOS9pfT3sDvgONzB9KHFiMSGp02Jf4o+WfsluXpwI4l7euNwCrAbSXtrxM7d3CbPxArSy8HbiXemweIUo9PIz6DdwBeQbHvJnfSnHr5zyBiL8NOwCHA7SXtr1c9AVwzxTYDRLm95SkvibEd8XvchLKx/wUuqPF4t9R4rGF3DY3JzAZWo/tr2TsBmwKXdLmfTixFeWW7hnsr/rWk/eX0ZeL5uLjOgw46+nZ02sCnLjeS/zFy5Bmb02xnk/8xcuQZ+yBV72KK/04eVnCf04iT+FcSs6IeTDjG6JEjGQJx4lDma/kn9YY/rrMo577cQVww69QaiccrY1XCWKsAdyfGMXrcDuxP8ZrfA8DGxKqPe6fY9xVEeaom2YJyXw8X1hv+uI6mnPvyEPDcLuJYJPF43ZbNaYIfU97vUicXz9cG5pZ0/Os7OH7ZvkC5r89P1xv+k1xF8VjnA29O2PdSRHL3zin2+9oS7kdZ/pdyn99P1hp9cxxC8cfo5oT9TiOSIlsR/WZSfn8nGgd0fC8n9/mEGM6tKIaqXU3x+3howX1OJ767bkFMpHkk4Rijx8nd3rkOvTshxiLjyHrDH9ellHNfbqK7/j0bJh6v1CfC0a5hQsTR1LE5zWZCpH+HCRHVoYqEyFjLA18B5iUca5AoebFkh8fsxh8T45xqzCNmqeZUVkJkkFjt0ulsuSYkRI5IjGH08/gVuvudXG5oH4+Ns///EDMRm+Y0yv98e0Gt9+DJjqa8+3IVnSexTIh0N24jvTnqb0s8/vWJxy7bLGImd5mvzf8Qv5c5LF0wxuHxkQ6PsxTwOca/sJmltvwEZtNd8n68cTu9UbYwVVUJkfG8DDg/4Xhjx0OkrSotyoTIwuPQDo+xMnA4kZBNeV4foP731gFitVOZ7yGPEN9lcyorITIInEHn5cSSEiL2EJEkSeo/dwHvJ/3ixUyid0WdXkzxi7ULCm43A9ivs3Aa6aXkr4fcqbWIZuWpHiLK87yfWPHUqXuG9rEOcNGof58LvJ7uL8SUbXWKl2sp+nqA3qlDDfAc4Hu5g+hTKxMXtot6O82fCJViV4rPbi36+lwReFNn4XRt1cTtj+vwOA8AHyM+D45m5LG5gQx15SfxFopfeCz6/K5EZyurVNzvifJsryESlqkWBz5VakQq0+3ESrMvJN5uSSJZVqdtKF4esuh7yGxgz87CaaRX03lyPYkJEUmSpP71VeD0xNtsW0Ugk0i5UPuxhG33IXqT9Ir306yyIkV9lvTVLXcRF1HLLOF2A3HB5KvEzLG9WThB0hT7U/wc7uPEfSliF2LlWK94C72V9GyT/YEXFtjuKcTqrF5S9PNqHmmlknIlLFPKMT5I930HbiUS5BsCZwLvoLuEd9l67fntN2cS5TL/0sFt96C7coyq3qHESqAUvXJOk/LdsA0+TQ2TJXrpAZMkSVKaQWDfxNvUWXJzuOFzEX8Hvgj8reD2y5NW67zpBoBjaH5J1NFeQPrM2CeIlRuXlx8O84jE0np0PtO5SimzAO8gLjb/uuD2i9KcpsVl+Tr5S4H1o2lEGbypGht/iWiy3Ss2AzYquO1pRPL1/oLbbzI06pZShmVJYgVbGf5GzOZPvbhZpZcBGxTc9hSif8UDBbd/EXGhXtW7kXit/jnxdtOJ/jFqrvnAuxJvU+d35jWJ1Q9F/IH4jLyh4ParU3z1cBtMB35ErKCrjAkRSZKk/nY7abM6K/1yOsa+FK+t/Z0xfxbRa7MylyEaxrdl5cv+pNcJ/hhwQQWxjHZlxfvv1G4Uv0B5FJHgSXk9vIvOe9E00aLAScTrQvXaiGgcO5GXAe+sKZa6pHyefIeo+35sRfsvy32J229ZSRTNkPr8PkxaYr3Xvo802cPA60gvn7U9sHb54ahE/6B4IhLqPac5gOLfeb9DlMxKKf/Za+8hKwEnMvXkio6ZEJEkSdIVCduuWFkUC5tJ8dUrDzFy4eH4ob8XsTExM7OXbEzMTG26AWC7xNtcAHy5gljaoujJ7uiT6F9SvA/K04iLRL1kDWBO7iD61KeB1cb595nAd+m8aWoTrQK8seC2/yAayUM8DkW9ifo+f4fdmbj9N4mLxr3macTKxCKuYmRlS0pC+s30VtnCprsR2L2D27WxNGk/GSStJFpd76mLU3wSwF3AyUM/HwU8XvB2W9B7Zd1eAXymqp2bEJEkSdJfE7Yt2jC2WztTfObWCYzUGX+QSIoU1WszqiBWXuyaO4gpbEL6ieihFO+J0WteDqxfcNsziIs9ECUk+nmGIcCORCk0dW9uwrZLAN8Y598/QNpFm9SL8jnsR/HVVaOTIKMvnk9lEaL3VZ1SH/tZRLmoLwLPKD+cbDp9fq8kGnoXsSj1P7/97kzgvMTb7FhBHCpXE89pdgeWLrjtDxhJgtxJvKcWdWBKUC3xYdInUBViQkSSJElLJmybshS9G6nlKSb7+2RSEi+5XNPBbb4HrFN2ICVKrXX8B+A3VQTSEt28Hr5PlM8qIiXxkksnr4cvEHXj1Z3DgXsStn8dC8+ofhbw8YTb30Tz6/anJCoeJXo9jZbyebUfxctIluF24D+Jt5kJfAi4DvgZUTO/LWUcx5OSqHiYJ5dB6+eyhW1waOL2L8aVPE3XxHOaoomKQaIH12gp7yEpiZdcUr/DDRDvq6Un2U2ISJIkKaVsVEq/kU6llLK6iCcvj//r0L8XkVKaK5ejSJshBjE7+2RgsfLDKUVq2YkjK4miHVJKWd0A/GrMv/2HaOJcVNNXifyKuDCfYgbwY7yQ1a07gPck3uZw4v0I4NvA7ITb7sPI6r+mSilldSJP7stxCvG4FrEK8IaC25ZhEDi9w9tOI97nzyCSaL8k3lvWKie02qSUsvoRcP+Yf/spxVfarErx0lwqx++AvydsP43eLAvXS5p2TpNSyurXwPVj/u13FO9tl1KaK5evA2cn3mY5okfiImUGYkJEkiSpv80GNkzYvo6Th25mw0/17+NJad6eyx7AvxNv8zzSHoe6LAKsm7D9IE++yN9PUmYNH0H0EBkr5fcgpXl7LocAlybeZlWivJ7nwN05jri4XdRqwKeAXYCtE253NHFxqOm6/byaRyS9qzheGU4tYR+LAa8hSqhdA1xL9Lp6Cc3vJdPt8/s4UQKniuOpHKnvMxtVEsXkXkR8B6xytHkl17CnAM9O2L4t5zQp/aZSmrfnsID4nnlr4u02Ab5SZiAux5MkSepvnyJtxs1NVQUyZHliRmYRdxMzhsbzE+AwitUHXhnYiZjd2VT3EzFeRNRpL2p3oob596sIqkMrkXay9ic67yOwP7B6h7edzCXEzN+qLQrsXXDbx5n4wupviWbORcqozQb2pNkN7B8nZub/ibTkzVbAJ4j3PXVuX2LGatHSHAfz5JURk7kNeF9qUBlsMjSKuBy4bIL/+x5RJ71Ism4z4oLsFQWP261fE7G/oMR9Pgt479C4hVglcxJwAc3qE/UiYsVqEZcS70fjOQL4IMWe35cBG5DWGFrd+RWRZC9q5aoCmcRs4JkVH6MXJgt8IXH7myuJYsTqFC8RezMTTzY4lujNtHiB/axJlCo8o+Bxc7iLONc7j7S8xEFECd2Jzv2SDTr6dqxBs91I/sfIkWdsTrOdTf7HyJFn2OxQdbiY4r+Th3V5rC2ImTopr4M3dXnMqXwsIZapLth+OWFfF5Z8P6ZyVkJsHxx1u70Sbjc8HiUusIxnjcR9lVGbeNPEY3aTzLkw8VhFR10lvN6eENMPp9jXwQn7up56L44cnRDb/4263WtIfw+bTyRGxrNI4r6e1+X9boIfU/z+fmDU7fZIuF3qGH0Bae+E211fwuOR4riE2PacYl+nJ+wrZcVBGTYmXjdVPd/D41bgm1R/4beoEyge+zum2NcvE/bVpAkMVTmE4o9H1Retl02IZZCYZFKGzycet+qRUs6wqKsTjn9ol8d6XcKxhsc2XR5zKl9KiGWq/lrfS9jXmSXfj6lcmhDb6DLF70+43fB4gIlXAW2Ysq9eyABKkiQp3bbExZyUmfqPklYqJdUMojxQEYM8ufHgWEcMbVfEiyl3BmxVvs+Tm7ZOZRbRT2Sp8sPpSOrsytSmvr2kjFILw44BHim4r9VJb3yfwxnErMkU04gLnauWH05f+QGR2C3bCXTet6JOK1J8gsB9TL0CMaWs3a7AUxO279YfgU/WcJxViObDVxKruKq4QFvUSsDOBbe9l0gsTibl+X0LzS9b2EvuI0rXFZVjhYgm93rSSg9C9Db6TQWxDBtebVvEPKZOhKa8h2xDWumwXL5CWo87gCWJc5quPx9MiEiSJPWXNYmLTWeSflJ3BvBw6RGNeD3FL1KeQ9Qhn8y1pDXua0vt7neR1gQU4nmve1bxREyIFJOSpLuSqWet3sfUF+1Ga8vr4RNE2YUUyxOPhSWku7M35TY9vwN4d4n7q9I+FC83eSxTJyN/BdxQcH+ziNWCdfoM8D81HWvW0LGuJBqz55DSW+wYYsLIZM6geMnR2dT//PazQaKET1EmRJrjucT3/FNITyKeBjxRekQjUvqxncbU33WvoHjvtAGil0gbvAO4LvE26wHf6vbAfgGUJElqrw2Y+gvvDKJe9zrAc4iEQ6fN9o7u8HZFlTkbfvR2RRv57kKUhEk5Mc7hEWLm6mXAEgm3eyNRNun/ptqwYsskbl9lEq7JUl4PRRtufgd4Z8FttyAuNlyVEEcO84kZ81cQs7qL2oyoN/6BqTbUhG4iSvqlzFydzP7ErN2mmwnsl7B9kdfnAqIkyucL7vNdRFnI+QlxdOszxIWrzwNPr+F4awA/I1am7kV9yfGZLFzWZSopz+9nC+5zf+Cr1Pv89rN7iBVKRSxG/I6krCrR1F7I1Oc0M4G1iHOadSj+nI2nrec0RftWvYMoQ/xQQhw53E+c01xI9M0r6p3ERKCunsfcdeoc+YY9RBxNHZvTbPYQ6d9hDxHVIaWHSJ2j6hImGyTEcgswveB+pxP1p4vu+6Ol3JupddpDZLRdEvYxPB4nGsUOy9FDZN/EY3ZzwbqtPURWJp6rIrE8RFo5tD8W3O8g8O3u70ohRyfENFFCb3Nitmfqc7njqH3YQyT9tTgAnJuwj4nGRE1Sm9hD5M0JMf02Yb8rAHMT9v2G7u9KRxYlekDcXSDGssbfqK+M1K4JcaWU3FmR4u/rg0RPhF7VpB4iEMndovE8UNIx7SGSb5xQwX0d7eUJsVydsN/ZRPKu6L7rWiXSaQ+R0VLPDQaJCWLrjdqHPUQkSZJUqkeovnxOyv6PpPisyfmkNSh9F+1ZRX0i6ResZxIXHp9SfjiF3ZG4/QqVRNFsKeVafkjaBZqU2fy7U04SrA7n0VlJnzk0f6JYkw0Ss/e7Wcn1X9pT3gOqWb0FcCdR+qWKOMo0l1i98Eziom7R3kTdWJcoO1W0TFk3qpjZDfHZd2pFcahzA6StLry1qkBUi/uA91V8jJTX7lT9EEd7lPjOUtSBdF4VoG5HkJ6omk30E1mykwOaEJEkSdJUPkLx2uadWI5oIlrEE6TPzj+S4nWCn0a7ZmW+l5jxn2I14HjynSSllj1ZsZIomiu1XEtquaIfERcEilic4iW2muALxEXTFMsAJ5FWqkELu47uVtcdRPNLFQ7biCi3VsQdpCU4IO31vDkLz46t2/1ESZY1iBJiZwCPVXi8TYmyj1V6AdG/qYjbSW8InPL8voooW6hqPZXiExAAbqsqENXiPaRPzEmRch7xKNGDKMV3iYkIRawDbJm4/5z2Jb1M67NJm/j2/7Vl9pskSZLy+ATwjYqPsSfFl+rfQpSKSnUzxWeBH0TMOGqDx4nau38Clk243bbEBcwfVhHUFFJPRF809SY9ZWeKz1a9F3jl0EhxA1FaoIj9iTJVRU/AcxoE3kb0E0npcfAC4DDiQok6803id/elibc7jVjt1hYHJmx7I53N8n+YSEYWcSBpCdQq3EnM7j2CiHsrohn6dpS/wu/jRJP6qi5opjxfNwLv7uAYjxB9KIo4kHgPVnVekri9K0Ta62DSExCpUlaa30Bnk07uoPj3xIOIku9t8DDxPeJSin8GAryJ6Cfyh5SDmRCRJEnSRD5J8QagnZpG2sn+6kSpjiq9HFgf+GvFxynLDcDbieazKas+PkXMcK1b6gqRtYhk1vUVxNJEKRfklqX618NaRALtzIqPU5Z7GDk5Tpn1+y7gkkoi6g+DwB7AXyie4L6XeNzb4ikUX80I0fy2aAPcTr0V+DDxWDbBw0SS6zTi831TYPuhsX4J+1+KSHp+pYR9jbU8aRMuXkT1CfvdiVW691d8nH62beL2N1USxeQuJy0Z24kqV3c1wXuofoLXokTfq6KeQ/Xf4bajXd+hryKS/Mcn3u6rJE5AMCEiSZKksf5LzKKqY/XADkSSo2kOIu2kJrfTgS8BH0q4zXRiVnfdHgWuIZa5F7U1aXWWhx1A8R4YW9Fd2Z8ybEwzV8QcRHsSIhCJjfczcQP2idTVRL5X/Yvo4/Llgtu/h/QEaU57AbNyBzHGYkQiquqLap1YAFw0ND5GlGvcbmhsQ1rCcrQdqCYhsjfNK503XLbw67kD6VEDpCdEzqkikCk8AFyc4bi94HYi8f6zGo61C5FYbZJpxHfh9+cOJMEJwMtIW/24CLHStzB7iEiSJGm0HxIzluoqpdTUpqG7Eb1N2uRjwO8Sb1O0bEfZUvs87EdnPU+uIJptFxn/6GD/ZWvq62FbYqVIm3wD+EnibXK9HnrJYRRbaXMGUfqoLabT3NJFB9COazs3E/XvdyAasn8NeKiD/WxGrBQp0wyau1rpANrTGLltXk/apJx7SCzLo6yOIvrw1JEMgeZ+h9uD9n2/OZgoB5wi6T624UNTkiRJ1XoEOJoobbEbsUKkDs8FtqjpWKlmE71N2mQ+MTutymaRZUlNiGxI1KTvZcsDb84dxAQGiItybbMXsRpJ9ZlPzGifO8k29wP71BNOaV5LWl+aOq1BrLpok1uAQ4jH9KeJt51ONC4u0+sq2GdZ1gRenTuIHjSNKB2a4kzgiQpiUXkeIlYUb0R8B7ivpuO+mOhH1kTLEuUV22Qu0U+ksufPhIgkSVJ/uoOo8X0gsCoxe+jSmmOouh5yt/anfd+Xbydq3C/IHcgUzid9ZvChxIWwXrUPzSvXMto7gSVyB5HoQWAnokyb6nM18OlJ/v/9tK8xcVNn/g5renwTuRfYlSj7mGLFkuNo+uPX9PjaaB9g3cTb/LyKQNS1W4nE6r7AKsSq4j/XHEPTX6NNj28819FZ0/lC7CEiSZLUXv9i6i/8c4kLDvcM/Xk7kfi4odLIprY00Sy0yVYnSnvUtdS+LOcSyYPP5A5kEo8DvwF2TLjNRsDniAbCvabJ5VqGLUW8ZtvWZ+NvxOqWH+QOpM98CXgj8Pwx/3428P36w+nKusArcwcxhS2Bdai+9N/6wF9L3uc84BPE521RZdbpXx94eYn7q8I2RN8tV7yV48Wk95h6kHb10mqbK4mG2pN5jIXPaW4lzmlurja0Ka1MTL5osnWBzYkSsW1yGtEj65Cyd2xCRJIkqb1+Cbw3dxAdeifRLLTpDqJ9CRGIxMFmpDcLrdORpCVEAD4IXEjvzdJ8PbFSq+kOpH0JEYiSgC+jwpmGepIniMf7j4w0z36IaFzdNk1fzQhR1u5Aqo31Y8TKny8QSff5Je7770T5zqI14MtcBdmGmdPDZQsPzh1ID3gWcArRhDnFl4ikiKpxEuklzJpiX0Y+55rsINqXEIGYCPUi4rymNG0rASBJkqT2a1M/gi2IXidtM0jUC849a24yvySSGykGgBOA7csPJ6s2XJADeA4xE72NDqD8me2a3F+Bz4/6+4eAGzPF0qllaE/t9bdTfrPxYW8gVh1OIxIj51NuT5XZpF2gLqvk2nJE77Q2eAftK1vYNFsDlwErJd7uNuBr5YejHjCTSIi0wY40txfWZJ4geuzdVeZOTYhIkiSpbq8mmoS2RRtmB4/nbuBNRDmSpvpoB7dZglhC/+4S45gGrF3i/lJsQKxeaIuR5GznAAAK+0lEQVS2JG/GepRo0OkM33p9jkiMnAd8J28oHdmDdqxmhHhvfEcF+90IOI5ISA/bDPgL0Q9mVgnHeClpFUxuKeGYAHsSyZg2WIpIeind0sR70RlEg+lUhxIrmKSxdiY9wZbLdJpfnnUit1Jyj0RLZkmSJKluKRdULyN9FUERLwY2Kbjt7sBHgPsriKNqFxNlpg7LHcgEzgfOImZtpphO1P/eDvgAnc/8n0nM/v4Q+RIiKa+Hq4nHq2zrAa8quO32wBrA9RXEUbVriAugP8kdSB+ZR1zEeIRYudYm00hbzfhrqunhsR3FJxEcCHyT8h7rlYkSheOVsloG+DKRnP4kcAydldFahijDVdSjRD+0bk0D9k/Y/lfAP0s47ljbE2WcihguW9i211IuKxNl+t5L/J514kqi7KI0npTvcH8ALq8ghs2JyTVF7E2UJnusgjiqdg5RtvGTZe1w0NG3Yw2a7UbyP0aOPGNzmu1s8j9GjjxjH6TqXUzx38mmXuSezLOJ2T1F7+OLK4rjRQkxDALvKfn4ZyUc+4MlHO+khONNNpYuIZaxNiKarHca03zgeKJfStGSK0sSJ7Gdft88svO7u5DlGLlQXGRU1bTzGcTjWDSOL5d8/KMTjp3aCHc830g43mTjeSXEktuPKX5/P5Ahvr0T4ru+5GNvn3DsucAKJR9/2DsT4hikvN5Rs4BLEo77b+CLxGSDgXH2N57nJx5jkOj/UIYdE445l3IbuY+2Z0Icg8BWFcVRp0Mofn9vA1abYjwd2JCYXLEb8Rn114RjTDTup7r3+c8nxHFuRTFU7WqK38dDM8XYjY1J+32qqgTvtolxlN1P7dKEY3dbXmwaaedQEw5XiEiSJKlOB1D8QslfgIsqiuNi4M/ECXQRBxAXYgcriqdqexKzx9bKHcg4riCSE9/t8PbTiAsguxHlkM4BriVmEN9OXNR75pixYnchl2YvipdruZ0oFVaFG4nZz68puP2etLuEyCHERdtNcweiRkuZ+XsqcGdFcZxI9C8oOsP9IOL13K2jKb6SEuK99UND45ahGG4kLmjfCvyHuA+rEhex35C4/2E/7eA240l5fn9KyfXrR/kR8FWKTzg4iJig1y9WBm7KcNwniHJIV2Y49livIFZG1eXXwOtqPF5bpbyH/A64qqI4fk1MCCg66f0g2rvqaQHxff8K4rOkYyZEJEmSVJfU+uadXiAv6giK17Rfk+h9ckZ14VTqAeLE/mLKqfdetiOA9UkrXzKeJYHXdx9OLaaTdn9/QFygqcp3KZ4QWZY4IS1rpUzd5hH9da4gVulIY61N2kz8Kj+vHiXKUR1ccPvhPl3XdnHM/wF26eL2TyMSvmV7BDi9hP08F9giYfsqn99HiB4tRfuVbUd7yxa2yUFUU6KyE9Oo97vbojUeq62WJxp9F1Xle8gg8D2Klx7ciOgDdUFlEVXrLuKxP48u8ho2VZckSVJd3k40BS3iIeCECmOBKLOU0mC5rc2kh/2FZjeIPxj4be4gCiqjUf0ORKmqIhYQJ7tV+iVps3Db/nq4CXgb7V31pWodSPHVjFcTF2aqlHIxbYC03idjPY/mlq/5HJHg71bKZ+GVxOzuKhWdnAHpvW2U7ktUPylH7bYPxRNHd1LeyraJHEWUny2q7d/hLgA+3M0OTIhIkiSpDgOkXYA4gbRkRSdSky7bED1Q2uwoYqZxEw2Xp7gidyBT+DHwkRL2k3IyegbVlwxZQNqKj/WIMh5tdgZpzZzVH5YkEvhFHVFVIKP8g7SkyzuBxTs81pVE/5SqSkR16p/AV0rYz9LA7gnb1/H8XgX8PmH7PRi/0b268xixsulDuQNRo80A3pWw/dGkJSs6cRdp/ZXeCKxSUSx1+SpdlJI1ISJJkqQ6bAmsk7B9ymzJbqQcp9tZt02xP/D33EFM4G5iGf8PcwcyjoeIi1C7EI1Wu/E84FUJ29c1U/X7pJXlavsMQ4jSQOflDkKN8g4iKVLEcDmrOqS8D6Re9B/rTKLHVlNW7T0G7E05FxVTkkWPAMeWcMwiUp7fZYG3VhVIn7oReCkxcUSazOsp3r9ikHqSqpD2HjID2K+qQGr0DuC6Tm5oQkSS/l979xIiRxWFcfzviG+MmonGV3wQNFmIgoIIQQ0IPpCgCxF8LASjAWcnLuNCUHChuNFAVEQRNAZRhCgiIsSADBqziKv4iJKoGR8kM4Nj5h0XXzfKMLHO6a57b033+UExWdR03Ux1VVffc885IYQQcvBMnA6j8k457MXXuP0h1AtlKfsbuIf0GTidOor6UzwBzBUeS9vXwLXU14TSky31E5qczGEE32q7u1Fz5KVsDrgP/d9D8GYzbgNGE41loffwNW7vtkTir2gxw5OUvRdPoQbsngyK4/EubHib7gPgVu/iy8rphYB0U3wEXIc+60Oo4rn22g3Pc9iJr3H7o8DJicaSyxjKLp/y/mIEREIIIYQQQmqXoyagVrmyQ9o8K6qW4Sul0lT70GrbJnseuB2t2izlR+Bh4Abgu5pe82zUu8LqFVTOKhfP9XAivrIRTTWCMn+aEoAL5dyKrzRizj4DM/hWr3sbhy9mHnga3QN3kL/nzl8ogF9XULjdcN4q5/mdxhd0vwpYn2YofeNzlK15J8pQDaHKNcCNjv1z96LxZKOsBO5NNZCM9qA+hC4REAkhhBBCCKkNYX/uPAxsTziWxWxvHdfK02y3yd4BXio9iAqfosnJIbRaOZcDwCZgDfAavjJSVTzlWrwToHX4DPjWsf8jwKmJxpLTTrQSPvQ3z8rfPcCXqQZyHC/jC5DWlUWwG9iAymhtI0/w8BM06b+jxtf0/D12t7actuILOkWWSGd2oWDhzTSnLFxYGjzX3EHqvX9ZvIEywa165R6yFV9fyAiIhBBCCCGEpE5HfResXke1wnOabB3Xai0qI9ILHge+Kj2ICtPAFmA1Gq+nZIzHMfS3GAKuQBOPMzUfYwBfuZb3gd9qHkMVb73rFSi7ohc8C3xYehChmNUog8Aq98pfUAm9jx37bwAuq/H4e1GJubUoe228xtdu+wb1P7mNejMEr2y9plWJ87sfBYKs7gIuSTSWXjKLgiCbUWmsm1DwPwSP5cD9jv1fJX/m6RgKWltd39p6wSYcJcMiIBJCCCGEEFJ6EDX/tMjZeHChfl2VOY1q73oyZEqZBF5APStuAZ6j++bwE6hnxkbgQvSlcAv1NO5dzB1o0tWqxIQc+AOTvXI9HEMTsSXLtIVyPNmM48BbCcfyfzz3hQHgsQRj+B7Vnx8E1gFPAV/QeTbdn6h5+TrgauDNGsa40BD27M4x1D+khH4sW1iXCRRUGgY+AF5E/WcGURDkGZTZFUInNgKnGfedRQGRErzPjr3yDDeBSixOWHY+Afgh6XBCk61HKVxNtQt9MQ395wH0ENNU7Yf10H82U+7LUegfK4FTjPuOk6+Za6cGsZcHmgN+STiWKhehyQWLeeDnLo51LvYvVUdI3wB9ObZm8QfJX0O+yiq06ncNun7a23no/TcKHGptI//59z5UJsndiLELZ7U2qwOpBmJwPr5mm928N6zvP8hz37Oep0PUn0WUm+ceneNetNAZaIwWs3RXWs/z+TtJumy1KgPAxY79p8iXabYM1de/lH/vw+2f56Dr90hr+x2VpBomz7yU554W5zetM7EvlrGYRws7PKWCSvM+D+R0FPijhte5ADjJuO8oaTLO6rQCZb5bzKBnhFJWYQ8A5/zsPIx6Q6VkOk//AFaCityvIS1JAAAAAElFTkSuQmCC	IDR	1	default
\.


--
-- Data for Name: fiscal_years; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fiscal_years (id, name, start_date, end_date, is_closed, closed_at, closed_by, created_at) FROM stdin;
86cdd2ca-9f54-42dd-8352-8e447263a368	2026	2026-01-01 00:00:00	2026-12-31 00:00:00	f	\N	\N	2026-03-14 14:28:41.787
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_items (id, code, name, unit, category, description, current_stock, minimum_stock, is_active, account_id, created_at, updated_at) FROM stdin;
518fc3d4-6924-4649-b378-3937da9eaf89	GABAH-001	Gabah Padi	kg	Bahan Baku	\N	0.000	500.000	t	\N	2026-03-15 15:25:23.552	2026-03-16 12:26:51.817
77b38a80-5fca-4eb8-9c15-9c7dd5345db7	BERAS-001	Beras Premium	kg	\N	\N	650.000	200.000	t	\N	2026-03-15 15:25:23.563	2026-03-16 12:26:51.825
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entries (id, entry_number, date, status, narration, fiscal_year_id, created_by, submitted_at, cancelled_at, created_at, updated_at) FROM stdin;
c13f234a-92f1-46eb-a82a-afc64a13d0af	JV-PI-202603-0001	2026-03-16 00:00:00	Submitted	Pembelian: PI-202603-0001 - PT Gabah Makmur	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:18:41.405	\N	2026-03-16 12:18:41.407	2026-03-16 12:18:41.407
6692e7ad-c218-4987-90b7-df30a6e04d65	JV-SI-202603-0001	2026-03-16 00:00:00	Submitted	Penjualan: SI-202603-0001 - Toko Beras Sejahtera	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:23:59.31	\N	2026-03-16 12:23:59.311	2026-03-16 12:23:59.311
fa09f5f7-56dc-4eee-91e4-fd93b36ec629	JV-PAY-202603-0001	2026-03-16 00:00:00	Submitted	Pembayaran Receive: PAY-202603-0001 - Toko Beras Sejahtera	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:24:15.524	\N	2026-03-16 12:24:15.525	2026-03-16 12:24:15.525
092bf47c-1c50-48cb-910f-926d3dcdc7b8	JV-PAY-202603-0002	2026-03-16 00:00:00	Submitted	Pembayaran Pay: PAY-202603-0002 - PT Gabah Makmur	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:24:15.631	\N	2026-03-16 12:24:15.632	2026-03-16 12:24:15.632
\.


--
-- Data for Name: journal_entry_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journal_entry_accounts (id, journal_entry_id, account_id, party_id, debit, credit, description) FROM stdin;
2a3ed638-1975-42d8-86bb-9a6b31045c97	c13f234a-92f1-46eb-a82a-afc64a13d0af	4626a83c-2270-4c20-911c-0cad3711f0db	\N	5000000.00	0.00	Persediaan: PI-202603-0001
d99d9a61-1abb-4a8f-bab1-a09630c9c911	c13f234a-92f1-46eb-a82a-afc64a13d0af	83738eff-c0d8-4ef5-a524-240d529ffeaa	bc79a01d-761b-4b09-a3c7-ec329ddab228	0.00	5000000.00	Hutang: PI-202603-0001
3d4b7258-1f33-4618-8e85-aff43353334b	6692e7ad-c218-4987-90b7-df30a6e04d65	c9c02bb2-f765-4552-885f-f173330ae1a7	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	8175100.00	0.00	Piutang: SI-202603-0001
81b024c9-e453-4678-b951-b50ee1daf50f	6692e7ad-c218-4987-90b7-df30a6e04d65	7d1f94b7-a1bd-44f7-92cc-24619ec938c9	\N	0.00	8175100.00	Penjualan: SI-202603-0001
24678392-0bd1-410c-8ec1-8d7c0a576557	fa09f5f7-56dc-4eee-91e4-fd93b36ec629	49e18d26-dd22-4fc6-ae37-07db6f036bed	\N	8175100.00	0.00	Pembayaran: PAY-202603-0001
0f2e58aa-2239-452d-b7cc-2c27d0942988	fa09f5f7-56dc-4eee-91e4-fd93b36ec629	c9c02bb2-f765-4552-885f-f173330ae1a7	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	0.00	8175100.00	Pembayaran: PAY-202603-0001
07d2b1fa-c4dd-4036-b31f-37580b4a4b3b	092bf47c-1c50-48cb-910f-926d3dcdc7b8	83738eff-c0d8-4ef5-a524-240d529ffeaa	bc79a01d-761b-4b09-a3c7-ec329ddab228	5000000.00	0.00	Pembayaran: PAY-202603-0002
fed69541-4db6-49bd-b5b6-d0141d8f2f12	092bf47c-1c50-48cb-910f-926d3dcdc7b8	49e18d26-dd22-4fc6-ae37-07db6f036bed	\N	0.00	5000000.00	Pembayaran: PAY-202603-0002
\.


--
-- Data for Name: parties; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parties (id, name, "partyType", phone, email, address, tax_id, outstanding_amount, is_active, created_at, updated_at) FROM stdin;
fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	Toko Beras Sejahtera	Customer	08198765432	\N	\N	\N	0.00	t	2026-03-16 12:18:32.513	2026-03-16 12:24:15.534
bc79a01d-761b-4b09-a3c7-ec329ddab228	PT Gabah Makmur	Supplier	08123456789	\N	\N	\N	0.00	t	2026-03-16 12:18:32.442	2026-03-16 12:24:15.639
\.


--
-- Data for Name: payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_allocations (id, payment_id, invoice_type, invoice_id, allocated_amount) FROM stdin;
76051491-0263-4a6f-b1ca-4c74c865de01	f29ba1eb-7259-45af-b9f7-55fcb627b955	SalesInvoice	d014640c-b114-4181-84e8-e705a34b9f29	8175100.00
6ab7be6c-f773-4f88-9861-11a8760cfccb	2b55f181-ba45-4472-869e-38be33cc1bcc	PurchaseInvoice	d86ebfcd-f1ea-401f-8bb8-1897097da1fd	5000000.00
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payments (id, payment_number, date, payment_type, party_id, account_id, amount, status, reference_number, notes, created_by, submitted_at, cancelled_at, created_at, updated_at, fiscal_year_id) FROM stdin;
f29ba1eb-7259-45af-b9f7-55fcb627b955	PAY-202603-0001	2026-03-16 00:00:00	Receive	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	49e18d26-dd22-4fc6-ae37-07db6f036bed	8175100.00	Submitted	\N	\N	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:24:15.511	\N	2026-03-16 12:24:15.512	2026-03-16 12:24:15.512	86cdd2ca-9f54-42dd-8352-8e447263a368
2b55f181-ba45-4472-869e-38be33cc1bcc	PAY-202603-0002	2026-03-16 00:00:00	Pay	bc79a01d-761b-4b09-a3c7-ec329ddab228	49e18d26-dd22-4fc6-ae37-07db6f036bed	5000000.00	Submitted	\N	\N	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:24:15.627	\N	2026-03-16 12:24:15.628	2026-03-16 12:24:15.628	86cdd2ca-9f54-42dd-8352-8e447263a368
\.


--
-- Data for Name: production_run_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_run_items (id, production_run_id, item_id, line_type, quantity, rendemen_pct, created_at) FROM stdin;
edf8369d-aa89-4d43-9375-eb49fbf2e4eb	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	518fc3d4-6924-4649-b378-3937da9eaf89	Input	500.000	\N	2026-03-16 00:15:24.117
2c53d75e-2129-43e0-9d09-f880563a6db6	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	Output	350.000	70.00	2026-03-16 00:15:24.117
aafded06-7c33-4a30-adb9-6700137dc044	10349201-fc38-4795-8975-e888c7a68559	518fc3d4-6924-4649-b378-3937da9eaf89	Input	1000.000	\N	2026-03-16 12:26:51.828
8c1a3826-1fb4-40df-a07c-e2c11d1eac99	10349201-fc38-4795-8975-e888c7a68559	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	Output	650.000	65.00	2026-03-16 12:26:51.828
\.


--
-- Data for Name: production_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.production_runs (id, run_number, date, notes, reference_type, reference_id, reference_number, rendemen_pct, is_cancelled, fiscal_year_id, created_by_id, created_at, updated_at) FROM stdin;
fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	PR-202603-0001	2026-03-15 00:00:00	Giling batch pertama	\N	\N	PI-202603-0001	70.00	t	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 00:15:24.09	2026-03-16 00:15:24.15
10349201-fc38-4795-8975-e888c7a68559	PR-202603-0002	2026-03-16 00:00:00	Giling batch pertama	\N	\N	\N	65.00	f	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:26:51.813	2026-03-16 12:26:51.813
\.


--
-- Data for Name: purchase_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_invoice_items (id, purchase_invoice_id, item_name, quantity, unit, rate, amount, account_id, description, discount) FROM stdin;
fb2c8e8f-9ecb-4d95-9142-c5a8b2de943f	d86ebfcd-f1ea-401f-8bb8-1897097da1fd	Gabah Kering	1000.000	Kg	5000.00	5000000.00	4626a83c-2270-4c20-911c-0cad3711f0db	\N	0.00
\.


--
-- Data for Name: purchase_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_invoices (id, invoice_number, date, party_id, status, grand_total, outstanding, due_date, notes, fiscal_year_id, created_by, submitted_at, cancelled_at, created_at, updated_at, biaya_lain, potongan, tax_pct) FROM stdin;
d86ebfcd-f1ea-401f-8bb8-1897097da1fd	PI-202603-0001	2026-03-16 00:00:00	bc79a01d-761b-4b09-a3c7-ec329ddab228	Paid	5000000.00	0.00	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:18:41.378	\N	2026-03-16 12:18:41.391	2026-03-16 12:24:15.643	0.00	0.00	0.00
\.


--
-- Data for Name: sales_invoice_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_invoice_items (id, sales_invoice_id, item_name, quantity, unit, rate, amount, account_id, description, discount) FROM stdin;
40ceb322-e4cc-426b-ada9-4ed8717bf91f	d014640c-b114-4181-84e8-e705a34b9f29	Beras Medium	650.000	Kg	12000.00	7410000.00	7d1f94b7-a1bd-44f7-92cc-24619ec938c9	\N	0.00
\.


--
-- Data for Name: sales_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales_invoices (id, invoice_number, date, party_id, status, grand_total, outstanding, due_date, notes, fiscal_year_id, created_by, submitted_at, cancelled_at, created_at, updated_at, biaya_lain, label_biaya, label_potongan, potongan, tax_pct, terms) FROM stdin;
d014640c-b114-4181-84e8-e705a34b9f29	SI-202603-0001	2026-03-16 00:00:00	fa9e1c4b-9cfe-4b9d-b6a0-04f80694538e	Paid	8175100.00	0.00	2026-04-15 00:00:00	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	2026-03-16 12:23:59.295	\N	2026-03-16 12:23:59.296	2026-03-16 12:24:15.539	0.00	\N	\N	0.00	0.00	\N
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, movement_number, date, item_id, movement_type, quantity, unit_cost, total_value, notes, reference_type, reference_id, reference_number, offset_account_id, journal_entry_id, fiscal_year_id, created_by_id, is_cancelled, created_at, updated_at) FROM stdin;
8133cfe6-c20b-402c-9b7e-6daca66f1bd3	SM-202603-0001	2026-03-15 00:00:00	518fc3d4-6924-4649-b378-3937da9eaf89	In	1000.000	5000.00	5000000.00	Pembelian gabah dari petani	\N	\N	\N	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	f	2026-03-15 15:25:23.577	2026-03-15 15:25:23.577
e9cd1d6c-5835-4a8c-a010-d4582250bc83	SM-202603-0002	2026-03-15 00:00:00	518fc3d4-6924-4649-b378-3937da9eaf89	Out	200.000	0.00	0.00	\N	\N	\N	\N	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	t	2026-03-15 15:25:23.608	2026-03-15 15:25:23.634
fefcc027-472c-408c-845c-afb6b2ced012	SM-202603-0003	2026-03-15 00:00:00	518fc3d4-6924-4649-b378-3937da9eaf89	Out	500.000	0.00	0.00	Giling batch pertama	ProductionRun	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	PR-202603-0001	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	t	2026-03-16 00:15:24.106	2026-03-16 00:15:24.148
07862c82-5120-4b5a-bfdb-7331d6040ffa	SM-202603-0004	2026-03-15 00:00:00	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	In	350.000	0.00	0.00	Giling batch pertama	ProductionRun	fa304c5b-b52b-4fb2-b1a7-bea5c22354b0	PR-202603-0001	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	t	2026-03-16 00:15:24.113	2026-03-16 00:15:24.149
8615dd05-0feb-45f6-a38f-101121ff6a0c	SM-202603-0005	2026-03-16 00:00:00	518fc3d4-6924-4649-b378-3937da9eaf89	Out	1000.000	0.00	0.00	Giling batch pertama	ProductionRun	10349201-fc38-4795-8975-e888c7a68559	PR-202603-0002	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	f	2026-03-16 12:26:51.823	2026-03-16 12:26:51.823
acc66613-2275-4fc1-8700-825a20dbe40e	SM-202603-0006	2026-03-16 00:00:00	77b38a80-5fca-4eb8-9c15-9c7dd5345db7	In	650.000	0.00	0.00	Giling batch pertama	ProductionRun	10349201-fc38-4795-8975-e888c7a68559	PR-202603-0002	\N	\N	86cdd2ca-9f54-42dd-8352-8e447263a368	f56b0571-bb3c-412a-91a7-acff8d4ffbd8	f	2026-03-16 12:26:51.827	2026-03-16 12:26:51.827
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, full_name, email, password_hash, role, is_active, last_login_at, created_at, updated_at) FROM stdin;
f56b0571-bb3c-412a-91a7-acff8d4ffbd8	admin	Logia Admin	admin@panganmasadepan.com	$2b$12$Zlcyd3ibA28QCc.0xl9e5u/X41vc7oVIAQtvaE1Saauq9tecACVdO	Admin	t	2026-03-16 14:57:22.96	2026-03-14 14:28:42.346	2026-03-16 14:57:22.96
d389332a-249b-4b24-8ecc-18d3e8ab8962	info	Info PMD	info@panganmasadepan.com	$2b$12$VczsG6Ey0FxXxJghHaSyYOpzbQmY8iroWS6s5ttpE2qk.MfqsdHWO	Accountant	t	\N	2026-03-16 15:27:57.684	2026-03-16 15:27:57.684
abe7078f-b709-49e2-8e5b-4c0213760142	ysn	YSN	ysn@panganmasadepan.com	$2b$12$VczsG6Ey0FxXxJghHaSyYOpzbQmY8iroWS6s5ttpE2qk.MfqsdHWO	Viewer	t	\N	2026-03-16 15:27:57.688	2026-03-16 15:27:57.688
57bfda57-46b8-4a94-bdd6-b5653522e4fb	keuangan	Keuangan PMD	keuangan@panganmasadepan.com	$2b$12$VczsG6Ey0FxXxJghHaSyYOpzbQmY8iroWS6s5ttpE2qk.MfqsdHWO	Admin	t	2026-03-16 20:49:45.522	2026-03-16 15:27:57.673	2026-03-16 20:49:45.522
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: accounting_ledger_entries accounting_ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_ledger_entries
    ADD CONSTRAINT accounting_ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: fiscal_years fiscal_years_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: journal_entry_accounts journal_entry_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_accounts
    ADD CONSTRAINT journal_entry_accounts_pkey PRIMARY KEY (id);


--
-- Name: parties parties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parties
    ADD CONSTRAINT parties_pkey PRIMARY KEY (id);


--
-- Name: payment_allocations payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: production_run_items production_run_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_run_items
    ADD CONSTRAINT production_run_items_pkey PRIMARY KEY (id);


--
-- Name: production_runs production_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_runs
    ADD CONSTRAINT production_runs_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoice_items purchase_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_invoices purchase_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_pkey PRIMARY KEY (id);


--
-- Name: sales_invoice_items sales_invoice_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_pkey PRIMARY KEY (id);


--
-- Name: sales_invoices sales_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: accounting_ledger_entries_account_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_ledger_entries_account_id_idx ON public.accounting_ledger_entries USING btree (account_id);


--
-- Name: accounting_ledger_entries_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_ledger_entries_date_idx ON public.accounting_ledger_entries USING btree (date);


--
-- Name: accounting_ledger_entries_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_ledger_entries_fiscal_year_id_idx ON public.accounting_ledger_entries USING btree (fiscal_year_id);


--
-- Name: accounting_ledger_entries_party_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_ledger_entries_party_id_idx ON public.accounting_ledger_entries USING btree (party_id);


--
-- Name: accounting_ledger_entries_reference_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX accounting_ledger_entries_reference_id_idx ON public.accounting_ledger_entries USING btree (reference_id);


--
-- Name: accounts_accountNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "accounts_accountNumber_idx" ON public.accounts USING btree ("accountNumber");


--
-- Name: accounts_accountNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "accounts_accountNumber_key" ON public.accounts USING btree ("accountNumber");


--
-- Name: accounts_parentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "accounts_parentId_idx" ON public.accounts USING btree ("parentId");


--
-- Name: accounts_rootType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "accounts_rootType_idx" ON public.accounts USING btree ("rootType");


--
-- Name: company_settings_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX company_settings_slug_key ON public.company_settings USING btree (slug);


--
-- Name: fiscal_years_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX fiscal_years_name_key ON public.fiscal_years USING btree (name);


--
-- Name: inventory_items_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_items_code_key ON public.inventory_items USING btree (code);


--
-- Name: journal_entries_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_date_idx ON public.journal_entries USING btree (date);


--
-- Name: journal_entries_entry_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX journal_entries_entry_number_key ON public.journal_entries USING btree (entry_number);


--
-- Name: journal_entries_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX journal_entries_fiscal_year_id_idx ON public.journal_entries USING btree (fiscal_year_id);


--
-- Name: parties_partyType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "parties_partyType_idx" ON public.parties USING btree ("partyType");


--
-- Name: payment_allocations_invoice_type_invoice_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_allocations_invoice_type_invoice_id_idx ON public.payment_allocations USING btree (invoice_type, invoice_id);


--
-- Name: payment_allocations_payment_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payment_allocations_payment_id_idx ON public.payment_allocations USING btree (payment_id);


--
-- Name: payments_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_date_idx ON public.payments USING btree (date);


--
-- Name: payments_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_fiscal_year_id_idx ON public.payments USING btree (fiscal_year_id);


--
-- Name: payments_party_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payments_party_id_idx ON public.payments USING btree (party_id);


--
-- Name: payments_payment_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payments_payment_number_key ON public.payments USING btree (payment_number);


--
-- Name: production_run_items_production_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX production_run_items_production_run_id_idx ON public.production_run_items USING btree (production_run_id);


--
-- Name: production_runs_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX production_runs_date_idx ON public.production_runs USING btree (date);


--
-- Name: production_runs_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX production_runs_fiscal_year_id_idx ON public.production_runs USING btree (fiscal_year_id);


--
-- Name: production_runs_run_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX production_runs_run_number_key ON public.production_runs USING btree (run_number);


--
-- Name: purchase_invoices_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_invoices_date_idx ON public.purchase_invoices USING btree (date);


--
-- Name: purchase_invoices_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_invoices_fiscal_year_id_idx ON public.purchase_invoices USING btree (fiscal_year_id);


--
-- Name: purchase_invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX purchase_invoices_invoice_number_key ON public.purchase_invoices USING btree (invoice_number);


--
-- Name: purchase_invoices_party_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_invoices_party_id_idx ON public.purchase_invoices USING btree (party_id);


--
-- Name: purchase_invoices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_invoices_status_idx ON public.purchase_invoices USING btree (status);


--
-- Name: sales_invoices_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_invoices_date_idx ON public.sales_invoices USING btree (date);


--
-- Name: sales_invoices_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_invoices_fiscal_year_id_idx ON public.sales_invoices USING btree (fiscal_year_id);


--
-- Name: sales_invoices_invoice_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sales_invoices_invoice_number_key ON public.sales_invoices USING btree (invoice_number);


--
-- Name: sales_invoices_party_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_invoices_party_id_idx ON public.sales_invoices USING btree (party_id);


--
-- Name: sales_invoices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sales_invoices_status_idx ON public.sales_invoices USING btree (status);


--
-- Name: stock_movements_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_date_idx ON public.stock_movements USING btree (date);


--
-- Name: stock_movements_fiscal_year_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_fiscal_year_id_idx ON public.stock_movements USING btree (fiscal_year_id);


--
-- Name: stock_movements_item_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_item_id_idx ON public.stock_movements USING btree (item_id);


--
-- Name: stock_movements_journal_entry_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_movements_journal_entry_id_key ON public.stock_movements USING btree (journal_entry_id);


--
-- Name: stock_movements_movement_number_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_movements_movement_number_key ON public.stock_movements USING btree (movement_number);


--
-- Name: stock_movements_movement_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_movement_type_idx ON public.stock_movements USING btree (movement_type);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_username_key ON public.users USING btree (username);


--
-- Name: accounting_ledger_entries accounting_ledger_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_ledger_entries
    ADD CONSTRAINT accounting_ledger_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accounting_ledger_entries accounting_ledger_entries_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_ledger_entries
    ADD CONSTRAINT accounting_ledger_entries_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: accounting_ledger_entries accounting_ledger_entries_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounting_ledger_entries
    ADD CONSTRAINT accounting_ledger_entries_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: accounts accounts_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: audit_trail audit_trail_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: fiscal_years fiscal_years_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fiscal_years
    ADD CONSTRAINT fiscal_years_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: inventory_items inventory_items_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: journal_entries journal_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_entries journal_entries_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_entry_accounts journal_entry_accounts_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_accounts
    ADD CONSTRAINT journal_entry_accounts_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: journal_entry_accounts journal_entry_accounts_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journal_entry_accounts
    ADD CONSTRAINT journal_entry_accounts_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payment_allocations payment_allocations_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_allocations
    ADD CONSTRAINT payment_allocations_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payments payments_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: production_run_items production_run_items_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_run_items
    ADD CONSTRAINT production_run_items_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inventory_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: production_run_items production_run_items_production_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_run_items
    ADD CONSTRAINT production_run_items_production_run_id_fkey FOREIGN KEY (production_run_id) REFERENCES public.production_runs(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: production_runs production_runs_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_runs
    ADD CONSTRAINT production_runs_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: production_runs production_runs_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.production_runs
    ADD CONSTRAINT production_runs_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_invoice_items purchase_invoice_items_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_invoice_items purchase_invoice_items_purchase_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoice_items
    ADD CONSTRAINT purchase_invoice_items_purchase_invoice_id_fkey FOREIGN KEY (purchase_invoice_id) REFERENCES public.purchase_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: purchase_invoices purchase_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_invoices purchase_invoices_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: purchase_invoices purchase_invoices_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_invoices
    ADD CONSTRAINT purchase_invoices_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_invoice_items sales_invoice_items_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_invoice_items sales_invoice_items_sales_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoice_items
    ADD CONSTRAINT sales_invoice_items_sales_invoice_id_fkey FOREIGN KEY (sales_invoice_id) REFERENCES public.sales_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales_invoices sales_invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_invoices sales_invoices_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales_invoices sales_invoices_party_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales_invoices
    ADD CONSTRAINT sales_invoices_party_id_fkey FOREIGN KEY (party_id) REFERENCES public.parties(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_movements stock_movements_created_by_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_created_by_id_fkey FOREIGN KEY (created_by_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_movements stock_movements_fiscal_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_fiscal_year_id_fkey FOREIGN KEY (fiscal_year_id) REFERENCES public.fiscal_years(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_movements stock_movements_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_item_id_fkey FOREIGN KEY (item_id) REFERENCES public.inventory_items(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: stock_movements stock_movements_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: stock_movements stock_movements_offset_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_offset_account_id_fkey FOREIGN KEY (offset_account_id) REFERENCES public.accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict RFKlpnNwjYgqpyzfjcJw0H4N4aC8OBx28gxo0zPgeLqgbIQvWkIjthYsW9F0NzA

